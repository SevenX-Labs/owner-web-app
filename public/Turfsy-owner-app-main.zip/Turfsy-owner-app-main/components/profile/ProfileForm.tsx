import React from 'react';
import {
    StyleSheet,
    Text,
    TextStyle,
    View,
    ViewStyle,
} from 'react-native';
import { OwnerProfile } from '../../src/types/profile';
import { useAppTheme } from '../../src/hooks/useAppTheme';
import { fp, hp, wp } from '../../src/utils/responsive';
import InputField from './InputField';



// ─── Validation ────────────────────────────────────────────────────────────────
export interface ProfileErrors {
  ownerName?: string;
  email?: string;
  phone?: string;
  bankHolderName?: string;
  bankName?: string;
  accountNumber?: string;
  ifscCode?: string;
  upi?: string;
}

export const validateProfile = (p: OwnerProfile): ProfileErrors => {
  const e: ProfileErrors = {};
  if (!p.ownerName?.trim()) e.ownerName = 'Name is required';
  
  if (!p.email?.trim()) e.email = 'Email is required';
  else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(p.email)) e.email = 'Invalid email';
  
  if (p.phone && !/^\d{10}$/.test(String(p.phone))) e.phone = 'Invalid 10-digit phone number';

  const bank = p.documents?.bank;
  if (!bank?.bankHolderName?.trim()) e.bankHolderName = 'Bank holder name is required';
  if (!bank?.bankName?.trim()) e.bankName = 'Bank name is required';
  
  if (!bank?.accountNumber?.trim()) e.accountNumber = 'Account number is required';
  else if (!/^\d{9,18}$/.test(bank.accountNumber)) e.accountNumber = 'Invalid account number (9-18 digits)';

  if (!bank?.ifsc?.trim()) e.ifscCode = 'IFSC code is required';
  else if (!/^[A-Z]{4}0[A-Z0-9]{6}$/.test(bank.ifsc)) e.ifscCode = 'Invalid IFSC format (e.g. HDFC0001234)';

  if (!bank?.upi?.trim()) e.upi = 'UPI ID is required';
  
  return e;
};

// ─── Section Header ─────────────────────────────────────────────────────────
const SectionHeader: React.FC<{ title: string }> = ({ title }) => {
  const { theme } = useAppTheme();
  return (
    <View style={styles.sectionHeader}>
      <View style={[styles.sectionLine, { backgroundColor: theme.colors.border }]} />
      <Text style={[styles.sectionTitle, { color: theme.colors.primary }]}>{title}</Text>
      <View style={[styles.sectionLine, { backgroundColor: theme.colors.border }]} />
    </View>
  );
};

// ─── ProfileForm ─────────────────────────────────────────────────────────────
interface ProfileFormProps {
  profile: OwnerProfile;
  errors: ProfileErrors;
  onChange: (updated: OwnerProfile) => void;
}

const ProfileForm: React.FC<ProfileFormProps> = ({ profile, errors, onChange }) => {
  const set = (path: string, value: string | number | string[]): void => {
    const keys = path.split('.');
    const updated = JSON.parse(JSON.stringify(profile)) as OwnerProfile;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    let cursor: any = updated;
    for (let i = 0; i < keys.length - 1; i++) cursor = cursor[keys[i]];
    cursor[keys[keys.length - 1]] = value;
    onChange(updated);
  };

  return (
    <View style={styles.container}>

      {/* ── Basic Info ── */}
      <SectionHeader title="BASIC INFO" />
      <View style={styles.section}>
        <InputField
          label="OWNER NAME"
          value={profile.ownerName}
          onChangeText={(v) => set('ownerName', v)}
          placeholder="Enter owner name"
          error={errors.ownerName}
        />
        <InputField
          label="EMAIL ADDRESS"
          value={profile.email}
          onChangeText={(v) => set('email', v)}
          keyboardType="email-address"
          autoCapitalize="none"
          placeholder="Enter email address"
          error={errors.email}
        />
        <InputField
          label="PHONE NUMBER"
          value={profile.phone ? String(profile.phone) : ''}
          onChangeText={(v) => set('phone', v)}
          keyboardType="phone-pad"
          placeholder="Enter 10-digit number"
          error={errors.phone}
          editable={false}
          style={{ opacity: 0.6 }}
        />
      </View>

      <SectionHeader title="DOCUMENTS & PAYMENTS" />
      <View style={styles.section}>
        <InputField
          label="BANK HOLDER NAME"
          value={profile.documents?.bank?.bankHolderName}
          onChangeText={(v) => set('documents.bank.bankHolderName', v)}
          placeholder="Enter bank holder name"
          error={errors.bankHolderName}
        />
        <InputField
          label="BANK NAME"
          value={profile.documents?.bank?.bankName}
          onChangeText={(v) => set('documents.bank.bankName', v)}
          placeholder="Enter bank name"
          error={errors.bankName}
        />
        <InputField
          label="BANK ACCOUNT NUMBER"
          value={profile.documents?.bank?.accountNumber ? String(profile.documents.bank.accountNumber) : ''}
          onChangeText={(v) => set('documents.bank.accountNumber', v.replace(/[^0-9]/g, ''))}
          keyboardType="number-pad"
          placeholder="Enter account number"
          error={errors.accountNumber}
        />
        <InputField
          label="IFSC CODE"
          value={profile.documents?.bank?.ifsc}
          onChangeText={(v) => set('documents.bank.ifsc', v.toUpperCase())}
          autoCapitalize="characters"
          placeholder="Enter IFSC code"
          error={errors.ifscCode}
        />
        <InputField
          label="UPI ID"
          value={profile.documents?.bank?.upi}
          onChangeText={(v) => set('documents.bank.upi', v)}
          autoCapitalize="none"
          placeholder="Enter UPI ID"
          error={errors.upi}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { gap: hp(4) } as ViewStyle,
  section: { gap: hp(18), marginBottom: hp(8) } as ViewStyle,
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: wp(10),
    marginVertical: hp(20),
  } as ViewStyle,
  sectionLine: { flex: 1, height: 1 } as ViewStyle,
  sectionTitle: {
    fontSize: fp(10),
    fontWeight: '900',
    letterSpacing: 2,
  } as TextStyle,
  row: { flexDirection: 'row', gap: wp(12) } as ViewStyle,
  flex: { flex: 1 } as ViewStyle,
});

export default ProfileForm;
