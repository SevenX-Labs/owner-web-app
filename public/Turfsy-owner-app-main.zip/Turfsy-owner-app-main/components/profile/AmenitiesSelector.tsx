import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ViewStyle,
  TextStyle,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { AMENITY_OPTIONS } from '../../src/types/profile';
import { wp, hp, fp } from '../../src/utils/responsive';

const THEME = {
  surface: '#1A1A1A',
  primary: '#ADFF00',
  textMuted: '#888888',
  border: '#333333',
};

const AMENITY_ICONS: Record<string, keyof typeof Ionicons.glyphMap> = {
  'Flood Lights':   'flashlight-outline',
  'Parking':        'car-outline',
  'Washroom':       'water-outline',
  'Changing Room':  'shirt-outline',
  'Drinking Water': 'cafe-outline',
  'Seating Area':   'people-outline',
  'Cafeteria':      'restaurant-outline',
};

interface AmenitiesSelectorProps {
  selected: string[];
  onChange: (updated: string[]) => void;
}

const AmenitiesSelector: React.FC<AmenitiesSelectorProps> = ({ selected, onChange }) => {
  const toggle = (item: string): void => {
    const next = selected.includes(item)
      ? selected.filter((a) => a !== item)
      : [...selected, item];
    onChange(next);
  };

  return (
    <View style={styles.container}>
      {AMENITY_OPTIONS.map((item) => {
        const isActive = selected.includes(item);
        return (
          <TouchableOpacity
            key={item}
            style={[styles.row, isActive && styles.rowActive]}
            onPress={() => toggle(item)}
            activeOpacity={0.7}
          >
            <View style={styles.left}>
              <View style={[styles.iconBox, isActive && styles.iconBoxActive]}>
                <Ionicons
                  name={AMENITY_ICONS[item]}
                  size={wp(20)}
                  color={isActive ? THEME.primary : THEME.textMuted}
                />
              </View>
              <Text style={[styles.label, isActive && styles.labelActive]}>{item}</Text>
            </View>
            <View style={[styles.checkbox, isActive && styles.checkboxActive]}>
              {isActive && <Ionicons name="checkmark" size={wp(14)} color="#000" />}
            </View>
          </TouchableOpacity>
        );
      })}
    </View>
  );
};

const styles = StyleSheet.create({
  container: { gap: hp(10) } as ViewStyle,
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: THEME.surface,
    borderRadius: wp(16),
    padding: wp(14),
    borderWidth: 1,
    borderColor: THEME.border,
  } as ViewStyle,
  rowActive: { borderColor: 'rgba(173,255,0,0.35)' } as ViewStyle,
  left: { flexDirection: 'row', alignItems: 'center', gap: wp(12) } as ViewStyle,
  iconBox: {
    width: wp(38),
    height: wp(38),
    borderRadius: wp(10),
    backgroundColor: '#000',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: THEME.border,
  } as ViewStyle,
  iconBoxActive: { borderColor: THEME.primary } as ViewStyle,
  label: { color: THEME.textMuted, fontSize: fp(15), fontWeight: '700' } as TextStyle,
  labelActive: { color: '#FFF' } as TextStyle,
  checkbox: {
    width: wp(26),
    height: wp(26),
    borderRadius: wp(8),
    borderWidth: 2,
    borderColor: '#444',
    justifyContent: 'center',
    alignItems: 'center',
  } as ViewStyle,
  checkboxActive: { backgroundColor: THEME.primary, borderColor: THEME.primary } as ViewStyle,
});

export default AmenitiesSelector;
