import React from 'react';
import {
    StyleSheet,
    Text,
    TextInput,
    TextInputProps,
    TextStyle,
    View,
    ViewStyle,
} from 'react-native';
import { fp, hp, wp } from '../../src/utils/responsive';

import { useAppTheme } from '../../src/hooks/useAppTheme';

interface InputFieldProps extends TextInputProps {
  label: string;
  error?: string;
  containerStyle?: ViewStyle;
}

const InputField: React.FC<InputFieldProps> = ({
  label,
  error,
  containerStyle,
  ...props
}) => {
  const { theme } = useAppTheme();
  
  return (
    <View style={[styles.container, containerStyle]}>
      <Text style={[styles.label, { color: theme.colors.textMuted }]}>{label}</Text>
      <TextInput
        style={[
          styles.input,
          { 
            backgroundColor: theme.colors.surfaceMuted,
            color: theme.colors.text,
            borderColor: error ? theme.colors.danger : theme.colors.border
          },
          props.multiline && styles.inputMultiline,
          props.style
        ]}
        placeholderTextColor={theme.colors.textMuted}
        selectionColor={theme.colors.primary}
        textAlignVertical={props.multiline ? 'top' : 'center'}
        {...props}
      />
      {error ? <Text style={[styles.errorText, { color: theme.colors.danger }]}>{error}</Text> : null}
    </View>
  );
};

const styles = StyleSheet.create({
  container: { gap: hp(8) } as ViewStyle,
  label: {
    fontSize: fp(10),
    fontWeight: '800',
    letterSpacing: 1.2,
    marginLeft: wp(4),
  } as TextStyle,
  input: {
    fontSize: fp(15),
    fontWeight: '700',
    height: hp(58),
    borderRadius: wp(20),
    paddingHorizontal: wp(20),
    paddingVertical: 0,
    borderWidth: 1.5,
    justifyContent: 'center',
  } as TextStyle,
  inputMultiline: {
    height: hp(110),
    paddingTop: hp(20),
  } as TextStyle,
  errorText: {
    fontSize: fp(11),
    fontWeight: '600',
    marginLeft: wp(4),
  } as TextStyle,
});

export default InputField;
