import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ViewStyle, TextStyle } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Booking } from '../../src/types/booking.types';

// Turfsy Owner Branding
const THEME = {
  background: '#000000',
  surface: '#1A1A1A',   // Matching the "Victory Arena" card surface
  primary: '#ADFF00',   // Volt Green
  border: '#262626',    // Industrial border
  textMain: '#FFFFFF',
  textMuted: '#888888',
  textDark: '#000000',
  error: '#FF4B4B',
  warning: '#FFB800',
};

interface BookingCardProps {
  booking: Booking;
  onPress?: () => void;
  onAction?: (action: 'confirm' | 'cancel' | 'complete') => void;
  showActions?: boolean;
}

const BookingCard: React.FC<BookingCardProps> = ({
  booking,
  onPress,
  onAction,
  showActions = false,
}) => {
  return (
    <TouchableOpacity
      style={styles.container}
      onPress={onPress}
      activeOpacity={0.8}
    >
      {/* Top Section: ID & Status */}
      <View style={styles.header}>
        <View style={styles.idBadge}>
          <Text style={styles.idText}>#{booking.bookingNumber}</Text>
        </View>
        <View style={[styles.statusTag, { borderColor: getStatusColor(booking.status) }]}>
          <View style={[styles.statusDot, { backgroundColor: getStatusColor(booking.status) }]} />
          <Text style={[styles.statusText, { color: getStatusColor(booking.status) }]}>
            {booking.status.toUpperCase()}
          </Text>
        </View>
      </View>

      {/* Center Section: Main Details */}
      <View style={styles.mainInfo}>
        <View style={styles.sportIconBox}>
          <Ionicons 
            name={booking.sport === 'football' ? 'football' : 'baseball'} 
            size={24} 
            color={THEME.primary} 
          />
        </View>
        
        <View style={styles.detailsGroup}>
          <Text style={styles.customerName}>{booking.customer.name}</Text>
          <View style={styles.slotRow}>
            <Ionicons name="time-outline" size={14} color={THEME.textMuted} />
            <Text style={styles.slotTime}>
              {booking.slot.startTime} - {booking.slot.endTime}
            </Text>
          </View>
        </View>

        <View style={styles.priceGroup}>
          <Text style={styles.amount}>₹{booking.amount}</Text>
          <Text style={[styles.paymentStatus, { color: booking.paymentStatus === 'paid' ? THEME.primary : THEME.textMuted }]}>
            {booking.paymentStatus === 'paid' ? 'PAID' : 'UNPAID'}
          </Text>
        </View>
      </View>

      {/* Bottom Action Section (If pending) */}
      {showActions && booking.status === 'pending' && (
        <View style={styles.actionRow}>
          <TouchableOpacity 
            style={styles.declineBtn} 
            onPress={() => onAction?.('cancel')}
          >
            <Text style={styles.declineText}>Decline</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.confirmBtn} 
            onPress={() => onAction?.('confirm')}
          >
            <Text style={styles.confirmText}>Confirm Booking</Text>
          </TouchableOpacity>
        </View>
      )}
    </TouchableOpacity>
  );
};

const getStatusColor = (status: string) => {
  switch (status) {
    case 'confirmed': return THEME.primary;
    case 'pending': return THEME.warning;
    case 'cancelled': return THEME.error;
    default: return THEME.textMuted;
  }
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: THEME.surface,
    borderRadius: 20,
    padding: 16,
    marginHorizontal: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: THEME.border,
  } as ViewStyle,
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  } as ViewStyle,
  idBadge: {
    backgroundColor: '#000',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: THEME.border,
  } as ViewStyle,
  idText: {
    color: THEME.textMuted,
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 0.5,
  } as TextStyle,
  statusTag: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 20,
    borderWidth: 1,
    gap: 6,
  } as ViewStyle,
  statusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  } as ViewStyle,
  statusText: {
    fontSize: 10,
    fontWeight: '900',
  } as TextStyle,
  mainInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  } as ViewStyle,
  sportIconBox: {
    width: 50,
    height: 50,
    backgroundColor: '#000',
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: THEME.border,
  } as ViewStyle,
  detailsGroup: {
    flex: 1,
    marginLeft: 15,
  } as ViewStyle,
  customerName: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '800',
  } as TextStyle,
  slotRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 2,
  } as ViewStyle,
  slotTime: {
    color: THEME.textMuted,
    fontSize: 13,
    fontWeight: '600',
  } as TextStyle,
  priceGroup: {
    alignItems: 'flex-end',
  } as ViewStyle,
  amount: {
    color: '#FFF',
    fontSize: 18,
    fontWeight: '900',
  } as TextStyle,
  paymentStatus: {
    fontSize: 9,
    fontWeight: '800',
    marginTop: 2,
  } as TextStyle,
  actionRow: {
    flexDirection: 'row',
    marginTop: 20,
    gap: 12,
  } as ViewStyle,
  confirmBtn: {
    flex: 2,
    backgroundColor: THEME.primary,
    height: 48,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
  } as ViewStyle,
  confirmText: {
    color: '#000',
    fontWeight: '900',
    fontSize: 14,
  } as TextStyle,
  declineBtn: {
    flex: 1,
    backgroundColor: 'transparent',
    height: 48,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: THEME.border,
  } as ViewStyle,
  declineText: {
    color: THEME.error,
    fontWeight: '800',
    fontSize: 14,
  } as TextStyle,
});

export default BookingCard;