import React from 'react';
import {
  TouchableOpacity,
  Text,
  StyleSheet,
  ActivityIndicator,
  ViewStyle,
  TextStyle,
  TouchableOpacityProps,
  View,
  Vibration,
} from 'react-native';

// Turfsy Owner "Pro" Palette
const THEME = {
  background: '#000000', // Pure Black for depth
  surface: '#1A1A1A',
  primary: '#ADFF00',    // Volt Green
  border: '#262626',     // Industrial grey border
  textMain: '#FFFFFF',
  textMuted: '#888888',
  textDark: '#000000',
  danger: '#FF4B4B',
};

type ButtonVariant = 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger';
type ButtonSize = 'sm' | 'md' | 'lg';

interface ButtonProps extends TouchableOpacityProps {
  title: string;
  variant?: ButtonVariant;
  size?: ButtonSize;
  loading?: boolean;
  fullWidth?: boolean;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  style?: ViewStyle;
  textStyle?: TextStyle;
  haptic?: boolean;
}

const Button: React.FC<ButtonProps> = ({
  title,
  variant = 'primary',
  size = 'md',
  loading = false,
  fullWidth = false,
  leftIcon,
  rightIcon,
  style,
  textStyle,
  disabled,
  haptic = true,
  onPress,
  ...props
}) => {
  const isDisabled = disabled || loading;

  const handlePress = (e: any) => {
    if (haptic) Vibration.vibrate(10); // Subtle feedback on press
    if (onPress) onPress(e);
  };

  // Loader color logic
  const loaderColor = variant === 'primary' ? THEME.textDark : THEME.primary;

  return (
    <TouchableOpacity
      style={[
        styles.base,
        styles[variant],
        styles[`size_${size}` as keyof typeof styles] as ViewStyle,
        fullWidth && styles.fullWidth,
        isDisabled && styles.disabled,
        style,
      ]}
      onPress={handlePress}
      disabled={isDisabled}
      activeOpacity={0.85}
      {...props}
    >
      {loading ? (
        <ActivityIndicator size="small" color={loaderColor} />
      ) : (
        <View style={styles.content}>
          {leftIcon && <View style={styles.iconBox}>{leftIcon}</View>}
          <Text
            style={[
              styles.text,
              styles[`text_${variant}` as keyof typeof styles] as TextStyle,
              styles[`textSize_${size}` as keyof typeof styles] as TextStyle,
              textStyle,
            ]}
          >
            {title}
          </Text>
          {rightIcon && <View style={styles.iconBox}>{rightIcon}</View>}
        </View>
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  base: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 32, // Matches the massive rounded look in your images
    borderWidth: 1,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  // Variants
  primary: {
    backgroundColor: THEME.primary,
    borderColor: THEME.primary,
  },
  secondary: {
    backgroundColor: THEME.surface,
    borderColor: THEME.border,
  },
  outline: {
    backgroundColor: 'transparent',
    borderColor: THEME.border,
  },
  ghost: {
    backgroundColor: 'transparent',
    borderColor: 'transparent',
  },
  danger: {
    backgroundColor: 'rgba(255, 75, 75, 0.1)',
    borderColor: THEME.danger,
  },
  // Dynamic Sizes
  size_sm: {
    height: 44,
    paddingHorizontal: 20,
  },
  size_md: {
    height: 60, // Taller, more "Pro" feel
    paddingHorizontal: 28,
  },
  size_lg: {
    height: 72,
    paddingHorizontal: 36,
  },
  fullWidth: {
    width: '100%',
  },
  disabled: {
    opacity: 0.4,
  },
  // Typography (Owner "Heavy" Style)
  text: {
    fontWeight: '900', // Ultra-bold for high impact
    letterSpacing: -0.5,
    textTransform: 'uppercase', // Professional dashboard look
  },
  text_primary: {
    color: THEME.textDark,
  },
  text_secondary: {
    color: THEME.textMain,
  },
  text_outline: {
    color: THEME.textMain,
  },
  text_ghost: {
    color: THEME.primary,
  },
  text_danger: {
    color: THEME.danger,
  },
  textSize_sm: { fontSize: 12 },
  textSize_md: { fontSize: 15 },
  textSize_lg: { fontSize: 17 },
  iconBox: {
    marginHorizontal: 8,
  },
});

export default Button;