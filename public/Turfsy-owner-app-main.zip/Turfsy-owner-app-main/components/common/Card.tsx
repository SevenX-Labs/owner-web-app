import React from 'react';
import {
  View,
  StyleSheet,
  TouchableOpacity,
  ViewStyle,
  TouchableOpacityProps,
} from 'react-native';

// Turfsy Owner "Pro" Palette
const THEME = {
  background: '#000000',
  surface: '#1A1A1A',   // Dark grey surface for card depth
  primary: '#ADFF00',   // Volt Green
  border: '#262626',    // Subtle industrial border
  borderActive: '#333333',
};

interface CardProps extends TouchableOpacityProps {
  children: React.ReactNode;
  style?: ViewStyle | ViewStyle[];
  pressable?: boolean;
  variant?: 'default' | 'glossy' | 'flat' | 'outlined' | 'accent';
  padding?: 'none' | 'sm' | 'md' | 'lg';
}

const Card: React.FC<CardProps> = ({
  children,
  style,
  pressable = false,
  variant = 'default',
  padding = 'md',
  ...props
}) => {
  // Safe style concatenation for TypeScript
  const cardStyles: any[] = [
    styles.base,
    styles[variant as keyof typeof styles],
    styles[`padding_${padding}` as keyof typeof styles],
    style,
  ];

  if (pressable) {
    return (
      <TouchableOpacity 
        style={cardStyles} 
        activeOpacity={0.85} 
        {...props}
      >
        {children}
      </TouchableOpacity>
    );
  }

  return <View style={cardStyles}>{children}</View>;
};

const styles = StyleSheet.create({
  base: {
    backgroundColor: THEME.surface,
    borderRadius: 20, // Consistent with your "Booking Card" and "Venue Card"
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: THEME.border,
  },
  
  // Variants (Owner Pro Aesthetic)
  default: {
    backgroundColor: THEME.surface,
  },
  glossy: {
    backgroundColor: '#222222',
    borderColor: '#444',
  },
  flat: {
    backgroundColor: '#000000',
    borderColor: THEME.border,
  },
  outlined: {
    backgroundColor: 'transparent',
    borderColor: THEME.border,
    borderStyle: 'dashed', // Great for "Add Image" placeholders
  },
  accent: {
    borderColor: THEME.primary, // Volt Green border for selected/active states
    backgroundColor: THEME.surface,
  },

  // Padding
  padding_none: {
    padding: 0,
  },
  padding_sm: {
    padding: 12,
  },
  padding_md: {
    padding: 20,
  },
  padding_lg: {
    padding: 28,
  },
});

export default Card;