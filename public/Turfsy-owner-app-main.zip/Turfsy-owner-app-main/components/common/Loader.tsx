import React from 'react';
import {
  View,
  Text,
  ActivityIndicator,
  StyleSheet,
  Modal,
  ViewStyle,
  TextStyle,
} from 'react-native';

// Turfsy Owner "Pro" Palette
const THEME = {
  background: '#000000', // Pure Black
  surface: '#1A1A1A',   // Industrial grey surface
  primary: '#ADFF00',   // Volt Green
  border: '#262626',    // Industrial border
  textMuted: '#888888',
};

interface LoaderProps {
  variant?: 'fullscreen' | 'inline' | 'overlay';
  message?: string;
  color?: string;
  size?: 'small' | 'large';
}

const Loader: React.FC<LoaderProps> = ({
  variant = 'inline',
  message,
  color = THEME.primary,
  size = 'large',
}) => {
  const content = (
    <View style={styles.card}>
      <ActivityIndicator size={size} color={color} />
      {message && <Text style={styles.message}>{message.toUpperCase()}</Text>}
    </View>
  );

  if (variant === 'fullscreen') {
    return <View style={styles.fullscreen}>{content}</View>;
  }

  if (variant === 'overlay') {
    return (
      <Modal transparent visible animationType="fade">
        <View style={styles.overlay}>{content}</View>
      </Modal>
    );
  }

  // Inline
  return (
    <View style={styles.inline}>
      <ActivityIndicator size={size} color={color} />
      {message && <Text style={styles.message}>{message.toUpperCase()}</Text>}
    </View>
  );
};

const styles = StyleSheet.create({
  fullscreen: {
    flex: 1,
    backgroundColor: THEME.background,
    alignItems: 'center',
    justifyContent: 'center',
  } as ViewStyle,
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.85)', // Much darker, premium overlay
    alignItems: 'center',
    justifyContent: 'center',
  } as ViewStyle,
  card: {
    backgroundColor: THEME.surface,
    borderRadius: 24,
    padding: 32,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: THEME.border,
    minWidth: 140,
    gap: 16,
  } as ViewStyle,
  inline: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
    gap: 12,
  } as ViewStyle,
  message: {
    fontSize: 10,
    fontWeight: '900',
    color: THEME.primary, // Volt Green text for importance
    textAlign: 'center',
    letterSpacing: 1.5,
  } as TextStyle,
});

export default Loader;