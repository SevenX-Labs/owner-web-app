import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Platform,
  StatusBar,
  ViewStyle,
  TextStyle,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';

// Turfsy Owner "Pro" Palette
const THEME = {
  background: '#000000', // Pure Black
  surface: '#1A1A1A',   // Dark grey surface for buttons
  primary: '#ADFF00',   // Volt Green
  border: '#262626',    // Industrial border
  textMain: '#FFFFFF',
  textMuted: '#888888',
  textDark: '#000000',
};

interface HeaderAction {
  icon: keyof typeof Ionicons.glyphMap;
  onPress: () => void;
  badge?: number;
}

interface HeaderProps {
  title: string;
  subtitle?: string;
  showBack?: boolean;
  onBack?: () => void;
  actions?: HeaderAction[];
  transparent?: boolean;
}

const Header: React.FC<HeaderProps> = ({
  title,
  subtitle,
  showBack = false,
  onBack,
  actions = [],
  transparent = false,
}) => {
  const router = useRouter();

  const handleBack = () => {
    if (onBack) {
      onBack();
    } else {
      router.back();
    }
  };

  return (
    <View style={[styles.container, transparent && styles.transparent]}>
      <StatusBar barStyle="light-content" />
      <View style={styles.inner}>
        {/* Left Section */}
        <View style={styles.left}>
          {showBack && (
            <TouchableOpacity
              style={styles.backBtn}
              onPress={handleBack}
              activeOpacity={0.7}
            >
              <Ionicons name="arrow-back" size={24} color="#FFF" />
            </TouchableOpacity>
          )}
          <View style={styles.titleContainer}>
            {subtitle ? (
              <Text style={styles.subtitle}>{subtitle.toUpperCase()}</Text>
            ) : null}
            <Text style={styles.title} numberOfLines={1}>{title}</Text>
          </View>
        </View>

        {/* Right Actions */}
        <View style={styles.actions}>
          {actions.map((action, index) => (
            <TouchableOpacity
              key={index}
              style={styles.actionBtn}
              onPress={action.onPress}
              activeOpacity={0.7}
            >
              <Ionicons name={action.icon} size={22} color="#FFF" />
              {action.badge && action.badge > 0 ? (
                <View style={styles.badge}>
                  <Text style={styles.badgeText}>
                    {action.badge > 99 ? '99' : action.badge}
                  </Text>
                </View>
              ) : null}
            </TouchableOpacity>
          ))}
        </View>
      </View>
    </View>
  );
};

const STATUS_BAR_HEIGHT = Platform.OS === 'android' ? StatusBar.currentHeight ?? 24 : 44;

const styles = StyleSheet.create({
  container: {
    backgroundColor: THEME.background,
    paddingTop: STATUS_BAR_HEIGHT,
    borderBottomWidth: 1,
    borderBottomColor: THEME.border,
    zIndex: 10,
  } as ViewStyle,
  transparent: {
    backgroundColor: 'transparent',
    borderBottomWidth: 0,
  } as ViewStyle,
  inner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 14,
    minHeight: 70,
  } as ViewStyle,
  left: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    gap: 16,
  } as ViewStyle,
  backBtn: {
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: THEME.surface,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: THEME.border,
  } as ViewStyle,
  titleContainer: {
    flex: 1,
  } as ViewStyle,
  title: {
    fontSize: 24,
    fontWeight: '900', // Massive bold weight
    color: THEME.textMain,
    letterSpacing: -0.8,
  } as TextStyle,
  subtitle: {
    fontSize: 10,
    fontWeight: '900',
    color: THEME.primary, // Highlight subtitle in Volt Green
    letterSpacing: 1.5,
    marginBottom: 2,
  } as TextStyle,
  actions: {
    flexDirection: 'row',
    gap: 10,
  } as ViewStyle,
  actionBtn: {
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: THEME.surface,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: THEME.border,
  } as ViewStyle,
  badge: {
    position: 'absolute',
    top: -4,
    right: -4,
    backgroundColor: THEME.primary,
    borderRadius: 10,
    minWidth: 18,
    height: 18,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 2,
    borderWidth: 2,
    borderColor: THEME.background,
  } as ViewStyle,
  badgeText: {
    color: THEME.textDark,
    fontSize: 9,
    fontWeight: '900',
  } as TextStyle,
});

export default Header;