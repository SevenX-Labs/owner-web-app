import React from 'react';
import { View, Text, StyleSheet, ViewStyle, TextStyle } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAppTheme } from '@/src/hooks/useAppTheme';

interface SummaryCardProps {
  label: string;
  value: string | number;
  icon: keyof typeof Ionicons.glyphMap;
  change?: number;
  changeLabel?: string;
}

const SummaryCard: React.FC<SummaryCardProps> = ({
  label,
  value,
  icon,
  change,
  changeLabel,
}) => {
  const { theme } = useAppTheme();
  const isPositive = change !== undefined && change >= 0;

  return (
    <View style={[styles.container, {
      backgroundColor: theme.colors.surface,
      borderColor: theme.colors.cardBorder,
    }]}>
      {/* Top Section: Icon & Growth Indicator */}
      <View style={styles.headerRow}>
        <View style={[styles.iconBox, {
          backgroundColor: theme.colors.surfaceMuted,
          borderColor: theme.colors.border,
        }]}>
          <Ionicons name={icon} size={22} color={theme.colors.primary} />
        </View>

        {change !== undefined && (
          <View style={[
            styles.changeBadge,
            { backgroundColor: isPositive ? theme.colors.primarySoft : theme.colors.dangerSoft }
          ]}>
            <Ionicons
              name={isPositive ? 'trending-up' : 'trending-down'}
              size={12}
              color={isPositive ? theme.colors.primary : theme.colors.error}
            />
            <Text style={[styles.changeText, {
              color: isPositive ? theme.colors.primary : theme.colors.error,
              fontFamily: theme.fonts.black,
            }]}>
              {isPositive ? '+' : ''}{change}%
            </Text>
          </View>
        )}
      </View>

      {/* Value Section */}
      <View style={styles.content}>
        <Text style={[styles.valueText, {
          fontFamily: theme.fonts.black,
        }]} numberOfLines={1}>
          {value}
        </Text>
        <View style={styles.labelRow}>
          <Text style={[styles.labelText, {
            color: theme.colors.textMuted,
            fontFamily: theme.fonts.bold,
          }]}>{label.toUpperCase()}</Text>
          {changeLabel && (
            <Text style={[styles.subLabelText, {
              color: theme.colors.textMuted,
              fontFamily: theme.fonts.semiBold,
            }]}>• {changeLabel}</Text>
          )}
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    borderRadius: 24,
    padding: 20,
    flex: 1,
    minWidth: 165,
    borderWidth: 1,
  } as ViewStyle,
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  } as ViewStyle,
  iconBox: {
    width: 48,
    height: 48,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
  } as ViewStyle,
  changeBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 20,
    gap: 4,
  } as ViewStyle,
  changeText: {
    fontSize: 12,
  } as TextStyle,
  content: {
    gap: 4,
  } as ViewStyle,
  valueText: {
    fontSize: 32,
    color: '#FFF',
    letterSpacing: -1,
  } as TextStyle,
  labelRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  } as ViewStyle,
  labelText: {
    fontSize: 10,
    letterSpacing: 1.2,
  } as TextStyle,
  subLabelText: {
    fontSize: 10,
  } as TextStyle,
});

export default SummaryCard;