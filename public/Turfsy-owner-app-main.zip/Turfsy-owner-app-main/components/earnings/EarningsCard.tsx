import React from 'react';
import { View, Text, StyleSheet, ViewStyle, TextStyle } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Transaction } from '../../src/types/earnings.types';

// Turfsy Owner "Pro" Palette
const THEME = {
  background: '#000000', // Pure Black
  surface: '#1A1A1A',   // Industrial grey surface
  primary: '#ADFF00',   // Volt Green
  border: '#262626',    // Industrial border
  textMain: '#FFFFFF',
  textMuted: '#888888',
  error: '#FF4B4B',
  warning: '#FFB800',
};

interface EarningsCardProps {
  transaction: Transaction;
}

const statusConfig = {
  credited: { color: THEME.primary, icon: 'arrow-down-outline' as const, label: 'CREDITED' },
  pending: { color: THEME.warning, icon: 'time-outline' as const, label: 'PENDING' },
  refunded: { color: THEME.error, icon: 'arrow-up-outline' as const, label: 'REFUNDED' },
};

const EarningsCard: React.FC<EarningsCardProps> = ({ transaction }) => {
  const config = statusConfig[transaction.status];
  const isRefunded = transaction.status === 'refunded';

  return (
    <View style={styles.container}>
      {/* 1. Transaction Icon Box (Pure Black) */}
      <View style={[styles.iconBox, { borderColor: config.color + '30' }]}>
        <Ionicons name={config.icon} size={20} color={config.color} />
      </View>

      {/* 2. Middle Section: Customer & Metadata */}
      <View style={styles.infoSection}>
        <Text style={styles.customerName} numberOfLines={1}>
          {transaction.customerName}
        </Text>
        
        <View style={styles.metaRow}>
          <View style={styles.sportBadge}>
            <Text style={styles.sportText}>{transaction.sport.toUpperCase()}</Text>
          </View>
          <Text style={styles.bookingId}>#{transaction.bookingNumber}</Text>
        </View>
      </View>

      {/* 3. Right Section: Amount & Industrial Status */}
      <View style={styles.rightSection}>
        <Text style={[styles.amountText, { color: isRefunded ? THEME.error : '#FFF' }]}>
          {isRefunded ? '-' : '+'}{transaction.amount}
        </Text>

        <View style={[styles.statusTag, { borderColor: config.color + '40' }]}>
          <View style={[styles.statusDot, { backgroundColor: config.color }]} />
          <Text style={[styles.statusText, { color: config.color }]}>
            {config.label}
          </Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: THEME.surface,
    borderRadius: 20,
    padding: 16,
    marginHorizontal: 20,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: THEME.border,
    gap: 12,
  } as ViewStyle,
  iconBox: {
    width: 48,
    height: 48,
    borderRadius: 14,
    backgroundColor: '#000', // Inner black for high contrast
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
  } as ViewStyle,
  infoSection: {
    flex: 1,
    gap: 4,
  } as ViewStyle,
  customerName: {
    fontSize: 16,
    fontWeight: '800',
    color: '#FFF',
    letterSpacing: -0.4,
  } as TextStyle,
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  } as ViewStyle,
  sportBadge: {
    backgroundColor: '#000',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
    borderWidth: 1,
    borderColor: THEME.border,
  } as ViewStyle,
  sportText: {
    fontSize: 9,
    fontWeight: '900',
    color: THEME.textMuted,
    letterSpacing: 0.5,
  } as TextStyle,
  bookingId: {
    fontSize: 10,
    fontWeight: '600',
    color: THEME.textMuted,
  } as TextStyle,
  rightSection: {
    alignItems: 'flex-end',
    gap: 6,
  } as ViewStyle,
  amountText: {
    fontSize: 18,
    fontWeight: '900',
    letterSpacing: -0.5,
  } as TextStyle,
  statusTag: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 20,
    borderWidth: 1,
    gap: 5,
    backgroundColor: '#000', // Status badges sit on black for "Pro" feel
  } as ViewStyle,
  statusDot: {
    width: 5,
    height: 5,
    borderRadius: 2.5,
  } as ViewStyle,
  statusText: {
    fontSize: 8,
    fontWeight: '900',
    letterSpacing: 0.5,
  } as TextStyle,
});

export default EarningsCard;