import { Platform } from 'react-native';

// ─── Turfzy Owner 2026 Premium Palette ─────────────────────────────────────
const limeGreen = '#B8FF17';
const deepBlack = '#0C0D10';
const surfaceDark = '#181B20';
const borderDark = '#2A2F37';

export const Colors = {
  light: {
    text: '#FFFFFF',
    background: deepBlack,
    tint: limeGreen,
    icon: '#7D8592',
    tabIconDefault: '#8B9099',
    tabIconSelected: limeGreen,
    border: borderDark,
  },
  dark: {
    text: '#FFFFFF',
    background: deepBlack,
    surface: surfaceDark,
    tint: limeGreen,
    icon: '#7D8592',
    tabIconDefault: '#8B9099',
    tabIconSelected: limeGreen,
    border: borderDark,
    error: '#FF5D5D',
    success: '#2ED573',
    warning: '#FFC857',
  },
};

export const Fonts = Platform.select({
  ios: {
    sans: 'Geist_400Regular',
    medium: 'Geist_500Medium',
    semiBold: 'Geist_600SemiBold',
    bold: 'Geist_700Bold',
    extraBold: 'Geist_800ExtraBold',
    black: 'Geist_900Black',
    mono: 'Menlo',
  },
  android: {
    sans: 'Geist_400Regular',
    medium: 'Geist_500Medium',
    semiBold: 'Geist_600SemiBold',
    bold: 'Geist_700Bold',
    extraBold: 'Geist_800ExtraBold',
    black: 'Geist_900Black',
    mono: 'monospace',
  },
  default: {
    sans: 'Geist_400Regular',
    medium: 'Geist_500Medium',
    semiBold: 'Geist_600SemiBold',
    bold: 'Geist_700Bold',
    extraBold: 'Geist_800ExtraBold',
    black: 'Geist_900Black',
    mono: 'monospace',
  },
});