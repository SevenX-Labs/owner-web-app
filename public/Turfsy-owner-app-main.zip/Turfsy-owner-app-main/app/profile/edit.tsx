import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React, { useEffect, useState } from 'react';
import {
    ActivityIndicator,
    ScrollView,
    StatusBar,
    StyleSheet,
    Text,
    TextStyle,
    TouchableOpacity,
    View,
    ViewStyle,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import ProfileForm, { ProfileErrors, validateProfile } from '../../components/profile/ProfileForm';
import { useAuthContext } from '../../src/context/AuthContext';
import { useAppTheme } from '../../src/hooks/useAppTheme';
import { showWarning } from '../../src/components/ui/CustomAlert';
import { EMPTY_PROFILE, OwnerProfile } from '../../src/types/profile';
import { fp, hp, screenPadding, wp } from '../../src/utils/responsive';
import { getProfile, updateProfile } from '../../src/utils/storage';

const EditProfileScreen: React.FC = () => {
  const router = useRouter();
  const { user } = useAuthContext();
  const { theme, isDark } = useAppTheme();
  const THEME = theme.colors;
  const [profile, setProfile] = useState<OwnerProfile>(EMPTY_PROFILE);
  const [errors, setErrors]   = useState<ProfileErrors>({});
  const [loading, setLoading] = useState<boolean>(true);
  const [saving, setSaving]   = useState<boolean>(false);
  const [successMsg, setSuccessMsg] = useState<string>('');

  useEffect(() => {
      // Populate form with what we already have in context
    if (user) {
      setProfile((prev) => ({
        ...prev,
        ownerName: user.name !== undefined ? user.name : prev.ownerName,
        email: user.email !== undefined ? user.email : prev.email,
        phone: user.phone !== undefined ? user.phone : prev.phone,
        documents: {
          ...prev.documents,
          bank: {
            ...prev.documents?.bank,
            accountNumber: user.bankDetails?.accountNumber !== undefined ? user.bankDetails?.accountNumber : prev.documents?.bank?.accountNumber,
            ifsc: user.bankDetails?.ifscCode !== undefined ? user.bankDetails?.ifscCode : prev.documents?.bank?.ifsc,
            bankName: user.bankDetails?.bankName !== undefined ? user.bankDetails?.bankName : prev.documents?.bank?.bankName,
            bankHolderName: user.bankDetails?.accountHolderName !== undefined ? user.bankDetails?.accountHolderName : prev.documents?.bank?.bankHolderName,
          }
        }
      }));
    }

    getProfile()
      .then((saved) => {
        if (saved) {
          setProfile((prev) => ({
            ...prev,
            ...saved,
            ownerName: saved.ownerName !== undefined ? saved.ownerName : prev.ownerName,
            email: saved.email !== undefined ? saved.email : prev.email,
            phone: saved.phone !== undefined ? saved.phone : prev.phone,
            documents: {
              ...prev.documents,
              ...saved.documents,
              bank: {
                ...prev.documents?.bank,
                ...saved.documents?.bank,
                accountNumber: saved.documents?.bank?.accountNumber !== undefined ? saved.documents?.bank?.accountNumber : prev.documents?.bank?.accountNumber,
                ifsc: saved.documents?.bank?.ifsc !== undefined ? saved.documents?.bank?.ifsc : prev.documents?.bank?.ifsc,
                bankName: saved.documents?.bank?.bankName !== undefined ? saved.documents?.bank?.bankName : prev.documents?.bank?.bankName,
                bankHolderName: saved.documents?.bank?.bankHolderName !== undefined ? saved.documents?.bank?.bankHolderName : prev.documents?.bank?.bankHolderName,
                upi: saved.documents?.bank?.upi !== undefined ? saved.documents?.bank?.upi : prev.documents?.bank?.upi,
              }
            }
          }));
        }
      })
      .catch((e) => console.log('Profile loading fallback error:', e))
      .finally(() => setLoading(false));
  }, [user]);

  const handleSave = async (): Promise<void> => {
    const validationErrors = validateProfile(profile);
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      showWarning('Incomplete Profile', 'Please fix the highlighted fields.');
      return;
    }
    setErrors({});
    setSuccessMsg('');
    setSaving(true);
    try {
      await updateProfile(profile);
      setSuccessMsg('Your profile has been updated successfully!');
      setTimeout(() => {
        handleBack();
      }, 1500);
    } catch {
      setErrors({ ownerName: 'Failed to update profile. Please try again.' });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: THEME.background }]}>
        <ActivityIndicator color={THEME.primary} style={{ flex: 1 }} />
      </SafeAreaView>
    );
  }

  const handleBack = () => {
    if (router.canGoBack()) {
      router.back();
    } else {
      router.replace('/(tabs)/profile');
    }
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: THEME.background }]}>
      <StatusBar barStyle={isDark ? 'light-content' : 'dark-content'} />

      {/* Header */}
      <View style={[styles.header, { borderBottomColor: THEME.border }]}>
        <TouchableOpacity 
          style={[styles.backBtn, { backgroundColor: isDark ? 'rgba(255,255,255,0.05)' : THEME.surfaceMuted, borderColor: isDark ? 'rgba(255,255,255,0.1)' : THEME.border }]} 
          onPress={handleBack} 
          activeOpacity={0.7}
          hitSlop={{ top: 15, bottom: 15, left: 15, right: 15 }}
        >
          <Ionicons name="arrow-back" size={wp(22)} color={THEME.text} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: THEME.text }]}>Edit Profile</Text>
        <TouchableOpacity
          style={[styles.saveHeaderBtn, { backgroundColor: THEME.primary, shadowColor: THEME.primary }, saving && { opacity: 0.6 }]}
          onPress={handleSave}
          disabled={saving}
          activeOpacity={0.8}
        >
          {saving
            ? <ActivityIndicator color="#000" size="small" />
            : <Text style={styles.saveHeaderBtnText}>Save</Text>
          }
        </TouchableOpacity>
      </View>

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* Success Message Banner */}
        {!!successMsg && (
          <View style={[styles.successBanner, { backgroundColor: THEME.primary }]}>
            <Ionicons name="checkmark-circle" size={fp(18)} color="#000" />
            <Text style={styles.successBannerText}>{successMsg}</Text>
          </View>
        )}

        {/* Global Error Banner */}
        {!!errors.ownerName && errors.ownerName.includes('Failed') && (
          <View style={styles.errorBanner}>
            <Ionicons name="alert-circle" size={fp(18)} color="#FFF" />
            <Text style={styles.errorBannerText}>{errors.ownerName}</Text>
          </View>
        )}

        <ProfileForm profile={profile} errors={errors} onChange={setProfile} />

        {/* Bottom Save Button */}
        <TouchableOpacity
          style={[styles.saveBtn, { backgroundColor: THEME.primary, shadowColor: THEME.primary }, saving && { opacity: 0.7 }]}
          onPress={handleSave}
          disabled={saving}
          activeOpacity={0.85}
        >
          {saving ? (
            <ActivityIndicator color="#000" />
          ) : (
            <>
              <Text style={styles.saveBtnText}>Update Profile</Text>
              <Ionicons name="checkmark-circle" size={wp(22)} color="#000" />
            </>
          )}
        </TouchableOpacity>

        <View style={{ height: hp(40) }} />
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1 } as ViewStyle,
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: screenPadding,
    paddingVertical: hp(14),
    borderBottomWidth: 1,
  } as ViewStyle,
  backBtn: {
    width: wp(44),
    height: wp(44),
    borderRadius: wp(16),
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
  } as ViewStyle,
  headerTitle: { fontSize: fp(20), fontWeight: '900', letterSpacing: 0.5 } as TextStyle,
  saveHeaderBtn: {
    paddingHorizontal: wp(20),
    paddingVertical: hp(10),
    borderRadius: wp(24),
    minWidth: wp(64),
    alignItems: 'center',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
  } as ViewStyle,
  saveHeaderBtnText: { color: '#000', fontSize: fp(14), fontWeight: '900' } as TextStyle,
  scrollContent: { paddingHorizontal: screenPadding, paddingTop: hp(24) } as ViewStyle,
  saveBtn: {
    height: hp(65),
    borderRadius: wp(24),
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: wp(10),
    marginTop: hp(32),
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.2,
    shadowRadius: 10,
    elevation: 6,
  } as ViewStyle,
  saveBtnText: { color: '#000', fontSize: fp(18), fontWeight: '900' } as TextStyle,
  successBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: wp(14),
    borderRadius: wp(12),
    marginBottom: hp(16),
    gap: wp(8),
  } as ViewStyle,
  successBannerText: { color: '#000', fontSize: fp(14), fontWeight: '700' } as TextStyle,
  errorBanner: {
    backgroundColor: '#FF4444',
    flexDirection: 'row',
    alignItems: 'center',
    padding: wp(14),
    borderRadius: wp(12),
    marginBottom: hp(16),
    gap: wp(8),
  } as ViewStyle,
  errorBannerText: { color: '#FFF', fontSize: fp(14), fontWeight: '700' } as TextStyle,
});

export default EditProfileScreen;
