import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  StatusBar,
  ViewStyle,
  TextStyle,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAppTheme } from '../../src/hooks/useAppTheme';
import { showSuccess } from '../../src/components/ui/CustomAlert';


const DEFAULT_SETTINGS = {
  newBooking: true,
  cancellation: true,
  payment: true,
  reminders: false,
  soundEnabled: true,
};

export default function SettingsScreen() {
  const router = useRouter();
  const { theme, mode, setMode } = useAppTheme();
  const styles = getStyles(theme);
  const THEME = theme;
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);

  const toggle = (key: keyof typeof settings) => {
    setSettings((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const handleSave = () => {
    showSuccess('Success', 'Preferences updated.');
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" />

      {/* Branded Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color={THEME.colors.text} />
        </TouchableOpacity>
        <View>
          <Text style={styles.headerLabel}>APP CONFIGURATION</Text>
          <Text style={styles.headerTitle}>Settings</Text>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        
        {/* Section 1: Notifications */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>NOTIFICATIONS</Text>
          <View style={styles.menuGroup}>
            <SettingRow
              icon="calendar-outline"
              label="New Bookings"
              sub="Instant alerts for every new slot booked"
              value={settings.newBooking}
              onToggle={() => toggle('newBooking')}
              THEME={THEME}
              styles={styles}
            />
            <SettingRow
              icon="close-circle-outline"
              label="Cancellations"
              sub="Notify when players cancel a slot"
              value={settings.cancellation}
              onToggle={() => toggle('cancellation')}
              THEME={THEME}
              styles={styles}
            />
            <SettingRow
              icon="card-outline"
              label="Payment Updates"
              sub="Confirmations for UPI settlements"
              value={settings.payment}
              onToggle={() => toggle('payment')}
              THEME={THEME}
              styles={styles}
            />
            <SettingRow
              icon="alarm-outline"
              label="Slot Reminders"
              sub="Alert 30 mins before every match"
              value={settings.reminders}
              onToggle={() => toggle('reminders')}
              isLast
              THEME={THEME}
              styles={styles}
            />
          </View>
        </View>

        {/* Section 2: Appearance */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>APPEARANCE</Text>
          <View style={styles.menuGroup}>
            <View style={styles.themeToggleRow}>
              <View style={styles.themeInfo}>
                <Text style={styles.label}>App Theme</Text>
                <Text style={styles.subText}>Select your preferred mode</Text>
              </View>
              <View style={styles.themeSelector}>
                <TouchableOpacity 
                  style={[styles.themeOption, mode === 'system' && styles.themeOptionActive]}
                  onPress={() => setMode('system')}
                >
                  <Ionicons name="settings-outline" size={16} color={mode === 'system' ? '#000' : THEME.colors.textMuted} />
                  <Text style={[styles.themeOptionText, mode === 'system' && styles.themeOptionTextActive]}>Auto</Text>
                </TouchableOpacity>
                <TouchableOpacity 
                  style={[styles.themeOption, mode === 'light' && styles.themeOptionActive]}
                  onPress={() => setMode('light')}
                >
                  <Ionicons name="sunny-outline" size={16} color={mode === 'light' ? '#000' : THEME.colors.textMuted} />
                  <Text style={[styles.themeOptionText, mode === 'light' && styles.themeOptionTextActive]}>Light</Text>
                </TouchableOpacity>
                <TouchableOpacity 
                  style={[styles.themeOption, mode === 'dark' && styles.themeOptionActive]}
                  onPress={() => setMode('dark')}
                >
                  <Ionicons name="moon-outline" size={16} color={mode === 'dark' ? '#000' : THEME.colors.textMuted} />
                  <Text style={[styles.themeOptionText, mode === 'dark' && styles.themeOptionTextActive]}>Dark</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </View>

        {/* Section 3: Preferences */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>PREFERENCES</Text>
          <View style={styles.menuGroup}>
            <SettingRow
              icon="volume-high-outline"
              label="UI Sound Effects"
              sub="Feedback for booking confirmations"
              value={settings.soundEnabled}
              onToggle={() => toggle('soundEnabled')}
              isLast
              THEME={THEME}
              styles={styles}
            />
          </View>
        </View>

        {/* Save Action */}
        <View style={styles.footer}>
          <TouchableOpacity style={styles.saveBtn} onPress={handleSave} activeOpacity={0.8}>
            <Text style={styles.saveBtnText}>Save Changes</Text>
            <Ionicons name="save-outline" size={20} color="#000" />
          </TouchableOpacity>
        </View>

      </ScrollView>
    </SafeAreaView>
  );
}

// Sub-component for individual setting rows
const SettingRow = ({ icon, label, sub, value, onToggle, isLast, THEME, styles }: any) => (
  <View style={[styles.row, !isLast && styles.rowBorder]}>
    <View style={styles.iconBox}>
      <Ionicons name={icon} size={20} color={THEME.colors.primary} />
    </View>
    <View style={styles.info}>
      <Text style={styles.label}>{label}</Text>
      <Text style={styles.subText}>{sub}</Text>
    </View>
    <Switch
      value={value}
      onValueChange={onToggle}
      trackColor={{ false: THEME.colors.surfaceMuted, true: THEME.colors.primary }}
      thumbColor={THEME.colors.background}
      ios_backgroundColor={THEME.colors.surfaceMuted}
    />
  </View>
);

const getStyles = (THEME: any) => StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: THEME.colors.background,
  } as ViewStyle,
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: THEME.border,
  } as ViewStyle,
  backBtn: {
    width: 44,
    height: 44,
    borderRadius: 16,
    backgroundColor: THEME.colors.surfaceMuted || 'rgba(128,128,128,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
    borderWidth: 1,
    borderColor: THEME.colors.border,
  } as ViewStyle,
  headerLabel: {
    color: THEME.colors.textMuted,
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.5,
  } as TextStyle,
  headerTitle: {
    color: THEME.colors.text,
    fontSize: 24,
    fontWeight: '900',
  } as TextStyle,
  content: {
    padding: 24,
  } as ViewStyle,
  section: {
    marginBottom: 30,
  } as ViewStyle,
  sectionTitle: {
    color: THEME.colors.textMuted,
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.5,
    marginBottom: 15,
    marginLeft: 4,
  } as TextStyle,
  menuGroup: {
    backgroundColor: THEME.colors.surface,
    borderRadius: 24,
    borderWidth: 1,
    borderColor: THEME.colors.border,
    overflow: 'hidden',
  } as ViewStyle,
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 20,
  } as ViewStyle,
  rowBorder: {
    borderBottomWidth: 1,
    borderBottomColor: THEME.colors.border,
  } as ViewStyle,
  iconBox: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: THEME.colors.surfaceMuted || '#262626',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
    borderWidth: 1,
    borderColor: THEME.colors.border,
  } as ViewStyle,
  info: {
    flex: 1,
  } as ViewStyle,
  label: {
    color: THEME.colors.text,
    fontSize: 15,
    fontWeight: '700',
  } as TextStyle,
  subText: {
    color: THEME.colors.textMuted,
    fontSize: 12,
    marginTop: 4,
    fontWeight: '500',
  } as TextStyle,
  footer: {
    marginTop: 10,
    paddingBottom: 40,
  } as ViewStyle,
  saveBtn: {
    backgroundColor: THEME.colors.primary,
    height: 65,
    borderRadius: 24,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 10,
    shadowColor: THEME.colors.primary,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.2,
    shadowRadius: 10,
    elevation: 6,
  } as ViewStyle,
  saveBtnText: {
    color: THEME.colors.background,
    fontSize: 18,
    fontWeight: '900',
  } as TextStyle,
  themeToggleRow: {
    padding: 20,
    gap: 16,
  } as ViewStyle,
  themeInfo: {
    marginBottom: 4,
  } as ViewStyle,
  themeSelector: {
    flexDirection: 'row',
    backgroundColor: THEME.colors.background,
    borderRadius: 16,
    padding: 6,
    gap: 6,
    borderWidth: 1,
    borderColor: THEME.colors.border,
  } as ViewStyle,
  themeOption: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderRadius: 12,
    gap: 6,
  } as ViewStyle,
  themeOptionActive: {
    backgroundColor: THEME.colors.primary,
  } as ViewStyle,
  themeOptionText: {
    color: THEME.colors.textMuted,
    fontSize: 14,
    fontWeight: '700',
  } as TextStyle,
  themeOptionTextActive: {
    color: '#000000', // Always pure black against primary volt
  } as TextStyle,
});