import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  StatusBar,
  ViewStyle,
  TextStyle,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAppTheme } from '../../src/hooks/useAppTheme';
import { showWarning, showSuccess } from '../../src/components/ui/CustomAlert';

const SUPPORT_CATEGORIES = ['Booking Issue', 'Payment Query', 'App Feedback', 'Other'];

export default function SupportScreen() {
  const router = useRouter();
  const { theme, isDark } = useAppTheme();
  const THEME = theme.colors;
  const [subject, setSubject] = useState('');
  const [description, setDescription] = useState('');
  const [selectedCategory, setSelectedCategory] = useState(SUPPORT_CATEGORIES[0]);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (): Promise<void> => {
    if (!subject.trim() || !description.trim()) {
      showWarning('Incomplete', 'Please fill in all required fields.');
      return;
    }
    setLoading(true);
    
    // Simulate API Call
    setTimeout(() => {
      setLoading(false);
      showSuccess(
        'Ticket Created', 
        'Our support team will contact you within 2-4 hours.',
        [{ text: 'DONE', onPress: () => router.back() }]
      );
    }, 1500);
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: THEME.background }]}>
      <StatusBar barStyle={isDark ? 'light-content' : 'dark-content'} />

      {/* Branded Header */}
      <View style={[styles.header, { borderBottomColor: THEME.border }]}>
        <TouchableOpacity onPress={() => router.back()} style={[styles.backBtn, { backgroundColor: isDark ? 'rgba(255,255,255,0.05)' : THEME.surfaceMuted, borderColor: isDark ? 'rgba(255,255,255,0.1)' : THEME.border }]}>
          <Ionicons name="arrow-back" size={24} color={THEME.text} />
        </TouchableOpacity>
        <View>
          <Text style={[styles.headerLabel, { color: THEME.textMuted }]}>CUSTOMER CARE</Text>
          <Text style={[styles.headerTitle, { color: THEME.text }]}>Help Center</Text>
        </View>
      </View>

      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'} 
        style={{ flex: 1 }}
      >
        <ScrollView 
          showsVerticalScrollIndicator={false} 
          contentContainerStyle={styles.content}
          keyboardShouldPersistTaps="handled"
        >
          {/* Pro Support Card */}
          <View style={[styles.supportCard, { backgroundColor: THEME.surface, borderColor: THEME.border }]}>
            <View style={[styles.iconBox, { backgroundColor: THEME.background, borderColor: THEME.border }]}>
              <Ionicons name="headset-outline" size={28} color={THEME.primary} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.cardInfoTitle, { color: THEME.text }]}>24/7 Support Desk</Text>
              <Text style={[styles.cardInfoSub, { color: THEME.textMuted }]}>Dedicated assistance for arena owners.</Text>
            </View>
          </View>

          {/* Category Selector */}
          <View style={styles.section}>
            <Text style={[styles.sectionLabel, { color: THEME.primary }]}>SELECT CATEGORY</Text>
            <View style={styles.categoryGrid}>
              {SUPPORT_CATEGORIES.map((cat) => {
                const isActive = selectedCategory === cat;
                return (
                  <TouchableOpacity
                    key={cat}
                    style={[styles.chip, { backgroundColor: THEME.surface, borderColor: THEME.border }, isActive && { backgroundColor: THEME.primary, borderColor: THEME.primary }]}
                    onPress={() => setSelectedCategory(cat)}
                  >
                    <Text style={[styles.chipText, { color: THEME.textMuted }, isActive && styles.chipTextActive]}>
                      {cat}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>

          {/* Issue Form */}
          <View style={styles.section}>
            <Text style={[styles.sectionLabel, { color: THEME.primary }]}>ISSUE DETAILS</Text>
            
            <View style={styles.field}>
              <Text style={[styles.inputLabel, { color: THEME.textMuted }]}>SUBJECT</Text>
              <TextInput
                style={[styles.input, { backgroundColor: isDark ? 'rgba(255,255,255,0.04)' : THEME.surfaceMuted, color: THEME.text, borderColor: THEME.border }]}
                placeholder="What are you facing issues with?"
                placeholderTextColor={THEME.textMuted}
                value={subject}
                onChangeText={setSubject}
                selectionColor={THEME.primary}
              />
            </View>

            <View style={styles.field}>
              <Text style={[styles.inputLabel, { color: THEME.textMuted }]}>DESCRIPTION</Text>
              <TextInput
                style={[styles.input, styles.textarea, { backgroundColor: isDark ? 'rgba(255,255,255,0.04)' : THEME.surfaceMuted, color: THEME.text, borderColor: THEME.border }]}
                placeholder="Describe your concern in detail..."
                placeholderTextColor={THEME.textMuted}
                value={description}
                onChangeText={setDescription}
                multiline
                numberOfLines={6}
                textAlignVertical="top"
                selectionColor={THEME.primary}
              />
            </View>
          </View>

          {/* Submit Button */}
          <TouchableOpacity
            style={[styles.submitBtn, { backgroundColor: THEME.primary, shadowColor: THEME.primary }, loading && { opacity: 0.6 }]}
            onPress={handleSubmit}
            disabled={loading}
            activeOpacity={0.8}
          >
            <Text style={styles.submitBtnText}>
              {loading ? 'CREATING TICKET...' : 'SUBMIT REQUEST'}
            </Text>
            <Ionicons name="send" size={18} color="#000" />
          </TouchableOpacity>

          <View style={{ height: 40 }} />
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  } as ViewStyle,
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 14,
    borderBottomWidth: 1,
  } as ViewStyle,
  backBtn: {
    width: 44,
    height: 44,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
    borderWidth: 1,
  } as ViewStyle,
  headerLabel: {
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.5,
  } as TextStyle,
  headerTitle: {
    fontSize: 24,
    fontWeight: '900',
  } as TextStyle,
  content: {
    padding: 24,
  } as ViewStyle,
  supportCard: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 24,
    padding: 20,
    borderWidth: 1,
    marginBottom: 30,
    gap: 16,
  } as ViewStyle,
  iconBox: {
    width: 60,
    height: 60,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
  } as ViewStyle,
  cardInfoTitle: {
    fontSize: 18,
    fontWeight: '800',
  } as TextStyle,
  cardInfoSub: {
    fontSize: 12,
    fontWeight: '500',
    marginTop: 2,
  } as TextStyle,
  section: {
    marginBottom: 30,
  } as ViewStyle,
  sectionLabel: {
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 2,
    marginBottom: 15,
    marginLeft: 4,
  } as TextStyle,
  categoryGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  } as ViewStyle,
  chip: {
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderRadius: 24,
    borderWidth: 1,
  } as ViewStyle,
  chipText: {
    fontSize: 14,
    fontWeight: '700',
  } as TextStyle,
  chipTextActive: {
    color: '#000',
    fontWeight: '800',
  } as TextStyle,
  field: {
    marginBottom: 20,
  } as ViewStyle,
  inputLabel: {
    fontSize: 9,
    fontWeight: '800',
    letterSpacing: 1,
    marginBottom: 8,
    marginLeft: 4,
  } as TextStyle,
  input: {
    fontSize: 15,
    fontWeight: '700',
    height: 60,
    borderRadius: 20,
    paddingHorizontal: 20,
    paddingVertical: 0,
    borderWidth: 1.5,
    justifyContent: 'center',
  } as TextStyle,
  textarea: {
    height: 150,
    paddingTop: 18,
  } as TextStyle,
  submitBtn: {
    height: 65,
    borderRadius: 24,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
    marginTop: 10,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.2,
    shadowRadius: 10,
    elevation: 6,
  } as ViewStyle,
  submitBtnText: {
    color: '#000',
    fontSize: 18,
    fontWeight: '900',
  } as TextStyle,
});