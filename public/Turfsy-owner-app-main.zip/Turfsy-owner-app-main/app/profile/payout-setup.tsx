import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useRouter } from 'expo-router';
import React, { useEffect, useState } from 'react';
import {
  ActivityIndicator,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import InputField from '../../components/profile/InputField';
import { useAppTheme } from '../../src/hooks/useAppTheme';
import { fp, hp, screenPadding, wp } from '../../src/utils/responsive';
import { STORAGE_KEYS } from '../../src/utils/constants';

interface PayoutSettings {
  bankHolderName: string;
  bankName: string;
  accountNumber: string;
  confirmAccountNumber: string;
  ifscCode: string;
  accountType: 'SAVINGS' | 'CURRENT';
}

export default function PayoutSetupScreen() {
  const router = useRouter();
  const { theme, isDark } = useAppTheme();
  const THEME = theme.colors;

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [errors, setErrors] = useState<Partial<PayoutSettings>>({});
  
  const [formData, setFormData] = useState<PayoutSettings>({
    bankHolderName: '',
    bankName: '',
    accountNumber: '',
    confirmAccountNumber: '',
    ifscCode: '',
    accountType: 'SAVINGS'
  });

  useEffect(() => {
    fetchCurrentSettings();
  }, []);

  const fetchCurrentSettings = async () => {
    try {
      const token = await AsyncStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
      if (!token) return;

      const res = await fetch('https://turfsy.onrender.com/api/v3/owner-settlements/summary', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      
      if (data.success && data.data?.bankDetails) {
        const details = data.data.bankDetails;
        setFormData(prev => {
          const accNum = details.accountNumber || '';
          // If it's masked (contains *), do not pre-fill it, force re-entry.
          const isMasked = accNum.includes('*');
          return {
            ...prev,
            bankHolderName: details.bankHolderName || '',
            bankName: details.bankName || '',
            accountNumber: isMasked ? '' : accNum.replace(/\D/g, ''),
            confirmAccountNumber: isMasked ? '' : accNum.replace(/\D/g, ''),
            ifscCode: details.ifscCode || '',
            accountType: details.accountType || 'SAVINGS',
          };
        });
      }
    } catch (e) {
      console.warn(e);
    } finally {
      setLoading(false);
    }
  };

  const validate = () => {
    const errs: Partial<PayoutSettings> = {};
    if (!formData.bankHolderName?.trim()) errs.bankHolderName = 'Account holder name is required';
    else if (!/^[A-Za-z .\-]+$/.test(formData.bankHolderName)) errs.bankHolderName = 'Only alphabets, spaces and dots allowed';
    
    if (!formData.bankName?.trim()) errs.bankName = 'Bank name is required';
    else if (!/^[A-Za-z &]+$/.test(formData.bankName)) errs.bankName = 'Only alphabets, spaces and & allowed';
    
    if (!formData.accountNumber?.trim()) errs.accountNumber = 'Account number is required';
    else if (!/^\d{9,18}$/.test(formData.accountNumber)) errs.accountNumber = 'Invalid account number (9-18 digits)';
    
    if (formData.accountNumber !== formData.confirmAccountNumber) {
      errs.confirmAccountNumber = 'Account numbers do not match';
    }

    if (!formData.ifscCode?.trim()) errs.ifscCode = 'IFSC code is required';
    else if (!/^[A-Z]{4}0[A-Z0-9]{6}$/.test(formData.ifscCode.toUpperCase())) errs.ifscCode = 'Invalid IFSC format (e.g. HDFC0001234)';
    
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSave = async () => {
    if (!validate()) return;
    
    setSaving(true);
    setSuccessMsg('');
    try {
      const token = await AsyncStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
      const payload = {
        bankHolderName: formData.bankHolderName,
        bankName: formData.bankName,
        accountNumber: formData.accountNumber,
        confirmAccountNumber: formData.confirmAccountNumber,
        ifscCode: formData.ifscCode.toUpperCase(),
        accountType: formData.accountType
      };

      const res = await fetch('https://turfsy.onrender.com/api/v3/owner-settings/payout', {
        method: 'PATCH',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      if (!res.ok) throw new Error('Update failed');
      
      setSuccessMsg('Payout settings updated successfully!');
      setTimeout(() => {
        if (router.canGoBack()) router.back();
        else router.replace('/earnings');
      }, 1500);
    } catch (e) {
      console.warn(e);
      setErrors({ bankHolderName: 'Failed to update settings. Try again.' });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: THEME.background }]}>
        <ActivityIndicator color={THEME.primary} style={{ flex: 1 }} />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: THEME.background }]}>
      <StatusBar barStyle={isDark ? 'light-content' : 'dark-content'} />

      <View style={[styles.header, { borderBottomColor: THEME.border }]}>
        <TouchableOpacity 
          style={[styles.backBtn, { backgroundColor: isDark ? 'rgba(255,255,255,0.05)' : THEME.surfaceMuted, borderColor: isDark ? 'rgba(255,255,255,0.1)' : THEME.border }]} 
          onPress={() => router.back()}
        >
          <Ionicons name="arrow-back" size={wp(22)} color={THEME.text} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: THEME.text }]}>Payout Setup</Text>
        <View style={{ width: wp(44) }} />
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent} keyboardShouldPersistTaps="handled">
        {!!successMsg && (
          <View style={[styles.successBanner, { backgroundColor: THEME.primary }]}>
            <Ionicons name="checkmark-circle" size={fp(18)} color="#000" />
            <Text style={styles.successBannerText}>{successMsg}</Text>
          </View>
        )}

        <View style={styles.formGap}>
          <InputField
            label="ACCOUNT HOLDER NAME"
              value={formData.bankHolderName}
              onChangeText={(v) => setFormData({ ...formData, bankHolderName: v })}
              placeholder="As per bank records"
              error={errors.bankHolderName}
            />
            <InputField
              label="BANK NAME"
              value={formData.bankName}
              onChangeText={(v) => setFormData({ ...formData, bankName: v })}
              placeholder="e.g. HDFC Bank"
              error={errors.bankName}
            />
            <InputField
              label="ACCOUNT NUMBER"
              value={formData.accountNumber}
              onChangeText={(v) => setFormData({ ...formData, accountNumber: v.replace(/\D/g, '') })}
              placeholder="9-18 digit account number"
              error={errors.accountNumber}
              keyboardType="number-pad"
            />
            <InputField
              label="CONFIRM ACCOUNT NUMBER"
              value={formData.confirmAccountNumber}
              onChangeText={(v) => setFormData({ ...formData, confirmAccountNumber: v.replace(/\D/g, '') })}
              placeholder="Re-enter account number"
              error={errors.confirmAccountNumber}
              keyboardType="number-pad"
            />
            <InputField
              label="IFSC CODE"
              value={formData.ifscCode}
              onChangeText={(v) => setFormData({ ...formData, ifscCode: v.toUpperCase() })}
              placeholder="e.g. HDFC0001234"
              error={errors.ifscCode}
              autoCapitalize="characters"
            />
            
            <View>
              <Text style={[styles.label, { color: THEME.text }]}>ACCOUNT TYPE</Text>
              <View style={styles.methodToggle}>
                <TouchableOpacity 
                  style={[styles.toggleBtn, formData.accountType === 'SAVINGS' && { backgroundColor: THEME.surfaceMuted, borderColor: THEME.primary, borderWidth: 1 }]}
                  onPress={() => setFormData({ ...formData, accountType: 'SAVINGS' })}
                >
                  <Text style={[styles.toggleText, { color: formData.accountType === 'SAVINGS' ? THEME.text : THEME.textMuted }]}>SAVINGS</Text>
                </TouchableOpacity>
                <TouchableOpacity 
                  style={[styles.toggleBtn, formData.accountType === 'CURRENT' && { backgroundColor: THEME.surfaceMuted, borderColor: THEME.primary, borderWidth: 1 }]}
                  onPress={() => setFormData({ ...formData, accountType: 'CURRENT' })}
                >
                  <Text style={[styles.toggleText, { color: formData.accountType === 'CURRENT' ? THEME.text : THEME.textMuted }]}>CURRENT</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>

        <TouchableOpacity
          style={[styles.saveBtn, { backgroundColor: THEME.primary }, saving && { opacity: 0.7 }]}
          onPress={handleSave}
          disabled={saving}
        >
          {saving ? (
            <ActivityIndicator color="#000" />
          ) : (
            <Text style={styles.saveBtnText}>Save Payout Settings</Text>
          )}
        </TouchableOpacity>
        
        <View style={{ height: hp(60) }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: screenPadding,
    paddingVertical: hp(14),
    borderBottomWidth: 1,
  },
  backBtn: {
    width: wp(44),
    height: wp(44),
    borderRadius: wp(16),
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
  },
  headerTitle: { fontSize: fp(18), fontWeight: '900' },
  scrollContent: { paddingHorizontal: screenPadding, paddingTop: hp(24) },
  methodToggle: {
    flexDirection: 'row',
    backgroundColor: 'rgba(128,128,128,0.1)',
    borderRadius: wp(12),
    padding: wp(4),
    marginBottom: hp(24),
  },
  toggleBtn: {
    flex: 1,
    paddingVertical: hp(12),
    alignItems: 'center',
    borderRadius: wp(10),
  },
  toggleText: {
    fontWeight: '800',
    fontSize: fp(13),
  },
  formGap: {
    gap: hp(18),
  },
  label: {
    fontSize: fp(11),
    fontWeight: '800',
    marginBottom: hp(8),
    letterSpacing: 0.5,
  },
  saveBtn: {
    height: hp(60),
    borderRadius: wp(16),
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: hp(32),
  },
  saveBtnText: {
    color: '#000',
    fontSize: fp(16),
    fontWeight: '900',
  },
  successBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: wp(14),
    borderRadius: wp(12),
    marginBottom: hp(16),
    gap: wp(8),
  },
  successBannerText: { color: '#000', fontSize: fp(14), fontWeight: '700' },
});
