import { Ionicons } from '@expo/vector-icons';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { useRouter } from 'expo-router';
import React, { useState, useEffect, useRef } from 'react';
import { ActivityIndicator, StyleSheet, Text, TouchableOpacity, View, TextInput, KeyboardAvoidingView, Platform, ScrollView, Animated } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { useAppTheme } from '@/src/hooks/useAppTheme';
import { useResponsive } from '@/src/utils/responsive';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { STORAGE_KEYS } from '@/src/utils/constants';

const MANUAL_REASONS = [
  'Scanner Not Working',
  'Camera Issue',
  'Technical Issue',
  'Other'
];

export default function ScannerScreen() {
  const [permission, requestPermission] = useCameraPermissions();
  const [scanned, setScanned] = useState(false);
  const [loading, setLoading] = useState(false);
  const [resultMessage, setResultMessage] = useState<string | null>(null);
  
  const [isManualMode, setIsManualMode] = useState(false);
  const [bookingId, setBookingId] = useState('');
  const [selectedReason, setSelectedReason] = useState<string | null>(null);

  const scanAnim = useRef(new Animated.Value(0)).current;
  const popAnim = useRef(new Animated.Value(0)).current;

  const router = useRouter();
  const { theme } = useAppTheme();
  const responsive = useResponsive();
  const styles = getStyles(theme, responsive);

  useEffect(() => {
    if (resultMessage === 'SUCCESS') {
      Animated.spring(popAnim, {
        toValue: 1,
        tension: 80,
        friction: 8,
        useNativeDriver: true,
      }).start();
    } else {
      popAnim.setValue(0);
    }
  }, [resultMessage]);

  useEffect(() => {
    if (permission && !permission.granted && permission.canAskAgain === false) {
      setIsManualMode(true);
    }
  }, [permission]);

  useEffect(() => {
    if (!isManualMode && permission?.granted) {
      const animation = Animated.loop(
        Animated.sequence([
          Animated.timing(scanAnim, {
            toValue: 1,
            duration: 2500,
            useNativeDriver: true,
          }),
          Animated.timing(scanAnim, {
            toValue: 0,
            duration: 2500,
            useNativeDriver: true,
          })
        ])
      );
      animation.start();
      return () => animation.stop();
    }
  }, [isManualMode, permission, scanAnim]);

  if (!permission) {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color={theme.colors.primary} />
      </View>
    );
  }

  if (!permission.granted && !isManualMode) {
    return (
      <View style={styles.centerContainer}>
        <Ionicons name="camera-outline" size={64} color={theme.colors.textMuted} style={{ marginBottom: 16 }} />
        <Text style={styles.permissionText}>We need your permission to show the camera for QR Check-in.</Text>
        <TouchableOpacity style={styles.primaryButton} onPress={requestPermission}>
          <Text style={styles.primaryButtonText}>Grant Permission</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.secondaryButton, { marginTop: 20 }]} onPress={() => setIsManualMode(true)}>
          <Text style={styles.secondaryButtonText}>Use Manual Override</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const handleBarCodeScanned = async ({ type, data }: { type: string; data: string }) => {
    if (scanned) return;
    setScanned(true);
    setLoading(true);
    setResultMessage(null);

    try {
      const token = await AsyncStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
      if (!token) throw new Error("No auth token");

      const res = await fetch(`https://turfsy.onrender.com/api/v3/booking/verify-qr`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ qrData: data }),
      });

      const resData = await res.json();
      
      if (res.ok && resData.success) {
        setResultMessage('SUCCESS');
        setTimeout(() => {
          router.back();
        }, 1500);
      } else {
        setResultMessage(resData.message || 'Invalid QR Code or Booking too early (must be within 10 mins).');
      }
    } catch (error: any) {
      setResultMessage(error.message || 'An error occurred during scan.');
    } finally {
      setLoading(false);
    }
  };

  const handleManualCheckIn = async () => {
    if (!bookingId.trim() || !selectedReason) return;
    
    setLoading(true);
    setResultMessage(null);

    try {
      const token = await AsyncStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
      if (!token) throw new Error("No auth token");

      const res = await fetch(`https://turfsy.onrender.com/api/v3/booking/${bookingId.trim()}/manual-checkin`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ reason: selectedReason }),
      });

      const resData = await res.json();
      
      if (res.ok && resData.success) {
        setResultMessage('SUCCESS');
        setTimeout(() => {
          router.back();
        }, 1500);
      } else {
        setResultMessage(resData.message || 'Failed to process manual check-in.');
      }
    } catch (error: any) {
      setResultMessage(error.message || 'An error occurred.');
    } finally {
      setLoading(false);
    }
  };

  const renderManualMode = () => (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
      <ScrollView contentContainerStyle={styles.manualContainer} keyboardShouldPersistTaps="handled">
        <View style={styles.header}>
          <TouchableOpacity onPress={() => permission?.granted ? setIsManualMode(false) : router.back()} style={styles.backButton}>
            <Ionicons name="arrow-back" size={24} color="#FFFFFF" />
          </TouchableOpacity>
          <Text style={styles.title}>Manual Check-in</Text>
          <View style={{ width: 44 }} />
        </View>

        <View style={styles.manualForm}>
          <Text style={styles.inputLabel}>BOOKING ID</Text>
          <TextInput
            style={styles.input}
            placeholder="Paste or type UUID here..."
            placeholderTextColor={theme.colors.textMuted}
            value={bookingId}
            onChangeText={setBookingId}
            autoCapitalize="none"
            autoCorrect={false}
          />

          <Text style={[styles.inputLabel, { marginTop: 24 }]}>REASON FOR MANUAL OVERRIDE</Text>
          <View style={styles.chipContainer}>
            {MANUAL_REASONS.map(reason => (
              <TouchableOpacity
                key={reason}
                style={[
                  styles.chip,
                  selectedReason === reason && styles.chipActive
                ]}
                onPress={() => setSelectedReason(reason)}
                activeOpacity={0.7}
              >
                <Text style={[
                  styles.chipText,
                  selectedReason === reason && styles.chipTextActive
                ]}>{reason}</Text>
              </TouchableOpacity>
            ))}
          </View>

          {resultMessage && resultMessage !== 'SUCCESS' && (
            <View style={[styles.resultBox, { backgroundColor: 'rgba(239, 68, 68, 0.1)' }]}>
              <Text style={[styles.resultText, { color: '#EF4444' }]}>
                {resultMessage}
              </Text>
            </View>
          )}

          <TouchableOpacity
            style={[styles.confirmButton, (!bookingId.trim() || !selectedReason || loading) && styles.confirmButtonDisabled]}
            onPress={handleManualCheckIn}
            disabled={!bookingId.trim() || !selectedReason || loading}
            activeOpacity={0.8}
          >
            {loading ? <ActivityIndicator color="#000" /> : <Text style={styles.confirmButtonText}>Confirm Manual Check-in</Text>}
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );

  const renderSuccessDialog = () => (
    <View style={styles.floatingOverlay}>
      <Animated.View style={[styles.floatingDialog, { transform: [{ scale: popAnim }] }]}>
        <View style={styles.successIconCircle}>
          <Ionicons name="checkmark-circle" size={54} color={theme.colors.primary} />
        </View>
        <Text style={styles.floatingTitle}>Check-in Successful!</Text>
        <Text style={styles.floatingSubtitle}>Booking Completed</Text>
      </Animated.View>
    </View>
  );

  if (isManualMode) {
    return (
      <SafeAreaView style={styles.container}>
        {renderManualMode()}
        {resultMessage === 'SUCCESS' && renderSuccessDialog()}
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Ionicons name="close" size={28} color="#FFFFFF" />
        </TouchableOpacity>
        <Text style={styles.title}>Scan QR</Text>
        <TouchableOpacity onPress={() => setIsManualMode(true)} style={styles.modeButton}>
          <Ionicons name="create-outline" size={24} color={theme.colors.primary} />
        </TouchableOpacity>
      </View>

      <View style={styles.cameraContainer}>
        <CameraView
          style={StyleSheet.absoluteFill}
          facing="back"
          onBarcodeScanned={scanned ? undefined : handleBarCodeScanned}
          barcodeScannerSettings={{
            barcodeTypes: ["qr"],
          }}
        >
          <View style={styles.overlay}>
            <View style={styles.unfocusedContainer} />
            <View style={styles.middleContainer}>
              <View style={styles.unfocusedContainer} />
              <View style={styles.focusedBox}>
                <View style={[styles.corner, styles.topLeft]} />
                <View style={[styles.corner, styles.topRight]} />
                <View style={[styles.corner, styles.bottomLeft]} />
                <View style={[styles.corner, styles.bottomRight]} />
                
                {/* Glowing laser scanning line */}
                <Animated.View
                  style={[
                    styles.laserLine,
                    {
                      transform: [
                        {
                          translateY: scanAnim.interpolate({
                            inputRange: [0, 1],
                            outputRange: [10, 246],
                          }),
                        },
                      ],
                    },
                  ]}
                />
              </View>
              <View style={styles.unfocusedContainer} />
            </View>
            <View style={styles.unfocusedContainer} />
          </View>
        </CameraView>
      </View>

      <View style={styles.bottomBar}>
        {loading ? (
          <View style={styles.statusBox}>
            <ActivityIndicator size="small" color={theme.colors.primary} />
            <Text style={styles.statusText}>Verifying Booking...</Text>
          </View>
        ) : resultMessage && resultMessage !== 'SUCCESS' ? (
          <View style={styles.statusBox}>
            <Text style={[styles.statusText, { color: '#EF4444' }]}>
              {resultMessage}
            </Text>
            <TouchableOpacity style={styles.retryButton} onPress={() => {
              setScanned(false);
              setResultMessage(null);
            }}>
              <Text style={styles.retryText}>Scan Again</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={{ alignItems: 'center' }}>
            <Text style={styles.instructions}>
              Point the camera at the customer's QR code.
            </Text>
            <TouchableOpacity style={styles.manualOverrideBtn} onPress={() => setIsManualMode(true)}>
              <Text style={styles.manualOverrideText}>Manual Override</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>
      {resultMessage === 'SUCCESS' && renderSuccessDialog()}
    </SafeAreaView>
  );
}

function getStyles(theme: any, responsive: any) {
  return StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#111827',
    },
    centerContainer: {
      flex: 1,
      backgroundColor: '#111827',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 24,
    },
    permissionText: {
      color: '#FFFFFF',
      fontSize: 16,
      textAlign: 'center',
      marginBottom: 30,
      lineHeight: 24,
    },
    primaryButton: {
      backgroundColor: theme.colors.primary,
      paddingHorizontal: 24,
      paddingVertical: 14,
      borderRadius: 12,
      width: '100%',
      alignItems: 'center',
    },
    primaryButtonText: {
      color: '#000000',
      fontWeight: 'bold',
      fontSize: 16,
    },
    secondaryButton: {
      paddingHorizontal: 24,
      paddingVertical: 14,
      borderRadius: 12,
      width: '100%',
      alignItems: 'center',
      borderWidth: 1,
      borderColor: theme.colors.border,
    },
    secondaryButtonText: {
      color: theme.colors.text,
      fontWeight: 'bold',
      fontSize: 16,
    },
    header: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      paddingHorizontal: 20,
      paddingVertical: 16,
      zIndex: 10,
    },
    backButton: {
      width: 44,
      height: 44,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: 'rgba(255,255,255,0.1)',
      borderRadius: 22,
    },
    modeButton: {
      width: 44,
      height: 44,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: 'rgba(16, 185, 129, 0.1)', // Emerald tinted
      borderRadius: 22,
    },
    title: {
      color: '#FFFFFF',
      fontSize: 18,
      fontWeight: 'bold',
    },
    cameraContainer: {
      flex: 1,
      overflow: 'hidden',
    },
    overlay: {
      ...StyleSheet.absoluteFill,
    },
    unfocusedContainer: {
      flex: 1,
      backgroundColor: 'rgba(17, 24, 39, 0.8)', // Match background #111827
    },
    middleContainer: {
      flexDirection: 'row',
      height: 260,
    },
    focusedBox: {
      width: 260,
      height: 260,
      position: 'relative',
    },
    laserLine: {
      position: 'absolute',
      left: 12,
      right: 12,
      height: 3,
      backgroundColor: theme.colors.primary,
      borderRadius: 1.5,
      shadowColor: theme.colors.primary,
      shadowOffset: { width: 0, height: 0 },
      shadowOpacity: 0.8,
      shadowRadius: 8,
      elevation: 5,
    },
    corner: {
      position: 'absolute',
      width: 40,
      height: 40,
      borderColor: theme.colors.primary,
    },
    topLeft: {
      top: 0,
      left: 0,
      borderTopWidth: 4,
      borderLeftWidth: 4,
      borderTopLeftRadius: 16,
    },
    topRight: {
      top: 0,
      right: 0,
      borderTopWidth: 4,
      borderRightWidth: 4,
      borderTopRightRadius: 16,
    },
    bottomLeft: {
      bottom: 0,
      left: 0,
      borderBottomWidth: 4,
      borderLeftWidth: 4,
      borderBottomLeftRadius: 16,
    },
    bottomRight: {
      bottom: 0,
      right: 0,
      borderBottomWidth: 4,
      borderRightWidth: 4,
      borderBottomRightRadius: 16,
    },
    bottomBar: {
      padding: 24,
      backgroundColor: '#111827',
      minHeight: 140,
      justifyContent: 'center',
    },
    instructions: {
      color: 'rgba(255,255,255,0.7)',
      textAlign: 'center',
      fontSize: 14,
      lineHeight: 20,
      marginBottom: 16,
    },
    manualOverrideBtn: {
      backgroundColor: 'rgba(255,255,255,0.1)',
      paddingHorizontal: 24,
      paddingVertical: 12,
      borderRadius: 24,
      borderWidth: 1,
      borderColor: 'rgba(255,255,255,0.2)',
    },
    manualOverrideText: {
      color: '#FFFFFF',
      fontWeight: '700',
    },
    statusBox: {
      alignItems: 'center',
      gap: 12,
    },
    statusText: {
      color: '#FFFFFF',
      fontSize: 16,
      fontWeight: 'bold',
      textAlign: 'center',
    },
    retryButton: {
      backgroundColor: 'rgba(255,255,255,0.1)',
      paddingHorizontal: 20,
      paddingVertical: 10,
      borderRadius: 20,
      marginTop: 8,
    },
    retryText: {
      color: '#FFFFFF',
      fontWeight: 'bold',
    },
    manualContainer: {
      flexGrow: 1,
      paddingBottom: 40,
    },
    manualForm: {
      padding: 24,
    },
    inputLabel: {
      color: theme.colors.textMuted,
      fontSize: 12,
      fontWeight: '800',
      letterSpacing: 1,
      marginBottom: 8,
    },
    input: {
      backgroundColor: 'rgba(255,255,255,0.05)',
      borderWidth: 1,
      borderColor: theme.colors.border,
      borderRadius: 16,
      padding: 16,
      color: theme.colors.text,
      fontSize: 16,
    },
    chipContainer: {
      flexDirection: 'row',
      flexWrap: 'wrap',
      gap: 12,
    },
    chip: {
      backgroundColor: 'rgba(255,255,255,0.05)',
      borderWidth: 1,
      borderColor: theme.colors.border,
      paddingHorizontal: 16,
      paddingVertical: 12,
      borderRadius: 24,
    },
    chipActive: {
      backgroundColor: theme.colors.primary,
      borderColor: theme.colors.primary,
    },
    chipText: {
      color: theme.colors.text,
      fontWeight: '600',
    },
    chipTextActive: {
      color: '#000000',
      fontWeight: '800',
    },
    confirmButton: {
      backgroundColor: theme.colors.primary,
      padding: 18,
      borderRadius: 16,
      alignItems: 'center',
      marginTop: 40,
    },
    confirmButtonDisabled: {
      backgroundColor: 'rgba(16, 185, 129, 0.3)',
    },
    confirmButtonText: {
      color: '#000000',
      fontWeight: 'bold',
      fontSize: 16,
    },
    resultBox: {
      padding: 16,
      borderRadius: 12,
      marginTop: 24,
      alignItems: 'center',
    },
    resultText: {
      fontWeight: 'bold',
      fontSize: 14,
    },
    floatingOverlay: {
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(17, 24, 39, 0.75)',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 999,
    },
    floatingDialog: {
      backgroundColor: '#1F2937',
      borderRadius: 24,
      paddingVertical: 24,
      paddingHorizontal: 32,
      alignItems: 'center',
      borderWidth: 1.5,
      borderColor: 'rgba(16, 185, 129, 0.4)',
      width: '80%',
      maxWidth: 320,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 10 },
      shadowOpacity: 0.3,
      shadowRadius: 20,
      elevation: 10,
    },
    successIconCircle: {
      marginBottom: 12,
    },
    floatingTitle: {
      color: '#FFFFFF',
      fontSize: 18,
      fontWeight: 'bold',
      textAlign: 'center',
      marginBottom: 6,
    },
    floatingSubtitle: {
      color: theme.colors.primary,
      fontSize: 14,
      fontWeight: '700',
      textAlign: 'center',
    }
  });
}
