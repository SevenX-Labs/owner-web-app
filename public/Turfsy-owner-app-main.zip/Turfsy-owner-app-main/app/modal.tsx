import React from 'react';
import { StyleSheet, View, TouchableOpacity, ViewStyle, TextStyle, ColorValue } from 'react-native';
import { Link, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';

import { ThemedText } from '@/components/themed-text';
import { ThemedView } from '@/components/themed-view';

// Turfsy Owner Theme
const THEME = {
  background: '#000000',
  surface: '#1A1A1A',
  primary: '#ADFF00' as ColorValue, // Cast as ColorValue for Style compatibility
  border: '#262626',
};

export default function ModalScreen() {
  const router = useRouter();

  return (
    <ThemedView style={styles.container}>
      {/* 1. Success Indicator */}
      <View style={styles.iconCircle}>
        <Ionicons 
          name="checkmark-circle" 
          size={80} 
          color={THEME.primary} 
        />
      </View>

      {/* 2. Text Content */}
      <ThemedText type="title" style={styles.title}>
        Action Completed
      </ThemedText>
      
      <ThemedText style={styles.description}>
        Your changes have been successfully saved to the Turfsy cloud.
      </ThemedText>

      {/* 3. Branded Dismiss Button */}
      <TouchableOpacity 
        style={styles.primaryBtn}
        onPress={() => router.dismiss()}
        activeOpacity={0.8}
      >
        <ThemedText style={styles.btnText}>BACK TO DASHBOARD</ThemedText>
      </TouchableOpacity>

      {/* 4. Secondary Dismiss Link - Fixed Error here */}
      <Link href="/" dismissTo style={styles.link as any}>
        <ThemedText style={styles.linkText}>Go to home screen</ThemedText>
      </Link>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
    backgroundColor: THEME.background,
  } as ViewStyle,
  iconCircle: {
    marginBottom: 20,
  } as ViewStyle,
  title: {
    fontSize: 32,
    fontWeight: '900',
    color: '#FFF',
    textAlign: 'center',
    letterSpacing: -0.5,
  } as TextStyle,
  description: {
    fontSize: 16,
    color: '#888',
    textAlign: 'center',
    marginTop: 10,
    lineHeight: 22,
    maxWidth: '80%',
  } as TextStyle,
  primaryBtn: {
    backgroundColor: THEME.primary,
    height: 60,
    width: '100%',
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 40,
  } as ViewStyle,
  btnText: {
    color: '#000',
    fontSize: 16,
    fontWeight: '800',
  } as TextStyle,
  link: {
    marginTop: 25,
    paddingVertical: 10,
  } as ViewStyle,
  linkText: {
    color: '#666',
    fontSize: 14,
    fontWeight: '600',
    textDecorationLine: 'underline',
  } as TextStyle,
});