import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  StatusBar,
  ViewStyle,
  TextStyle,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { showSuccess } from '../../src/components/ui/CustomAlert';

// Turfsy Branding Constants
const THEME = {
  background: '#000000',
  surface: '#1A1A1A',
  primary: '#ADFF00', // Volt Green
  textMain: '#FFFFFF',
  textMuted: '#888888',
  border: '#262626',
};

export default function EarningsExportScreen() {
  const router = useRouter();
  const [loading, setLoading] = useState<boolean>(false);

  const handleExport = async (format: 'CSV' | 'PDF'): Promise<void> => {
    setLoading(true);
    try {
      // Logic for actual export would go here
      setTimeout(() => {
        showSuccess(
          'Export Successful',
          `Your ${format} report has been generated and saved to your device.`
        );
        setLoading(false);
      }, 1500);
    } catch (error) {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" />

      {/* Branded Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color="#FFF" />
        </TouchableOpacity>
        <View>
          <Text style={styles.headerLabel}>FINANCIAL TOOLS</Text>
          <Text style={styles.headerTitle}>Export Data</Text>
        </View>
      </View>

      <View style={styles.content}>
        <Text style={styles.description}>
          Select your preferred file format to download your business performance reports.
        </Text>

        {/* CSV Export Option */}
        <TouchableOpacity
          style={styles.exportCard}
          onPress={() => handleExport('CSV')}
          disabled={loading}
          activeOpacity={0.8}
        >
          <View style={styles.iconBox}>
            <Ionicons name="grid-outline" size={28} color={THEME.primary} />
          </View>
          <View style={styles.exportDetails}>
            <Text style={styles.exportName}>Spreadsheet (CSV)</Text>
            <Text style={styles.exportDesc}>Best for Excel, Numbers, or detailed data analysis.</Text>
          </View>
          <View style={styles.downloadCircle}>
            <Ionicons name="download-outline" size={18} color="#000" />
          </View>
        </TouchableOpacity>

        {/* PDF Export Option */}
        <TouchableOpacity
          style={styles.exportCard}
          onPress={() => handleExport('PDF')}
          disabled={loading}
          activeOpacity={0.8}
        >
          <View style={styles.iconBox}>
            <Ionicons name="document-text-outline" size={28} color={THEME.primary} />
          </View>
          <View style={styles.exportDetails}>
            <Text style={styles.exportName}>Document (PDF)</Text>
            <Text style={styles.exportDesc}>Best for sharing, printing, or accounting records.</Text>
          </View>
          <View style={styles.downloadCircle}>
            <Ionicons name="download-outline" size={18} color="#000" />
          </View>
        </TouchableOpacity>

        {/* Pro Tip Box */}
        <View style={styles.tipBox}>
          <Ionicons name="bulb-outline" size={20} color={THEME.primary} />
          <Text style={styles.tipText}>
            Reports include all slot timings, player details, and net settlement amounts.
          </Text>
        </View>
      </View>

      {/* Footer Branding */}
      <View style={styles.footer}>
        <Text style={styles.footerText}>TURFSY SECURE DATA</Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: THEME.background,
  } as ViewStyle,
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 20,
    borderBottomWidth: 1,
    borderBottomColor: THEME.border,
  } as ViewStyle,
  backBtn: {
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: THEME.surface,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
    borderWidth: 1,
    borderColor: THEME.border,
  } as ViewStyle,
  headerLabel: {
    color: THEME.textMuted,
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.5,
  } as TextStyle,
  headerTitle: {
    color: '#FFF',
    fontSize: 24,
    fontWeight: '900',
  } as TextStyle,
  content: {
    padding: 24,
    gap: 16,
  } as ViewStyle,
  description: {
    color: THEME.textMuted,
    fontSize: 15,
    lineHeight: 22,
    fontWeight: '600',
    marginBottom: 20,
  } as TextStyle,
  exportCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: THEME.surface,
    borderRadius: 24,
    padding: 20,
    borderWidth: 1,
    borderColor: THEME.border,
  } as ViewStyle,
  iconBox: {
    width: 60,
    height: 60,
    borderRadius: 18,
    backgroundColor: '#000',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: THEME.border,
  } as ViewStyle,
  exportDetails: {
    flex: 1,
    marginLeft: 16,
  } as ViewStyle,
  exportName: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '800',
  } as TextStyle,
  exportDesc: {
    color: THEME.textMuted,
    fontSize: 12,
    marginTop: 4,
    fontWeight: '500',
    lineHeight: 16,
  } as TextStyle,
  downloadCircle: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: THEME.primary,
    justifyContent: 'center',
    alignItems: 'center',
  } as ViewStyle,
  tipBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(173, 255, 0, 0.05)',
    padding: 20,
    borderRadius: 20,
    marginTop: 20,
    gap: 12,
    borderWidth: 1,
    borderColor: 'rgba(173, 255, 0, 0.1)',
  } as ViewStyle,
  tipText: {
    flex: 1,
    color: '#CCC',
    fontSize: 13,
    fontWeight: '600',
    lineHeight: 18,
  } as TextStyle,
  footer: {
    marginTop: 'auto',
    alignItems: 'center',
    paddingBottom: 20,
  } as ViewStyle,
  footerText: {
    color: THEME.border,
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 2,
  } as TextStyle,
});