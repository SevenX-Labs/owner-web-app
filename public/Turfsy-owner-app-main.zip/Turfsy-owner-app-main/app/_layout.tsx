import { DarkTheme, DefaultTheme, ThemeProvider } from '@react-navigation/native';
import { Stack, useSegments, useRouter, useRootNavigationState } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { StatusBar } from 'expo-status-bar';
import React, { useEffect } from 'react';
import { ActivityIndicator, StyleSheet, View, Platform } from 'react-native';
import 'react-native-reanimated';
import { NavigationBar } from 'expo-navigation-bar';
import {
  useFonts,
  Geist_400Regular,
  Geist_500Medium,
  Geist_600SemiBold,
  Geist_700Bold,
  Geist_800ExtraBold,
  Geist_900Black,
} from '@expo-google-fonts/geist';

import { useColorScheme } from '@/hooks/use-color-scheme';
import { AuthProvider, useAuthContext } from '../src/context/AuthContext';
import { useAppTheme } from '../src/hooks/useAppTheme';
import { useNotifications } from '../src/hooks/useNotifications';
import { NotificationToast } from '../src/components/NotificationToast';
import { CustomAlertProvider } from '../src/components/ui/CustomAlert';

void SplashScreen.preventAutoHideAsync();

function RootNavigator() {
  const { isDark, theme } = useAppTheme();
  const { isAuthenticated, isLoading } = useAuthContext();
  const segments = useSegments();
  const router = useRouter();
  const navigationState = useRootNavigationState();

  // Hide system navigation bar on Android (immersive/game-like mode)
  useEffect(() => {
    if (Platform.OS === 'android') {
      NavigationBar.setHidden(true);
    }
  }, []);

  // ─── Geist Font Loading ──────────────────────────────────────────────────
  const [fontsLoaded] = useFonts({
    Geist_400Regular,
    Geist_500Medium,
    Geist_600SemiBold,
    Geist_700Bold,
    Geist_800ExtraBold,
    Geist_900Black,
  });

  // ─── Push Notification Integration ──────────────────────────────────────────
  const {
    inAppNotification,
    dismissInAppNotification,
    handleInAppNotificationTap,
  } = useNotifications();

  useEffect(() => {
    if (isLoading || !navigationState?.key || !fontsLoaded) return;

    // Hide splash once auth state is resolved and fonts are loaded
    void SplashScreen.hideAsync();

    const inAuthGroup = segments[0] === '(auth)';

    if (!isAuthenticated && !inAuthGroup) {
      // Redirect unauthenticated users to the welcome screen
      router.replace('/(auth)/welcome' as any);
    } else if (isAuthenticated && inAuthGroup) {
      // Redirect authenticated users from auth screens to the dashboard
      router.replace('/(tabs)' as any);
    }
  }, [isAuthenticated, isLoading, segments, router, navigationState?.key, fontsLoaded]);

  // Show a blank loading screen while auth hydrates or fonts load
  if (isLoading || !fontsLoaded) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: theme.colors.background }]}>
        <ActivityIndicator size="large" color={theme.colors.primary} />
      </View>
    );
  }

  return (
    <ThemeProvider value={isDark ? DarkTheme : DefaultTheme}>
      <View style={{ flex: 1 }}>
        <Stack
          screenOptions={{
            headerShown: false,
            animation: 'fade_from_bottom',
            contentStyle: { backgroundColor: theme.colors.background },
          }}
        >
          <Stack.Screen name="(auth)" />
          <Stack.Screen name="(tabs)" />
          <Stack.Screen name="profile-setup/index" />
          <Stack.Screen name="booking/[id]" />
          <Stack.Screen
            name="booking/filter"
            options={{
              presentation: 'transparentModal',
              animation: 'slide_from_bottom',
            }}
          />
          <Stack.Screen name="earnings/analytics" />
          <Stack.Screen name="earnings/export" />
          <Stack.Screen name="profile/edit" />
          <Stack.Screen name="profile/support" />
          <Stack.Screen name="profile/settings" />
          <Stack.Screen
            name="modal"
            options={{
              presentation: 'modal',
              animation: 'slide_from_bottom',
            }}
          />
        </Stack>

        {/* In-app notification toast (foreground) */}
        <NotificationToast
          notification={inAppNotification}
          onDismiss={dismissInAppNotification}
          onTap={handleInAppNotificationTap}
        />
      </View>
      <StatusBar style="light" backgroundColor={theme.colors.background} translucent />
    </ThemeProvider>
  );
}

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default function RootLayout() {
  return (
    <AuthProvider>
      <CustomAlertProvider>
        <RootNavigator />
      </CustomAlertProvider>
    </AuthProvider>
  );
}
