import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React, { useState } from 'react';
import {
    ActivityIndicator,
    ScrollView,
    StatusBar,
    StyleSheet,
    Text,
    TextStyle,
    TouchableOpacity,
    View,
    ViewStyle,
} from 'react-native';
import { showWarning, showError } from '../../src/components/ui/CustomAlert';
import { SafeAreaView } from 'react-native-safe-area-context';
import ProfileForm, { ProfileErrors, validateProfile } from '../../components/profile/ProfileForm';
import { useAuthContext } from '../../src/context/AuthContext';
import { EMPTY_PROFILE, OwnerProfile } from '../../src/types/profile';
import { fp, hp, isTablet, screenPadding, wp } from '../../src/utils/responsive';
import { saveProfile } from '../../src/utils/storage';

const THEME = {
  background: '#000000',
  surface: '#1A1A1A',
  primary: '#ADFF00',
  textMuted: '#888888',
  border: '#333333',
  error: '#FF4B4B',
};

const OwnerProfileScreen: React.FC = () => {
  const router = useRouter();
  const { establishSession } = useAuthContext();
  const [profile, setProfile] = useState<OwnerProfile>(EMPTY_PROFILE);
  const [errors, setErrors]   = useState<ProfileErrors>({});
  const [saving, setSaving]   = useState<boolean>(false);

  const handleSave = async (): Promise<void> => {
    const validationErrors = validateProfile(profile);
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      showWarning('Incomplete Profile', 'Please fix the highlighted fields before saving.');
      return;
    }
    setErrors({});
    setSaving(true);
    try {
      await saveProfile(profile);
      await establishSession(profile as any);
      router.replace('/(tabs)' as any);
    } catch {
      showError('Error', 'Failed to save profile. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" />

      {/* Top Bar */}
      <View style={styles.topBar}>
        <View style={styles.logoRow}>
          <View style={styles.logoSquare} />
          <Text style={styles.logoText}>TURFSY</Text>
          <View style={styles.ownerTag}>
            <Text style={styles.ownerTagText}>OWNER</Text>
          </View>
        </View>
        <View style={styles.stepBadge}>
          <Text style={styles.stepBadgeText}>SETUP</Text>
        </View>
      </View>

      {/* Progress */}
      <View style={styles.progressContainer}>
        <View style={styles.progressBar}>
          <View style={styles.progressFill} />
        </View>
      </View>

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* Hero */}
        <View style={styles.hero}>
          <Text style={styles.heroTitle}>Build Your</Text>
          <Text style={[styles.heroTitle, { color: THEME.primary }]}>Profile.</Text>
          <Text style={styles.heroSubtitle}>
            Complete your owner profile to start accepting bookings on Turfsy.
          </Text>
        </View>

        {/* Form */}
        <ProfileForm
          profile={profile}
          errors={errors}
          onChange={setProfile}
        />

        {/* Save Button */}
        <TouchableOpacity
          style={[styles.saveBtn, saving && { opacity: 0.7 }]}
          onPress={handleSave}
          disabled={saving}
          activeOpacity={0.85}
        >
          {saving ? (
            <ActivityIndicator color="#000" />
          ) : (
            <>
              <Text style={styles.saveBtnText}>Save Profile</Text>
              <Ionicons name="checkmark-circle" size={wp(22)} color="#000" />
            </>
          )}
        </TouchableOpacity>

        <View style={{ height: hp(40) }} />
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: THEME.background } as ViewStyle,
  topBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: screenPadding,
    paddingTop: hp(16),
    paddingBottom: hp(8),
  } as ViewStyle,
  logoRow: { flexDirection: 'row', alignItems: 'center', gap: wp(8) } as ViewStyle,
  logoSquare: {
    width: wp(22),
    height: wp(22),
    backgroundColor: THEME.primary,
    borderRadius: wp(5),
  } as ViewStyle,
  logoText: { color: '#FFF', fontSize: fp(16), fontWeight: '900', letterSpacing: 2 } as TextStyle,
  ownerTag: {
    borderWidth: 1,
    borderColor: THEME.primary,
    paddingHorizontal: wp(5),
    paddingVertical: hp(1),
    borderRadius: wp(4),
  } as ViewStyle,
  ownerTagText: { color: THEME.primary, fontSize: fp(9), fontWeight: '800' } as TextStyle,
  stepBadge: {
    backgroundColor: THEME.surface,
    paddingHorizontal: wp(12),
    paddingVertical: hp(6),
    borderRadius: wp(20),
    borderWidth: 1,
    borderColor: THEME.border,
  } as ViewStyle,
  stepBadgeText: { color: THEME.primary, fontSize: fp(10), fontWeight: '800', letterSpacing: 1 } as TextStyle,
  progressContainer: { paddingHorizontal: screenPadding, marginBottom: hp(4) } as ViewStyle,
  progressBar: {
    height: hp(3),
    backgroundColor: THEME.surface,
    borderRadius: wp(2),
    overflow: 'hidden',
  } as ViewStyle,
  progressFill: { width: '100%', height: '100%', backgroundColor: THEME.primary } as ViewStyle,
  scrollContent: { paddingHorizontal: screenPadding, paddingTop: hp(24) } as ViewStyle,
  hero: { marginBottom: hp(8) } as ViewStyle,
  heroTitle: {
    fontSize: fp(isTablet ? 52 : 42),
    fontWeight: '900',
    color: '#FFF',
    lineHeight: fp(isTablet ? 58 : 48),
  } as TextStyle,
  heroSubtitle: {
    color: THEME.textMuted,
    fontSize: fp(15),
    marginTop: hp(10),
    lineHeight: fp(22),
    maxWidth: '90%',
  } as TextStyle,
  saveBtn: {
    backgroundColor: THEME.primary,
    height: hp(65),
    borderRadius: wp(32),
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: wp(10),
    marginTop: hp(32),
  } as ViewStyle,
  saveBtnText: { color: '#000', fontSize: fp(18), fontWeight: '800' } as TextStyle,
});

export default OwnerProfileScreen;
