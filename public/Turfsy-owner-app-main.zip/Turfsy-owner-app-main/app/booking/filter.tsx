import React, { useState } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  StatusBar,
  ViewStyle,
  TextStyle,
  ScrollView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';

// Turfsy Pro Theme
const THEME = {
  background: '#000000',
  surface: '#1A1A1A',
  primary: '#ADFF00', // Volt Green
  textMain: '#FFFFFF',
  textMuted: '#888888',
  border: '#262626',
};

// Mocked options for standalone UI
const STATUS_OPTIONS = [
  { label: 'Pending', value: 'pending' },
  { label: 'Confirmed', value: 'confirmed' },
  { label: 'Completed', value: 'completed' },
  { label: 'Cancelled', value: 'cancelled' },
];

const SPORT_OPTIONS = [
  { label: 'Football', value: 'football' },
  { label: 'Cricket', value: 'cricket' },
  { label: 'Tennis', value: 'tennis' },
  { label: 'Turf', value: 'turf' },
];

export default function BookingFilterScreen() {
  const router = useRouter();
  const [selectedStatus, setSelectedStatus] = useState<string>('');
  const [selectedSport, setSelectedSport] = useState<string>('');

  const clearFilters = (): void => {
    setSelectedStatus('');
    setSelectedSport('');
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" />
      
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.closeBtn}>
          <Ionicons name="close" size={24} color="#FFF" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Filters</Text>
        <TouchableOpacity onPress={clearFilters}>
          <Text style={styles.clearText}>Reset</Text>
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* Status Group */}
        <FilterGroup 
          title="BOOKING STATUS"
          options={STATUS_OPTIONS}
          selected={selectedStatus}
          onSelect={setSelectedStatus}
        />

        <View style={styles.divider} />

        {/* Sport Group */}
        <FilterGroup 
          title="SPORT TYPE"
          options={SPORT_OPTIONS}
          selected={selectedSport}
          onSelect={setSelectedSport}
        />
      </ScrollView>

      {/* Footer Action */}
      <View style={styles.footer}>
        <TouchableOpacity 
          style={styles.applyBtn} 
          onPress={() => router.back()}
          activeOpacity={0.8}
        >
          <Text style={styles.applyBtnText}>Apply Filters</Text>
          <Ionicons name="checkmark-done" size={20} color="#000" />
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

// Sub-component for Filter Groups
const FilterGroup = ({ title, options, selected, onSelect }: any) => (
  <View style={styles.groupContainer}>
    <Text style={styles.groupLabel}>{title}</Text>
    <View style={styles.chipGrid}>
      {options.map((opt: any) => {
        const isActive = selected === opt.value;
        return (
          <TouchableOpacity
            key={opt.value}
            onPress={() => onSelect(isActive ? '' : opt.value)}
            style={[styles.chip, isActive && styles.chipActive]}
            activeOpacity={0.7}
          >
            <Text style={[styles.chipText, isActive && styles.chipTextActive]}>
              {opt.label}
            </Text>
          </TouchableOpacity>
        );
      })}
    </View>
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: THEME.background,
  } as ViewStyle,
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 20,
    borderBottomWidth: 1,
    borderBottomColor: THEME.border,
  } as ViewStyle,
  closeBtn: {
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: THEME.surface,
    justifyContent: 'center',
    alignItems: 'center',
  } as ViewStyle,
  headerTitle: {
    color: '#FFF',
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: -0.5,
  } as TextStyle,
  clearText: {
    color: THEME.primary,
    fontSize: 14,
    fontWeight: '800',
  } as TextStyle,
  scrollContent: {
    padding: 24,
  } as ViewStyle,
  groupContainer: {
    marginBottom: 30,
  } as ViewStyle,
  groupLabel: {
    color: THEME.textMuted,
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.5,
    marginBottom: 15,
  } as TextStyle,
  chipGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  } as ViewStyle,
  chip: {
    backgroundColor: THEME.surface,
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: THEME.border,
  } as ViewStyle,
  chipActive: {
    backgroundColor: THEME.primary,
    borderColor: THEME.primary,
  } as ViewStyle,
  chipText: {
    color: THEME.textMuted,
    fontSize: 14,
    fontWeight: '700',
  } as TextStyle,
  chipTextActive: {
    color: '#000',
    fontWeight: '800',
  } as TextStyle,
  divider: {
    height: 1,
    backgroundColor: THEME.border,
    marginBottom: 30,
  } as ViewStyle,
  footer: {
    padding: 24,
    paddingBottom: 40,
  } as ViewStyle,
  applyBtn: {
    backgroundColor: THEME.primary,
    height: 65,
    borderRadius: 32,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 10,
  } as ViewStyle,
  applyBtnText: {
    color: '#000',
    fontSize: 18,
    fontWeight: '900',
  } as TextStyle,
});