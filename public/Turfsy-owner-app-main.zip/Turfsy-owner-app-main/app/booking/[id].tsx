import React, { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  StatusBar,
  ViewStyle,
  TextStyle,
  ColorValue,
  ActivityIndicator,
  Alert,
  Modal,
  TextInput,
  Linking,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useLocalSearchParams, useRouter, useFocusEffect } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';

import { useAppTheme } from '@/src/hooks/useAppTheme';
import { useResponsive } from '@/src/utils/responsive';
import { STORAGE_KEYS } from '@/src/utils/constants';
import { Skeleton } from '@/src/components/ui/Skeleton';

const MANUAL_REASONS = [
  'Scanner Not Working',
  'Camera Issue',
  'Technical Issue',
  'Other'
];

export default function BookingDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { theme } = useAppTheme();
  const responsive = useResponsive();

  const [booking, setBooking] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [reasonModalVisible, setReasonModalVisible] = useState(false);
  const [selectedReason, setSelectedReason] = useState<string>('');
  const [customReason, setCustomReason] = useState<string>('');

  const bookingRef = React.useRef(booking);
  useEffect(() => {
    bookingRef.current = booking;
  }, [booking]);

  const fetchBookingDetails = useCallback(async () => {
    if (!id) return;
    try {
      if (!bookingRef.current) {
        setLoading(true);
      }
      const token = await AsyncStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
      if (!token) throw new Error("No auth token");

      const res = await fetch(`https://turfsy.onrender.com/api/v3/booking/owner/bookings/${id}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Accept': 'application/json',
        }
      });
      const resData = await res.json();
      if (res.ok && resData.success) {
        setBooking(resData.data);
      } else {
        Alert.alert('Error', resData.message || 'Failed to fetch booking details');
      }
    } catch (err: any) {
      Alert.alert('Error', err.message || 'An error occurred');
    } finally {
      setLoading(false);
    }
  }, [id]);

  useFocusEffect(
    useCallback(() => {
      fetchBookingDetails();
    }, [fetchBookingDetails])
  );

  const handleApprove = async () => {
    try {
      setActionLoading(true);
      const token = await AsyncStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
      if (!token) throw new Error("No auth token");

      const res = await fetch(`https://turfsy.onrender.com/api/v3/booking/owner/bookings/${id}/approve`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Accept': 'application/json',
        }
      });
      const resData = await res.json();
      if (res.ok && resData.success) {
        Alert.alert('Success', 'Booking approved successfully');
        fetchBookingDetails();
      } else {
        Alert.alert('Error', resData.message || 'Failed to approve booking');
      }
    } catch (err: any) {
      Alert.alert('Error', err.message || 'An error occurred');
    } finally {
      setActionLoading(false);
    }
  };

  const handleReject = async () => {
    try {
      setActionLoading(true);
      const token = await AsyncStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
      if (!token) throw new Error("No auth token");

      const res = await fetch(`https://turfsy.onrender.com/api/v3/booking/owner/bookings/${id}/reject`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Accept': 'application/json',
        }
      });
      const resData = await res.json();
      if (res.ok && resData.success) {
        Alert.alert('Success', 'Booking rejected successfully');
        fetchBookingDetails();
      } else {
        Alert.alert('Error', resData.message || 'Failed to reject booking');
      }
    } catch (err: any) {
      Alert.alert('Error', err.message || 'An error occurred');
    } finally {
      setActionLoading(false);
    }
  };

  const handleManualCheckInSubmit = async () => {
    const finalReason = selectedReason === 'Other' ? customReason.trim() : selectedReason;
    if (!finalReason) {
      Alert.alert('Error', 'Please select or provide a reason');
      return;
    }

    try {
      setActionLoading(true);
      const token = await AsyncStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
      if (!token) throw new Error("No auth token");

      const res = await fetch(`https://turfsy.onrender.com/api/v3/booking/${id}/manual-checkin`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ reason: finalReason }),
      });
      const resData = await res.json();
      if (res.ok && resData.success) {
        Alert.alert('Success', 'Manual check-in completed successfully');
        setReasonModalVisible(false);
        fetchBookingDetails();
      } else {
        Alert.alert('Error', resData.message || 'Failed to complete manual check-in');
      }
    } catch (err: any) {
      Alert.alert('Error', err.message || 'An error occurred');
    } finally {
      setActionLoading(false);
    }
  };

  const handleCall = () => {
    const phone = booking?.userPhone || booking?.customer?.phone;
    if (phone) {
      Linking.openURL(`tel:${phone}`);
    } else {
      Alert.alert('Not Available', 'No customer phone number registered for this booking');
    }
  };

  if (loading) {
    return <Skeleton.BookingDetailScreen />;
  }

  if (!booking) {
    return (
      <SafeAreaView style={styles.centerContainer}>
        <Ionicons name="alert-circle-outline" size={64} color={theme.colors.error} />
        <Text style={[styles.errorText, { color: theme.colors.text }]}>Booking not found</Text>
        <TouchableOpacity style={styles.retryBtn} onPress={fetchBookingDetails}>
          <Text style={styles.retryBtnText}>Retry</Text>
        </TouchableOpacity>
      </SafeAreaView>
    );
  }

  const bookingStatus = (booking.bookingStatus || booking.status || 'PENDING').toUpperCase();
  
  // Calculate Duration
  const calculateDuration = (start: string, end: string) => {
    if (!start || !end) return 0;
    const [sH, sM] = start.split(':').map(Number);
    const [eH, eM] = end.split(':').map(Number);
    let diff = (eH * 60 + eM) - (sH * 60 + sM);
    if (diff < 0) diff += 24 * 60; // overnight
    return diff;
  };
  const durationMin = calculateDuration(booking.startTime, booking.endTime);

  // Date formatter
  const formattedDate = booking.bookingDate 
    ? new Date(booking.bookingDate).toLocaleDateString('en-US', { weekday: 'short', day: 'numeric', month: 'short' })
    : 'N/A';

  const STATUS_COLORS: Record<string, string> = {
    CONFIRMED: '#2ED573',
    PENDING: '#FFC857',
    PENDING_APPROVAL: '#FFC857',
    CANCELLED: '#FF5D5D',
    REJECTED: '#FF5D5D',
    COMPLETED: theme.colors.primary,
    NO_SHOW: '#8B5CF6',
  };

  const statusColor = STATUS_COLORS[bookingStatus] || theme.colors.textMuted;

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color={theme.colors.text} />
        </TouchableOpacity>
        <View style={styles.headerTitleWrap}>
          <Text style={styles.headerLabel}>BOOKING ID</Text>
          <Text style={styles.headerTitle}>{booking.displayId || booking.id?.substring(0, 8).toUpperCase()}</Text>
        </View>
        <View style={[styles.statusBadge, { borderColor: statusColor, backgroundColor: `${statusColor}15` }]}>
          <Text style={[styles.statusText, { color: statusColor }]}>{bookingStatus}</Text>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        
        {/* Ticket-Style Info Card */}
        <View style={styles.mainCard}>
          <View style={styles.cardHeader}>
            <View style={styles.sportIconBox}>
              <Ionicons name="football" size={32} color={theme.colors.primary} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.sportName}>FOOTBALL</Text>
              <Text style={styles.venueName} numberOfLines={1}>{booking.turf?.name || 'Victory Arena'}</Text>
            </View>
          </View>

          <View style={styles.divider} />

          <View style={styles.detailsGrid}>
            <DetailItem icon="calendar-clear" label="DATE" value={formattedDate} theme={theme} />
            <DetailItem icon="time" label="TIME" value={`${booking.startTime} - ${booking.endTime}`} theme={theme} />
            <DetailItem icon="stopwatch" label="DURATION" value={`${durationMin} Min`} theme={theme} />
          </View>
        </View>

        {/* Customer Section */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>PLAYER DETAILS</Text>
          <View style={styles.customerBox}>
            <View style={[styles.avatar, { backgroundColor: theme.colors.primary }]}>
              <Text style={styles.avatarText}>{(booking.userName || 'Customer').charAt(0).toUpperCase()}</Text>
            </View>
            <View style={styles.customerInfo}>
              <Text style={styles.customerName}>{booking.userName || 'Customer'}</Text>
              <Text style={styles.customerPhone}>{booking.userPhone || 'No Phone'}</Text>
              {booking.userEmail && <Text style={styles.customerEmail}>{booking.userEmail}</Text>}
            </View>
            <TouchableOpacity style={[styles.callBtn, { backgroundColor: theme.colors.primary }]} onPress={handleCall}>
              <Ionicons name="call" size={20} color="#000" />
            </TouchableOpacity>
          </View>
        </View>

        {/* Billing Section */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>BILLING SUMMARY</Text>
          <View style={styles.billCard}>
            <View style={styles.billRow}>
              <Text style={styles.billLabel}>Total Price</Text>
              <Text style={styles.billValue}>₹{booking.amount}</Text>
            </View>
            
            <View style={styles.billRow}>
              <Text style={styles.billLabel}>Deposit Paid</Text>
              <Text style={styles.billValue}>₹{booking.depositAmount || 0}</Text>
            </View>

            <View style={styles.dividerLight} />

            <View style={styles.billRow}>
              <Text style={styles.billLabel}>Payment Method</Text>
              <Text style={[styles.billValue, { color: theme.colors.textSecondary }]}>
                {booking.paymentType?.replace(/_/g, ' ') || 'N/A'}
              </Text>
            </View>

            <View style={styles.billRow}>
              <Text style={styles.billLabel}>Payment Status</Text>
              <Text style={[styles.billValue, { color: booking.paymentStatus === 'SUCCESS' ? theme.colors.primary : theme.colors.warning }]}>
                {(booking.paymentStatus || 'PENDING').toUpperCase()}
              </Text>
            </View>

            {booking.paymentStatus !== 'SUCCESS' && !['CANCELLED', 'REJECTED'].includes(bookingStatus) && (
              <View style={[styles.alertBox, { backgroundColor: 'rgba(245, 166, 35, 0.1)', borderColor: 'rgba(245, 166, 35, 0.3)' }]}>
                <Ionicons name="cash-outline" size={20} color="#FFC857" />
                <Text style={styles.alertText}>
                  Collect ₹{booking.balanceAmount ?? (booking.amount - (booking.depositAmount || 0))} in Cash at Turf
                </Text>
              </View>
            )}
          </View>
        </View>

        {/* Notes / Audit Log Section */}
        {booking.notes && (
          <View style={styles.section}>
            <Text style={styles.sectionLabel}>NOTES & AUDIT LOG</Text>
            <View style={styles.notesBox}>
              <Text style={styles.notesText}>{booking.notes}</Text>
            </View>
          </View>
        )}

        {/* Footer Actions */}
        <View style={styles.footer}>
          {actionLoading ? (
            <ActivityIndicator size="large" color={theme.colors.primary} />
          ) : (
            <>
              {/* If Pending / Pending Approval */}
              {(bookingStatus === 'PENDING' || bookingStatus === 'PENDING_APPROVAL') && (
                <View style={styles.actionRow}>
                  <TouchableOpacity 
                    style={[styles.actionButton, styles.approveBtn, { backgroundColor: theme.colors.primary }]} 
                    onPress={handleApprove}
                  >
                    <Text style={styles.actionBtnTextDark}>Approve</Text>
                    <Ionicons name="checkmark-circle" size={20} color="#000" />
                  </TouchableOpacity>
                  
                  <TouchableOpacity 
                    style={[styles.actionButton, styles.rejectBtn, { borderColor: theme.colors.error }]} 
                    onPress={handleReject}
                  >
                    <Text style={[styles.actionBtnTextLight, { color: theme.colors.error }]}>Reject</Text>
                    <Ionicons name="close-circle" size={20} color={theme.colors.error} />
                  </TouchableOpacity>
                </View>
              )}

              {/* If Confirmed */}
              {bookingStatus === 'CONFIRMED' && (
                <View style={styles.actionRowVertical}>
                  <TouchableOpacity 
                    style={[styles.fullWidthBtn, { backgroundColor: theme.colors.primary }]} 
                    onPress={() => router.push('/scanner')}
                  >
                    <Text style={styles.actionBtnTextDark}>Scan QR Check-In</Text>
                    <Ionicons name="qr-code-outline" size={20} color="#000" />
                  </TouchableOpacity>

                  <TouchableOpacity 
                    style={[styles.fullWidthBtnMuted, { borderColor: theme.colors.border }]} 
                    onPress={() => setReasonModalVisible(true)}
                  >
                    <Text style={[styles.actionBtnTextLight, { color: theme.colors.textSecondary }]}>Manual Override Check-In</Text>
                    <Ionicons name="create-outline" size={20} color={theme.colors.textSecondary} />
                  </TouchableOpacity>
                </View>
              )}

              {/* If Completed */}
              {bookingStatus === 'COMPLETED' && (
                <View style={styles.completedBox}>
                  <Ionicons name="checkmark-done-circle" size={24} color={theme.colors.primary} />
                  <Text style={[styles.completedText, { color: theme.colors.primary }]}>
                    Checked In Successfully
                  </Text>
                </View>
              )}

              {/* If Cancelled or Rejected */}
              {(bookingStatus === 'CANCELLED' || bookingStatus === 'REJECTED') && (
                <View style={styles.completedBox}>
                  <Ionicons name="close-circle" size={24} color={theme.colors.error} />
                  <Text style={[styles.completedText, { color: theme.colors.error }]}>
                    Booking {bookingStatus === 'CANCELLED' ? 'Cancelled' : 'Rejected'}
                  </Text>
                </View>
              )}
            </>
          )}
        </View>

      </ScrollView>

      {/* Manual Check-in Modal */}
      <Modal
        visible={reasonModalVisible}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setReasonModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { backgroundColor: theme.colors.surface, borderColor: theme.colors.border }]}>
            <View style={styles.modalHeader}>
              <Text style={[styles.modalTitle, { color: theme.colors.text }]}>Manual Check-in</Text>
              <TouchableOpacity onPress={() => setReasonModalVisible(false)}>
                <Ionicons name="close" size={24} color={theme.colors.text} />
              </TouchableOpacity>
            </View>

            <Text style={[styles.modalSubtitle, { color: theme.colors.textSecondary }]}>
              Please select a reason for bypassing the QR code scanner:
            </Text>

            <View style={styles.chipContainer}>
              {MANUAL_REASONS.map(reason => (
                <TouchableOpacity
                  key={reason}
                  style={[
                    styles.chip,
                    { borderColor: theme.colors.border },
                    selectedReason === reason && [styles.chipActive, { backgroundColor: theme.colors.primary, borderColor: theme.colors.primary }]
                  ]}
                  onPress={() => setSelectedReason(reason)}
                >
                  <Text style={[
                    styles.chipText,
                    { color: theme.colors.textSecondary },
                    selectedReason === reason && { color: '#000000', fontWeight: 'bold' }
                  ]}>{reason}</Text>
                </TouchableOpacity>
              ))}
            </View>

            {selectedReason === 'Other' && (
              <TextInput
                style={[styles.modalInput, { borderColor: theme.colors.border, color: theme.colors.text }]}
                placeholder="Type reason here..."
                placeholderTextColor={theme.colors.textMuted}
                value={customReason}
                onChangeText={setCustomReason}
              />
            )}

            <TouchableOpacity
              style={[
                styles.modalSubmitBtn,
                { backgroundColor: theme.colors.primary },
                (!selectedReason || (selectedReason === 'Other' && !customReason.trim())) && styles.modalSubmitBtnDisabled
              ]}
              onPress={handleManualCheckInSubmit}
              disabled={!selectedReason || (selectedReason === 'Other' && !customReason.trim())}
            >
              <Text style={styles.modalSubmitText}>Confirm Check-in</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

    </SafeAreaView>
  );
}

// Helper detail item
const DetailItem = ({ icon, label, value, theme }: { icon: any, label: string, value: string, theme: any }) => (
  <View style={styles.detailItem}>
    <Ionicons name={icon} size={16} color={theme.colors.primary} />
    <View style={{ marginLeft: 10 }}>
      <Text style={[styles.itemLabel, { color: theme.colors.textMuted }]}>{label}</Text>
      <Text style={[styles.itemValue, { color: theme.colors.text }]}>{value}</Text>
    </View>
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0C0D10',
  },
  centerContainer: {
    flex: 1,
    backgroundColor: '#0C0D10',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    fontWeight: '600',
  },
  errorText: {
    marginTop: 16,
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 24,
  },
  retryBtn: {
    backgroundColor: '#B8FF17',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 16,
  },
  retryBtnText: {
    color: '#000',
    fontWeight: 'bold',
    fontSize: 16,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#2A2F37',
  },
  backBtn: {
    width: 40,
  },
  headerTitleWrap: {
    flex: 1,
  },
  headerLabel: {
    color: '#7D8592',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1,
  },
  headerTitle: {
    color: '#FFF',
    fontSize: 18,
    fontWeight: '900',
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    borderWidth: 1,
  },
  statusText: {
    fontSize: 10,
    fontWeight: '900',
  },
  scrollContent: {
    padding: 24,
  },
  mainCard: {
    backgroundColor: '#181B20',
    borderRadius: 24,
    padding: 24,
    borderWidth: 1,
    borderColor: '#262A31',
    marginBottom: 30,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  sportIconBox: {
    width: 64,
    height: 64,
    borderRadius: 16,
    backgroundColor: '#0C0D10',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#2A2F37',
  },
  sportName: {
    color: '#B8FF17',
    fontSize: 12,
    fontWeight: '900',
    letterSpacing: 1,
  },
  venueName: {
    color: '#FFF',
    fontSize: 20,
    fontWeight: '800',
    marginTop: 2,
  },
  divider: {
    height: 1,
    backgroundColor: '#2A2F37',
    marginVertical: 24,
  },
  dividerLight: {
    height: 1,
    backgroundColor: '#22262D',
    marginVertical: 8,
  },
  detailsGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  itemLabel: {
    fontSize: 8,
    fontWeight: '800',
  },
  itemValue: {
    fontSize: 13,
    fontWeight: '700',
    marginTop: 2,
  },
  section: {
    marginBottom: 30,
  },
  sectionLabel: {
    color: '#7D8592',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1.5,
    marginBottom: 15,
  },
  customerBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#181B20',
    padding: 16,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#262A31',
  },
  avatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: {
    color: '#000',
    fontSize: 20,
    fontWeight: '900',
  },
  customerInfo: {
    flex: 1,
    marginLeft: 15,
  },
  customerName: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '800',
  },
  customerPhone: {
    color: '#B2B7C2',
    fontSize: 13,
    fontWeight: '600',
    marginTop: 2,
  },
  customerEmail: {
    color: '#7D8592',
    fontSize: 12,
    fontWeight: '500',
    marginTop: 2,
  },
  callBtn: {
    width: 44,
    height: 44,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
  },
  billCard: {
    backgroundColor: '#181B20',
    padding: 20,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#262A31',
    gap: 12,
  },
  billRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  billLabel: {
    color: '#7D8592',
    fontSize: 14,
    fontWeight: '600',
  },
  billValue: {
    color: '#FFF',
    fontSize: 14,
    fontWeight: '800',
  },
  alertBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    marginTop: 8,
  },
  alertText: {
    color: '#FFC857',
    fontSize: 13,
    fontWeight: '700',
    flex: 1,
  },
  notesBox: {
    backgroundColor: 'rgba(255,255,255,0.03)',
    borderWidth: 1,
    borderColor: '#2A2F37',
    borderRadius: 16,
    padding: 16,
  },
  notesText: {
    color: '#B2B7C2',
    fontSize: 14,
    lineHeight: 20,
  },
  footer: {
    marginTop: 10,
    paddingBottom: 40,
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
  },
  actionRow: {
    flexDirection: 'row',
    gap: 16,
    width: '100%',
  },
  actionRowVertical: {
    flexDirection: 'column',
    gap: 12,
    width: '100%',
  },
  actionButton: {
    flex: 1,
    height: 60,
    borderRadius: 30,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
  },
  approveBtn: {
    // Background is primary color
  },
  rejectBtn: {
    borderWidth: 1.5,
    backgroundColor: 'transparent',
  },
  fullWidthBtn: {
    width: '100%',
    height: 60,
    borderRadius: 30,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
  },
  fullWidthBtnMuted: {
    width: '100%',
    height: 50,
    borderRadius: 25,
    borderWidth: 1.5,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
  },
  actionBtnTextDark: {
    color: '#000',
    fontSize: 16,
    fontWeight: '900',
  },
  actionBtnTextLight: {
    fontSize: 16,
    fontWeight: '900',
  },
  completedBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 12,
  },
  completedText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.7)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    borderWidth: 1,
    borderBottomWidth: 0,
    padding: 24,
    paddingBottom: 40,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  modalSubtitle: {
    fontSize: 14,
    lineHeight: 20,
    marginBottom: 20,
  },
  chipContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 20,
  },
  chip: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
    borderWidth: 1,
  },
  chipActive: {
    // Primary color active
  },
  chipText: {
    fontSize: 14,
    fontWeight: '600',
  },
  modalInput: {
    borderWidth: 1,
    borderRadius: 12,
    padding: 12,
    fontSize: 14,
    marginBottom: 24,
    height: 50,
  },
  modalSubmitBtn: {
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalSubmitBtnDisabled: {
    opacity: 0.5,
  },
  modalSubmitText: {
    color: '#000',
    fontSize: 16,
    fontWeight: 'bold',
  },
});