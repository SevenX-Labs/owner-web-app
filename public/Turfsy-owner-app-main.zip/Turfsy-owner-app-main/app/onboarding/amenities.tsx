import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React from 'react';
import {
    ScrollView,
    StatusBar,
    StyleSheet,
    Text,
    TextStyle,
    TouchableOpacity,
    View,
    ViewStyle,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuthContext } from '../../src/context/AuthContext';
import { fp, hp, isTablet, screenPadding, wp } from '../../src/utils/responsive';

const THEME = {
  background: '#000000',
  surface: '#1A1A1A',
  primary: '#ADFF00',
  textMuted: '#888888',
  border: '#333333',
};

const AMENITIES = [
  { label: 'Flood Lights',   icon: 'flashlight-outline', active: true  },
  { label: 'Parking',        icon: 'car-outline',         active: true  },
  { label: 'Washroom',       icon: 'water-outline',       active: true  },
  { label: 'Changing Room',  icon: 'shirt-outline',       active: false },
  { label: 'Drinking Water', icon: 'cafe-outline',        active: true  },
  { label: 'Seating Area',   icon: 'people-outline',      active: true  },
  { label: 'Cafeteria',      icon: 'restaurant-outline',  active: false },
] as const;

const AmenitiesScreen: React.FC = () => {
  const router = useRouter();
  const { establishSession } = useAuthContext();

  const handleComplete = async () => {
    // Setup is complete, record session to ensure dashboard opens rather than welcome screen
    await establishSession();
    router.replace('/(tabs)' as any);
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" />

      <View style={styles.stepContainer}>
        <View style={styles.progressBar}>
          <View style={[styles.progressFill, { width: '100%' }]} />
        </View>
        <Text style={styles.stepText}>STEP 4 OF 4</Text>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <Text style={styles.title}>Venue</Text>
          <Text style={[styles.title, { color: THEME.primary }]}>Amenities.</Text>
          <Text style={styles.subtitle}>
            Select the facilities available at your venue to help players choose you.
          </Text>
        </View>

        <View style={styles.listContainer}>
          {AMENITIES.map(({ label, icon, active }) => (
            <View key={label} style={[styles.row, active && styles.rowActive]}>
              <View style={styles.leftSide}>
                <View style={[styles.iconBox, active && styles.iconBoxActive]}>
                  <Ionicons name={icon as any} size={wp(22)} color={active ? THEME.primary : THEME.textMuted} />
                </View>
                <Text style={[styles.rowText, active && styles.rowTextActive]}>{label}</Text>
              </View>
              <View style={[styles.checkbox, active && styles.checkboxActive]}>
                {active && <Ionicons name="checkmark" size={wp(16)} color="#000" />}
              </View>
            </View>
          ))}
        </View>

        <View style={styles.footer}>
          <TouchableOpacity
            style={styles.submitBtn}
            onPress={handleComplete}
            activeOpacity={0.8}
          >
            <Text style={styles.submitBtnText}>Complete Setup</Text>
            <Ionicons name="rocket" size={wp(20)} color="#000" />
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: THEME.background } as ViewStyle,
  stepContainer: { paddingHorizontal: screenPadding, paddingTop: hp(10), alignItems: 'center' } as ViewStyle,
  progressBar: { height: hp(4), width: '100%', backgroundColor: '#1A1A1A', borderRadius: wp(2), overflow: 'hidden', marginBottom: hp(8) } as ViewStyle,
  progressFill: { height: '100%', backgroundColor: THEME.primary } as ViewStyle,
  stepText: { color: THEME.primary, fontSize: fp(12), fontWeight: '800', letterSpacing: 1.5 } as TextStyle,
  scrollContent: { paddingHorizontal: screenPadding, paddingTop: hp(40), paddingBottom: hp(40) } as ViewStyle,
  header: { marginBottom: hp(32) } as ViewStyle,
  title: { color: '#FFF', fontSize: fp(isTablet ? 52 : 42), fontWeight: '900', lineHeight: fp(isTablet ? 58 : 46) } as TextStyle,
  subtitle: { color: THEME.textMuted, fontSize: fp(16), marginTop: hp(12), lineHeight: fp(22) } as TextStyle,
  listContainer: { gap: hp(12) } as ViewStyle,
  row: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: THEME.surface, borderRadius: wp(20), padding: wp(16),
    borderWidth: 1, borderColor: THEME.border,
  } as ViewStyle,
  rowActive: { borderColor: 'rgba(173, 255, 0, 0.3)' } as ViewStyle,
  leftSide: { flexDirection: 'row', alignItems: 'center', gap: wp(16) } as ViewStyle,
  iconBox: {
    width: wp(44), height: wp(44), borderRadius: wp(12), backgroundColor: '#000',
    justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: THEME.border,
  } as ViewStyle,
  iconBoxActive: { borderColor: THEME.primary } as ViewStyle,
  rowText: { color: THEME.textMuted, fontSize: fp(16), fontWeight: '700' } as TextStyle,
  rowTextActive: { color: '#FFF' } as TextStyle,
  checkbox: {
    width: wp(28), height: wp(28), borderRadius: wp(10), borderWidth: 2,
    borderColor: '#333', justifyContent: 'center', alignItems: 'center',
  } as ViewStyle,
  checkboxActive: { backgroundColor: THEME.primary, borderColor: THEME.primary } as ViewStyle,
  footer: { marginTop: hp(40) } as ViewStyle,
  submitBtn: {
    backgroundColor: THEME.primary, height: hp(65), borderRadius: wp(32),
    flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: wp(10),
  } as ViewStyle,
  submitBtnText: { color: '#000', fontSize: fp(18), fontWeight: '800' } as TextStyle,
});

export default AmenitiesScreen;
