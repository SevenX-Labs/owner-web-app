import React from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  StatusBar,
  ViewStyle,
  TextStyle,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { wp, hp, fp, screenPadding, isTablet } from '../../src/utils/responsive';

const THEME = {
  background: '#000000',
  surface: '#1A1A1A',
  primary: '#ADFF00',
  textMuted: '#888888',
  border: '#333333',
};

const STATIC_DATA = {
  ownerName: 'Rahul Sharma',
  email: 'rahul.sharma@email.com',
  contactNumber: '8652502577',
  upiId: 'rahul@upi',
  idProof: 'Aadhar - XXXX XXXX 5678',
};

const OwnerDetailsScreen: React.FC = () => {
  const router = useRouter();

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" />

      <View style={styles.stepContainer}>
        <View style={styles.progressBar}>
          <View style={[styles.progressFill, { width: '50%' }]} />
        </View>
        <Text style={styles.stepText}>STEP 2 OF 4</Text>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <Text style={styles.title}>Personal</Text>
          <Text style={[styles.title, { color: THEME.primary }]}>Profile.</Text>
          <Text style={styles.subtitle}>Tell us about yourself and how you'd like to get paid.</Text>
        </View>

        {/* Venue Images */}
        <View style={styles.imageSection}>
          <Text style={styles.inputLabel}>VENUE IMAGES</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.imageScroll}>
            <View style={styles.uploadBtn}>
              <Ionicons name="camera" size={wp(24)} color={THEME.primary} />
              <Text style={styles.uploadText}>Add</Text>
            </View>
            {[1, 2, 3].map((i) => (
              <View key={i} style={styles.imagePlaceholder}>
                <Ionicons name="image-outline" size={wp(20)} color="#333" />
              </View>
            ))}
          </ScrollView>
        </View>

        {/* Form Fields */}
        <View style={styles.form}>
          <StaticField label="OWNER NAME" value={STATIC_DATA.ownerName} />
          <StaticField label="EMAIL ADDRESS" value={STATIC_DATA.email} />
          <StaticField label="CONTACT NUMBER" value={STATIC_DATA.contactNumber} />
          <StaticField label="UPI ID" value={STATIC_DATA.upiId} />
          <StaticField label="ID PROOF (AADHAR)" value={STATIC_DATA.idProof} />
        </View>

        <View style={styles.footer}>
          <TouchableOpacity
            style={styles.primaryBtn}
            onPress={() => router.push('/onboarding/turf-details' as any)}
            activeOpacity={0.8}
          >
            <Text style={styles.primaryBtnText}>Next: Turf Details</Text>
            <Ionicons name="arrow-forward" size={wp(20)} color="#000" />
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const StaticField = ({ label, value }: { label: string; value: string }) => (
  <View style={styles.field}>
    <Text style={styles.inputLabel}>{label}</Text>
    <View style={styles.inputWrapper}>
      <TextInput
        style={styles.input}
        value={value}
        editable={false}
        selectionColor={THEME.primary}
      />
      <Ionicons name="checkmark-circle" size={wp(20)} color={THEME.primary} />
    </View>
  </View>
);

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: THEME.background } as ViewStyle,
  stepContainer: { paddingHorizontal: screenPadding, paddingTop: hp(10), alignItems: 'center' } as ViewStyle,
  progressBar: { height: hp(4), width: '100%', backgroundColor: '#1A1A1A', borderRadius: wp(2), overflow: 'hidden', marginBottom: hp(8) } as ViewStyle,
  progressFill: { height: '100%', backgroundColor: THEME.primary } as ViewStyle,
  stepText: { color: THEME.primary, fontSize: fp(12), fontWeight: '800', letterSpacing: 1.5 } as TextStyle,
  scrollContent: { paddingHorizontal: screenPadding, paddingTop: hp(40), paddingBottom: hp(40) } as ViewStyle,
  header: { marginBottom: hp(32) } as ViewStyle,
  title: { color: '#FFF', fontSize: fp(isTablet ? 52 : 42), fontWeight: '900', lineHeight: fp(isTablet ? 58 : 46) } as TextStyle,
  subtitle: { color: THEME.textMuted, fontSize: fp(16), marginTop: hp(12), lineHeight: fp(22) } as TextStyle,
  imageSection: { marginBottom: hp(30) } as ViewStyle,
  imageScroll: { flexDirection: 'row', marginTop: hp(12) } as ViewStyle,
  uploadBtn: {
    width: wp(80), height: wp(80), borderRadius: wp(16), backgroundColor: THEME.surface,
    justifyContent: 'center', alignItems: 'center', borderStyle: 'dashed',
    borderWidth: 1, borderColor: THEME.primary, marginRight: wp(12),
  } as ViewStyle,
  uploadText: { color: THEME.primary, fontSize: fp(10), fontWeight: '800', marginTop: hp(4) } as TextStyle,
  imagePlaceholder: {
    width: wp(80), height: wp(80), borderRadius: wp(16), backgroundColor: THEME.surface,
    justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: THEME.border, marginRight: wp(12),
  } as ViewStyle,
  form: { gap: hp(20) } as ViewStyle,
  field: { gap: hp(10) } as ViewStyle,
  inputLabel: { color: THEME.textMuted, fontSize: fp(10), fontWeight: '800', letterSpacing: 1.2, marginLeft: wp(4) } as TextStyle,
  inputWrapper: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: THEME.surface,
    height: hp(60), borderRadius: wp(16), paddingHorizontal: wp(16), borderWidth: 1, borderColor: THEME.border,
  } as ViewStyle,
  input: { flex: 1, color: '#FFF', fontSize: fp(16), fontWeight: '600' } as TextStyle,
  footer: { marginTop: hp(40) } as ViewStyle,
  primaryBtn: {
    backgroundColor: THEME.primary, height: hp(65), borderRadius: wp(32),
    flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: wp(10),
  } as ViewStyle,
  primaryBtnText: { color: '#000', fontSize: fp(18), fontWeight: '800' } as TextStyle,
});

export default OwnerDetailsScreen;
