import React from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  StatusBar,
  ViewStyle,
  TextStyle,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { wp, hp, fp, screenPadding, isTablet } from '../../src/utils/responsive';

const THEME = {
  background: '#000000',
  surface: '#1A1A1A',
  primary: '#ADFF00',
  textMuted: '#888888',
  border: '#333333',
};

const STATIC_DATA = {
  turfName: 'Green Arena Turf',
  description: 'Premium 5-a-side football turf with floodlights',
  sportsType: 'Football, Cricket',
  turfSize: '60x40 ft',
  address: 'Survey No. 12, Baner Road, Pune',
  city: 'Pune',
  pincode: '411045',
  openTime: '06:00 AM',
  closeTime: '11:00 PM',
  minSlotDuration: '60 mins',
  priceWeekdayDay: '800',
  priceWeekdayNight: '1200',
  priceWeekendDay: '1000',
  priceWeekendNight: '1500',
};

const TurfDetailsScreen: React.FC = () => {
  const router = useRouter();

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" />

      <View style={styles.stepContainer}>
        <View style={styles.progressBar}>
          <View style={[styles.progressFill, { width: '75%' }]} />
        </View>
        <Text style={styles.stepText}>STEP 3 OF 4</Text>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <Text style={styles.title}>Venue</Text>
          <Text style={[styles.title, { color: THEME.primary }]}>Details.</Text>
          <Text style={styles.subtitle}>Define your space, hours, and dynamic pricing rules.</Text>
        </View>

        {/* General Information */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>GENERAL INFORMATION</Text>
          <StaticField label="TURF NAME" value={STATIC_DATA.turfName} />
          <StaticField label="DESCRIPTION" value={STATIC_DATA.description} multiline />
          <StaticField label="SPORTS TYPE" value={STATIC_DATA.sportsType} />
          <StaticField label="TURF SIZE" value={STATIC_DATA.turfSize} />
        </View>

        {/* Location */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>LOCATION</Text>
          <StaticField label="ADDRESS (LOCATION)" value={STATIC_DATA.address} />
          <View style={styles.row}>
            <View style={styles.flexOne}><StaticField label="CITY" value={STATIC_DATA.city} /></View>
            <View style={styles.flexOne}><StaticField label="PINCODE" value={STATIC_DATA.pincode} /></View>
          </View>
        </View>

        {/* Operations */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>OPERATIONS</Text>
          <View style={styles.row}>
            <View style={styles.flexOne}><StaticField label="OPEN TIME" value={STATIC_DATA.openTime} /></View>
            <View style={styles.flexOne}><StaticField label="CLOSE TIME" value={STATIC_DATA.closeTime} /></View>
          </View>
          <StaticField label="MINIMUM SLOT DURATION" value={STATIC_DATA.minSlotDuration} />
        </View>

        {/* Pricing */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>DYNAMIC PRICING (INR)</Text>
          <View style={styles.pricingGrid}>
            <PricingBox label="WKDAY DAY" value={STATIC_DATA.priceWeekdayDay} icon="sunny-outline" />
            <PricingBox label="WKDAY NIGHT" value={STATIC_DATA.priceWeekdayNight} icon="moon-outline" />
          </View>
          <View style={styles.pricingGrid}>
            <PricingBox label="WKND DAY" value={STATIC_DATA.priceWeekendDay} icon="calendar-outline" />
            <PricingBox label="WKND NIGHT" value={STATIC_DATA.priceWeekendNight} icon="sparkles-outline" />
          </View>
        </View>

        <View style={styles.footer}>
          <TouchableOpacity
            style={styles.primaryBtn}
            onPress={() => router.push('/onboarding/amenities' as any)}
            activeOpacity={0.8}
          >
            <Text style={styles.primaryBtnText}>Next: Amenities</Text>
            <Ionicons name="arrow-forward" size={wp(20)} color="#000" />
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const StaticField = ({ label, value, multiline }: { label: string; value: string; multiline?: boolean }) => (
  <View style={styles.field}>
    <Text style={styles.inputLabel}>{label}</Text>
    <TextInput
      style={[styles.input, multiline ? { height: hp(100), textAlignVertical: 'top', paddingTop: hp(15) } as TextStyle : {}]}
      value={value}
      editable={false}
      multiline={multiline}
      selectionColor={THEME.primary}
    />
  </View>
);

const PricingBox = ({ label, value, icon }: { label: string; value: string; icon: keyof typeof Ionicons.glyphMap }) => (
  <View style={styles.pricingBox}>
    <View style={styles.pricingHeader}>
      <Ionicons name={icon} size={wp(14)} color={THEME.primary} />
      <Text style={styles.pricingLabel}>{label}</Text>
    </View>
    <Text style={styles.pricingValue}>₹{value}</Text>
  </View>
);

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: THEME.background } as ViewStyle,
  stepContainer: { paddingHorizontal: screenPadding, paddingTop: hp(10), alignItems: 'center' } as ViewStyle,
  progressBar: { height: hp(4), width: '100%', backgroundColor: '#1A1A1A', borderRadius: wp(2), overflow: 'hidden', marginBottom: hp(8) } as ViewStyle,
  progressFill: { height: '100%', backgroundColor: THEME.primary } as ViewStyle,
  stepText: { color: THEME.primary, fontSize: fp(12), fontWeight: '800', letterSpacing: 1.5 } as TextStyle,
  scrollContent: { paddingHorizontal: screenPadding, paddingTop: hp(40), paddingBottom: hp(40) } as ViewStyle,
  header: { marginBottom: hp(32) } as ViewStyle,
  title: { color: '#FFF', fontSize: fp(isTablet ? 52 : 42), fontWeight: '900', lineHeight: fp(isTablet ? 58 : 46) } as TextStyle,
  subtitle: { color: THEME.textMuted, fontSize: fp(16), marginTop: hp(12), lineHeight: fp(22) } as TextStyle,
  section: { marginBottom: hp(32), gap: hp(16) } as ViewStyle,
  sectionLabel: { color: THEME.primary, fontSize: fp(10), fontWeight: '900', letterSpacing: 2 } as TextStyle,
  row: { flexDirection: 'row', gap: wp(12) } as ViewStyle,
  flexOne: { flex: 1 } as ViewStyle,
  field: { gap: hp(8) } as ViewStyle,
  inputLabel: { color: THEME.textMuted, fontSize: fp(9), fontWeight: '800', letterSpacing: 1, marginLeft: wp(4) } as TextStyle,
  input: {
    backgroundColor: THEME.surface, color: '#FFF', fontSize: fp(15), fontWeight: '600',
    height: hp(56), borderRadius: wp(16), paddingHorizontal: wp(16), borderWidth: 1, borderColor: THEME.border,
  } as TextStyle,
  pricingGrid: { flexDirection: 'row', gap: wp(12) } as ViewStyle,
  pricingBox: { flex: 1, backgroundColor: THEME.surface, borderRadius: wp(16), padding: wp(16), borderWidth: 1, borderColor: THEME.border } as ViewStyle,
  pricingHeader: { flexDirection: 'row', alignItems: 'center', gap: wp(6), marginBottom: hp(8) } as ViewStyle,
  pricingLabel: { color: THEME.textMuted, fontSize: fp(9), fontWeight: '800' } as TextStyle,
  pricingValue: { color: '#FFF', fontSize: fp(18), fontWeight: '900' } as TextStyle,
  footer: { marginTop: hp(20) } as ViewStyle,
  primaryBtn: {
    backgroundColor: THEME.primary, height: hp(65), borderRadius: wp(32),
    flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: wp(10),
  } as ViewStyle,
  primaryBtnText: { color: '#000', fontSize: fp(18), fontWeight: '800' } as TextStyle,
});

export default TurfDetailsScreen;
