import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React, { useCallback, useRef, useState } from 'react';
import {
  Animated,
  FlatList,
  Modal,
  PanResponder,
  StyleSheet,
  Text,
  TouchableOpacity,
  TouchableWithoutFeedback,
  View,
} from 'react-native';

import { AppHeader } from '@/src/components/common/AppHeader';
import { Screen } from '@/src/components/layout/Screen';
import { useResponsive } from '@/src/utils/responsive';
import { useAppTheme } from '@/src/hooks/useAppTheme';

interface NotificationItem {
  id: string;
  title: string;
  message: string;
  time: string;
  type: 'booking' | 'payment' | 'system';
  isRead: boolean;
}

const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: '1',
    title: 'New Booking Request',
    message: 'Rohan Sharma has requested a booking for 7 PM today.',
    time: '2 mins ago',
    type: 'booking',
    isRead: false,
  },
  {
    id: '2',
    title: 'Payment Received',
    message: 'Payment of ₹1,200 received for booking #TRF9021.',
    time: '45 mins ago',
    type: 'payment',
    isRead: false,
  },
  {
    id: '3',
    title: 'System Update',
    message: 'New features are now available! Check out the dashboard.',
    time: '2 hours ago',
    type: 'system',
    isRead: true,
  },
  {
    id: '4',
    title: 'Booking Cancelled',
    message: 'The booking for Champions Arena at 9 PM has been cancelled.',
    time: '5 hours ago',
    type: 'booking',
    isRead: true,
  },
];

const DELETE_THRESHOLD = -80;

const getStyles = (theme: any) => StyleSheet.create({
  container: {
    paddingBottom: 24,
  },
  notificationWrapper: {
    marginBottom: 12,
    borderRadius: 20,
    overflow: 'hidden',
  },
  deleteBackground: {
    position: 'absolute',
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,
    backgroundColor: theme.colors.danger,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'flex-end',
    paddingRight: 28,
  },
  deleteContent: {
    alignItems: 'center',
    gap: 4,
  },
  deleteText: {
    color: '#FFF',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1,
  },
  notificationCard: {
    padding: 16,
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 14,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: theme.colors.border,
    backgroundColor: theme.colors.surfaceMuted,
  },
  unreadCard: {
    backgroundColor: theme.colors.primarySoftOpaque,
    borderColor: theme.colors.primary + '40',
  },
  iconWrap: {
    width: 46,
    height: 46,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: theme.colors.surface,
    borderWidth: 1,
    borderColor: theme.colors.border,
  },
  iconWrapUnread: {
    backgroundColor: theme.colors.primary + '18',
    borderColor: theme.colors.primary + '30',
  },
  content: {
    flex: 1,
    gap: 4,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flex: 1,
  },
  title: {
    color: theme.colors.text,
    fontWeight: '800',
    letterSpacing: 0.2,
    flex: 1,
  },
  time: {
    color: theme.colors.textMuted,
    fontWeight: '600',
  },
  message: {
    color: theme.colors.textMuted,
    lineHeight: 18,
    fontWeight: '500',
  },
  unreadDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: theme.colors.primary,
    flexShrink: 0,
  },
  newBadge: {
    backgroundColor: theme.colors.primary + '20',
    paddingHorizontal: 10,
    paddingVertical: 3,
    borderRadius: 8,
    marginTop: 6,
    alignSelf: 'flex-start',
  },
  newBadgeText: {
    color: theme.colors.primary,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  emptyState: {
    paddingVertical: 100,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 16,
  },
  emptyIcon: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: theme.colors.surfaceMuted,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: theme.colors.border,
  },
  emptyTitle: {
    color: theme.colors.text,
    fontWeight: '700',
  },
  emptySubtitle: {
    color: theme.colors.textMuted,
    fontWeight: '500',
  },
  // Menu overlay styles
  menuOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.3)',
  },
  menuContainer: {
    position: 'absolute',
    right: 24,
    top: 110,
    minWidth: 220,
    backgroundColor: theme.colors.surface,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: theme.colors.border,
    paddingVertical: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.2,
    shadowRadius: 16,
    elevation: 12,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 20,
    gap: 14,
  },
  menuItemBorder: {
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border,
  },
  menuItemText: {
    color: theme.colors.text,
    fontSize: 14,
    fontWeight: '700',
  },
  menuItemTextDanger: {
    color: theme.colors.danger,
  },
  swipeHint: {
    color: theme.colors.textMuted,
    fontSize: 12,
    fontWeight: '600',
    fontStyle: 'italic',
  },
  unreadBadge: {
    backgroundColor: theme.colors.primary,
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderRadius: 12,
  },
  unreadBadgeText: {
    color: '#000',
    fontWeight: '900',
  },
  badgeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    gap: 8,
  },
});

// Swipeable notification item component
function SwipeableNotification({
  item,
  onDelete,
  onMarkRead,
  theme,
  styles,
  responsive,
}: {
  item: NotificationItem;
  onDelete: (id: string) => void;
  onMarkRead: (id: string) => void;
  theme: any;
  styles: any;
  responsive: any;
}) {
  const translateX = useRef(new Animated.Value(0)).current;

  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => false,
      onMoveShouldSetPanResponder: (_, gestureState) => {
        return Math.abs(gestureState.dx) > 10 && Math.abs(gestureState.dy) < 10;
      },
      onPanResponderMove: (_, gestureState) => {
        if (gestureState.dx < 0) {
          translateX.setValue(Math.max(gestureState.dx, -120));
        }
      },
      onPanResponderRelease: (_, gestureState) => {
        if (gestureState.dx < DELETE_THRESHOLD) {
          Animated.timing(translateX, {
            toValue: -500,
            duration: 300,
            useNativeDriver: true,
          }).start(() => {
            onDelete(item.id);
          });
        } else {
          Animated.spring(translateX, {
            toValue: 0,
            tension: 40,
            friction: 8,
            useNativeDriver: true,
          }).start();
        }
      },
    })
  ).current;

  const getIcon = (type: NotificationItem['type']): keyof typeof Ionicons.glyphMap => {
    switch (type) {
      case 'booking': return 'calendar';
      case 'payment': return 'card';
      case 'system': return 'notifications';
      default: return 'notifications';
    }
  };

  return (
    <View style={styles.notificationWrapper}>
      {/* Delete Background – behind the card */}
      <View style={styles.deleteBackground}>
        <View style={styles.deleteContent}>
          <Ionicons name="trash-outline" size={22} color="#FFF" />
          <Text style={styles.deleteText}>DELETE</Text>
        </View>
      </View>

      {/* Swipeable Card on top */}
      <Animated.View
        {...panResponder.panHandlers}
        style={{ transform: [{ translateX }] }}
      >
        <TouchableOpacity
          activeOpacity={1}
          onPress={() => !item.isRead && onMarkRead(item.id)}
        >
          <View style={[
            styles.notificationCard,
            !item.isRead && styles.unreadCard,
          ]}>
            <View style={[styles.iconWrap, !item.isRead && styles.iconWrapUnread]}>
              <Ionicons
                name={getIcon(item.type)}
                size={22}
                color={item.isRead ? theme.colors.textMuted : theme.colors.primary}
              />
            </View>
            <View style={styles.content}>
              <View style={styles.headerRow}>
                <View style={styles.titleRow}>
                  {!item.isRead && <View style={styles.unreadDot} />}
                  <Text
                    style={[styles.title, { fontSize: responsive.fp(14) }]}
                    numberOfLines={1}
                  >
                    {item.title}
                  </Text>
                </View>
                <Text style={[styles.time, { fontSize: responsive.fp(11) }]}>{item.time}</Text>
              </View>
              <Text style={[styles.message, { fontSize: responsive.fp(13) }]} numberOfLines={2}>
                {item.message}
              </Text>
              {!item.isRead && (
                <View style={styles.newBadge}>
                  <Text style={[styles.newBadgeText, { fontSize: responsive.fp(10) }]}>NEW</Text>
                </View>
              )}
            </View>
          </View>
        </TouchableOpacity>
      </Animated.View>
    </View>
  );
}

export default function NotificationsScreen() {
  const router = useRouter();
  const responsive = useResponsive();
  const { theme } = useAppTheme();
  const styles = getStyles(theme);
  const [notifications, setNotifications] = useState<NotificationItem[]>(INITIAL_NOTIFICATIONS);
  const [menuVisible, setMenuVisible] = useState(false);

  const handleDelete = useCallback((id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  const handleMarkRead = useCallback((id: string) => {
    setNotifications(prev =>
      prev.map(n => n.id === id ? { ...n, isRead: true } : n)
    );
  }, []);

  const handleMarkAllRead = useCallback(() => {
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
    setMenuVisible(false);
  }, []);

  const handleClearAll = useCallback(() => {
    setNotifications([]);
    setMenuVisible(false);
  }, []);

  const unreadCount = notifications.filter(n => !n.isRead).length;

  const renderItem = ({ item }: { item: NotificationItem }) => (
    <SwipeableNotification
      item={item}
      onDelete={handleDelete}
      onMarkRead={handleMarkRead}
      theme={theme}
      styles={styles}
      responsive={responsive}
    />
  );

  return (
    <Screen
      style={{ flex: 1 }}
      contentStyle={{ paddingHorizontal: responsive.isTablet ? 32 : 24, paddingTop: 12 }}
    >
      <AppHeader
        title="Notifications"
        eyebrow="STAY UPDATED"
        showBack
        action={{
          icon: 'ellipsis-horizontal',
          onPress: () => setMenuVisible(true),
        }}
      />

      {/* Unread Count Badge */}
      {unreadCount > 0 && (
        <View style={styles.badgeRow}>
          <View style={styles.unreadBadge}>
            <Text style={[styles.unreadBadgeText, { fontSize: responsive.fp(11) }]}>
              {unreadCount} UNREAD
            </Text>
          </View>
          <Text style={styles.swipeHint}>← Swipe left to delete</Text>
        </View>
      )}

      {notifications.length > 0 ? (
        <FlatList
          data={notifications}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.container}
          showsVerticalScrollIndicator={false}
        />
      ) : (
        <View style={styles.emptyState}>
          <View style={styles.emptyIcon}>
            <Ionicons name="notifications-off-outline" size={42} color={theme.colors.textMuted} />
          </View>
          <Text style={[styles.emptyTitle, { fontSize: responsive.fp(18) }]}>All caught up!</Text>
          <Text style={[styles.emptySubtitle, { fontSize: responsive.fp(13) }]}>
            No notifications to display
          </Text>
        </View>
      )}

      {/* 3-Dot Menu Modal */}
      <Modal
        transparent
        visible={menuVisible}
        animationType="fade"
        onRequestClose={() => setMenuVisible(false)}
      >
        <TouchableWithoutFeedback onPress={() => setMenuVisible(false)}>
          <View style={styles.menuOverlay}>
            <TouchableWithoutFeedback>
              <View style={styles.menuContainer}>
                <TouchableOpacity
                  style={[styles.menuItem, styles.menuItemBorder]}
                  onPress={handleMarkAllRead}
                  activeOpacity={0.7}
                >
                  <Ionicons name="checkmark-done-outline" size={20} color={theme.colors.primary} />
                  <Text style={styles.menuItemText}>Mark All as Read</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.menuItem}
                  onPress={handleClearAll}
                  activeOpacity={0.7}
                >
                  <Ionicons name="trash-outline" size={20} color={theme.colors.danger} />
                  <Text style={[styles.menuItemText, styles.menuItemTextDanger]}>Clear All</Text>
                </TouchableOpacity>
              </View>
            </TouchableWithoutFeedback>
          </View>
        </TouchableWithoutFeedback>
      </Modal>
    </Screen>
  );
}
