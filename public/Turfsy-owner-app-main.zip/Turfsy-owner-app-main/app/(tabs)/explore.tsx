import React from 'react';
import { 
  StyleSheet, 
  View, 
  TouchableOpacity, 
  ViewStyle, 
  TextStyle, 
  Text 
} from 'react-native';
import { Image, ImageStyle } from 'expo-image'; // Added ImageStyle for perfect typing
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';

import { Collapsible } from '@/components/ui/collapsible';
import ParallaxScrollView from '@/components/parallax-scroll-view';
import { ThemedText } from '@/components/themed-text';
import { ThemedView } from '@/components/themed-view';

const THEME = {
  background: '#000000',
  primary: '#ADFF00', 
  surface: '#1A1A1A',
  textMuted: '#888888',
  border: '#262626',
};

export default function ExploreScreen() {
  const router = useRouter();

  const handleNavigation = (path: string) => {
    router.push(path as any);
  };

  return (
    <ParallaxScrollView
      headerBackgroundColor={{ light: '#1A1A1A', dark: '#000000' }}
      headerImage={
        <Ionicons
          size={280}
          name="rocket-outline"
          style={styles.headerImage as any} 
        />
      }>
      
      <ThemedView style={styles.titleContainer}>
        <View>
          <ThemedText type="defaultSemiBold" style={styles.brandTag}>TURFSY INSIGHTS</ThemedText>
          <ThemedText type="title" style={styles.mainTitle}>Explore</ThemedText>
        </View>
        <TouchableOpacity style={styles.helpBtn} activeOpacity={0.7}>
          <Ionicons name="help-buoy-outline" size={24} color={THEME.primary} />
        </TouchableOpacity>
      </ThemedView>

      <ThemedText style={styles.description}>
        Discover new ways to scale your turf business and optimize your bookings.
      </ThemedText>

      <Collapsible title="Booking Optimization">
        <ThemedText style={styles.collapsibleText}>
          Learn how to use <ThemedText type="defaultSemiBold" style={{color: THEME.primary}}>Dynamic Pricing</ThemedText> to 
          increase revenue during peak hours.
        </ThemedText>
        <TouchableOpacity 
          style={styles.actionBtn}
          onPress={() => handleNavigation('/(tabs)/bookings')}
          activeOpacity={0.8}
        >
          <ThemedText style={styles.actionBtnText}>Configure Pricing</ThemedText>
          <Ionicons name="chevron-forward" size={16} color="#000" />
        </TouchableOpacity>
      </Collapsible>

      <Collapsible title="Analytics Dashboard">
        <ThemedText style={styles.collapsibleText}>
          Track your occupancy rates and most popular time slots.
        </ThemedText>
        <View style={styles.imageContainer}>
          <Image
            source={{ uri: 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?q=80&w=500' }}
            // THE ULTIMATE FIX: Using a typed object spread
            style={[styles.featureImage as ImageStyle]} 
            contentFit="cover"
            transition={500}
          />
          <View style={styles.imageOverlay}>
            <Text style={styles.overlayText}>Victory Arena Stats</Text>
          </View>
        </View>
      </Collapsible>

      <View style={styles.footerPadding} />
    </ParallaxScrollView>
  );
}

const styles = StyleSheet.create({
  headerImage: {
    color: '#222',
    bottom: -50,
    left: -20,
    position: 'absolute',
  } as TextStyle,
  titleContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    backgroundColor: 'transparent',
    marginTop: 10,
  } as ViewStyle,
  brandTag: {
    color: THEME.primary,
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 1.5,
  } as TextStyle,
  mainTitle: {
    fontSize: 42,
    fontWeight: '900',
    color: '#FFF',
    letterSpacing: -1,
  } as TextStyle,
  description: {
    color: THEME.textMuted,
    fontSize: 16,
    lineHeight: 24,
    marginTop: 10,
    marginBottom: 20,
  } as TextStyle,
  collapsibleText: {
    color: '#CCC',
    fontSize: 15,
    lineHeight: 22,
    paddingBottom: 10,
  } as TextStyle,
  actionBtn: {
    backgroundColor: THEME.primary,
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginTop: 10,
  } as ViewStyle,
  actionBtnText: {
    color: '#000',
    fontWeight: '800',
    fontSize: 14,
  } as TextStyle,
  imageContainer: {
    marginTop: 15,
    borderRadius: 20,
    overflow: 'hidden',
    height: 180,
    borderWidth: 1,
    borderColor: THEME.border,
  } as ViewStyle,
  featureImage: {
    width: '100%',
    height: '100%',
  } as ViewStyle, // Ensure width/height is present for layout
  imageOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(0,0,0,0.6)',
    padding: 12,
  } as ViewStyle,
  overlayText: {
    color: '#FFF',
    fontSize: 12,
    fontWeight: '700',
  } as TextStyle,
  helpBtn: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: THEME.surface,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: THEME.border,
  } as ViewStyle,
  footerPadding: {
    height: 60,
  } as ViewStyle,
});