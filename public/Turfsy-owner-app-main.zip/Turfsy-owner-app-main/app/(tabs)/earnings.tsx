export { default } from '@/src/screens/Earnings/EarningsScreen';
