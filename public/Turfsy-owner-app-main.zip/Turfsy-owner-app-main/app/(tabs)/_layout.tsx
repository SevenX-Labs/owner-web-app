import { Redirect, Tabs } from 'expo-router';
import React from 'react';

import { useAuthContext } from '@/src/context/AuthContext';
import { ResponsiveTabBar } from '@/src/navigation/BottomTabs';

export default function TabLayout() {
  const { isAuthenticated, isLoading } = useAuthContext();

  if (!isLoading && !isAuthenticated) {
    return <Redirect href="/(auth)/welcome" />;
  }

  return (
    <>
      <Tabs
        tabBar={(props) => <ResponsiveTabBar {...props} />}
        screenOptions={{
          headerShown: false,
        }}
      >
        <Tabs.Screen name="index" options={{ title: 'Home' }} />
        <Tabs.Screen name="bookings" options={{ title: 'Booking' }} />
        <Tabs.Screen name="analytics" options={{ title: 'Analytics' }} />
        <Tabs.Screen name="turf" options={{ title: 'Turf' }} />
        <Tabs.Screen name="profile" options={{ title: 'Profile' }} />
        <Tabs.Screen name="earnings" options={{ href: null }} />
        <Tabs.Screen name="explore" options={{ href: null }} />
      </Tabs>
    </>
  );
}
