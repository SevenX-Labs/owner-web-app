import React from 'react';
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  StatusBar,
  Image,
  useWindowDimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';

import { useResponsive } from '@/src/utils/responsive';
import { useAppTheme } from '@/src/hooks/useAppTheme';

const WelcomeScreen: React.FC = () => {
  const router = useRouter();
  const responsive = useResponsive();
  const { theme } = useAppTheme();
  const { width } = useWindowDimensions();

  const handleNavigate = (path: string): void => {
    router.push(path as any);
  };

  const isWeb = width > 768;
  const pad = responsive.isTablet || isWeb ? 40 : 24;
  const styles = getStyles(theme, isWeb);

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#000" />
      <SafeAreaView style={styles.safeArea}>
        <View style={[styles.contentWrapper, { paddingHorizontal: pad }]}>
          
          {/* Logo Top */}
          <View style={styles.topLogo}>
             <Image source={require('@/assets/images/logo.png')} style={styles.logoImage} resizeMode="contain" />
             <Text style={styles.brandName}>Owner App</Text>
          </View>

          <View style={styles.mainContent}>
            <View style={styles.textSection}>
              <Text style={styles.heroTitle} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.5}>
                Grow Your
              </Text>
              <Text style={styles.heroTitleAccent} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.5}>
                Business.
              </Text>
              <Text style={styles.heroSubtitle}>
                The ultimate platform for turf owners to manage bookings, payments, and players effortlessly.
              </Text>
            </View>
          </View>

          {/* Button Section */}
          <View style={styles.buttonSection}>
            <TouchableOpacity
              style={styles.primaryButton}
              activeOpacity={0.8}
              onPress={() => handleNavigate('/(auth)/login')}
            >
              <Text style={styles.primaryButtonText}>Get Started</Text>
              <Ionicons name="arrow-forward" size={20} color="#000" />
            </TouchableOpacity>
          </View>
        </View>
      </SafeAreaView>
    </View>
  );
};

function getStyles(theme: any, isWeb: boolean) {
  return StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#000000',
    },
    safeArea: {
      flex: 1,
    },
    contentWrapper: {
      flex: 1,
      maxWidth: isWeb ? 600 : '100%',
      width: '100%',
      alignSelf: 'center',
      justifyContent: 'space-between',
      paddingTop: isWeb ? 40 : 20,
      paddingBottom: isWeb ? 40 : 20,
    },
    topLogo: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: isWeb ? 'center' : 'flex-start',
      gap: 12,
    },
    logoImage: {
      width: 44,
      height: 44,
    },
    brandName: {
      fontFamily: theme.fonts.black,
      fontSize: 24,
      color: '#FFFFFF',
      letterSpacing: -0.5,
    },
    mainContent: {
      flex: 1,
      justifyContent: 'center',
    },
    textSection: {
      alignItems: isWeb ? 'center' : 'flex-start',
    },
    heroTitle: {
      fontFamily: theme.fonts.black,
      fontSize: isWeb ? 72 : 56,
      color: '#FFFFFF',
      lineHeight: isWeb ? 80 : 64,
      textAlign: isWeb ? 'center' : 'left',
    },
    heroTitleAccent: {
      fontFamily: theme.fonts.black,
      fontSize: isWeb ? 72 : 56,
      color: theme.colors.primary,
      lineHeight: isWeb ? 80 : 64,
      textAlign: isWeb ? 'center' : 'left',
    },
    heroSubtitle: {
      fontFamily: theme.fonts.regular,
      fontSize: isWeb ? 18 : 16,
      color: 'rgba(255,255,255,0.7)',
      lineHeight: isWeb ? 28 : 24,
      marginTop: 20,
      maxWidth: isWeb ? '80%' : '90%',
      textAlign: isWeb ? 'center' : 'left',
    },
    buttonSection: {
      gap: 16,
    },
    primaryButton: {
      backgroundColor: theme.colors.primary,
      flexDirection: 'row',
      justifyContent: 'center',
      alignItems: 'center',
      gap: 12,
      height: 60,
      borderRadius: 16,
    },
    primaryButtonText: {
      fontFamily: theme.fonts.bold,
      fontSize: 18,
      color: '#000000',
    },
    secondaryButton: {
      height: 50,
      justifyContent: 'center',
      alignItems: 'center',
    },
    secondaryButtonText: {
      fontFamily: theme.fonts.semiBold,
      fontSize: 15,
      color: 'rgba(255,255,255,0.6)',
      textDecorationLine: 'underline',
    },
  });
}

export default WelcomeScreen;