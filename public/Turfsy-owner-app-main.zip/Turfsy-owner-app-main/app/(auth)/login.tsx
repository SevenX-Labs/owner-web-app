import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React from 'react';
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  Image,
  useWindowDimensions,
  Keyboard,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { useResponsive } from '@/src/utils/responsive';
import { useAppTheme } from '@/src/hooks/useAppTheme';

const OwnerLogin: React.FC = () => {
  const router = useRouter();
  const responsive = useResponsive();
  const { theme } = useAppTheme();
  const { width } = useWindowDimensions();
  
  const [phone, setPhone] = React.useState('');
  const [isLoading, setIsLoading] = React.useState(false);
  const [errorMsg, setErrorMsg] = React.useState('');
  const [isKeyboardVisible, setKeyboardVisible] = React.useState(false);

  React.useEffect(() => {
    const showSub = Keyboard.addListener(Platform.OS === 'ios' ? 'keyboardWillShow' : 'keyboardDidShow', () => setKeyboardVisible(true));
    const hideSub = Keyboard.addListener(Platform.OS === 'ios' ? 'keyboardWillHide' : 'keyboardDidHide', () => setKeyboardVisible(false));
    return () => {
      showSub.remove();
      hideSub.remove();
    };
  }, []);

  const isWeb = width > 768;
  const pad = responsive.isTablet || isWeb ? 40 : 24;
  const styles = getStyles(theme, isWeb);

  const handleSendCode = async () => {
    setErrorMsg('');
    if (!phone || phone.length < 10) {
      setErrorMsg('Please enter a valid 10-digit mobile number.');
      return;
    }
    try {
      setIsLoading(true);
      const res = await fetch('https://turfsy.onrender.com/api/v3/auth/owner/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Failed to send OTP.');
      router.push({ pathname: '/(auth)/otp', params: { phone } });
    } catch (error: any) {
      setErrorMsg(error.message || 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#000" />
      <SafeAreaView style={styles.flex}>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.flex}>
          <ScrollView contentContainerStyle={[styles.scrollContent, { paddingHorizontal: pad }]} keyboardShouldPersistTaps="handled" bounces={false}>
            <View style={styles.contentWrapper}>
              
              <View style={styles.topLogo}>
                <Image source={require('@/assets/images/logo.png')} style={styles.logoImage} resizeMode="contain" />
                <Text style={styles.brandName}>Owner App</Text>
              </View>

              <View style={styles.mainContent}>
                <View style={styles.header}>
                  <Text style={styles.title} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.7}>Manage Your</Text>
                  <Text style={styles.titleAccent} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.7}>Empire.</Text>
                  <Text style={styles.subtitle}>Enter your mobile number to access your dashboard and bookings.</Text>
                </View>

                <View style={styles.inputWrapper}>
                  <Text style={styles.inputLabel}>MOBILE NUMBER</Text>
                  <View style={styles.phoneInputContainer}>
                    <Text style={styles.countryCode}>+91</Text>
                    <View style={styles.divider} />
                    <TextInput
                      style={styles.input}
                      value={phone}
                      onChangeText={(text) => {
                        setErrorMsg('');
                        const cleaned = text.replace(/[^0-9]/g, '');
                        setPhone(cleaned);
                        if (cleaned.length === 10) {
                          Keyboard.dismiss();
                        }
                      }}
                      keyboardType="numeric"
                      placeholder="Enter 10-digit number"
                      placeholderTextColor={theme.colors.textMuted}
                      maxLength={10}
                      selectionColor={theme.colors.primary}
                      editable={!isLoading}
                    />
                    {phone.length === 10 && <Ionicons name="checkmark-circle" size={22} color={theme.colors.success} />}
                  </View>
                  {!!errorMsg && <Text style={styles.errorText}>{errorMsg}</Text>}
                </View>
              </View>

              {!isKeyboardVisible && (
                <View style={styles.footer}>
                  <TouchableOpacity style={[styles.primaryBtn, isLoading && { opacity: 0.7 }]} onPress={handleSendCode} activeOpacity={0.8} disabled={isLoading}>
                    {isLoading ? (
                      <ActivityIndicator color="#000" />
                    ) : (
                      <>
                        <Text style={styles.primaryBtnText}>Get Verification Code</Text>
                        <Ionicons name="arrow-forward" size={20} color="#000" />
                      </>
                    )}
                  </TouchableOpacity>
                </View>
              )}

            </View>
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </View>
  );
};

function getStyles(theme: any, isWeb: boolean) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: '#000000' },
    flex: { flex: 1 },
    scrollContent: { flexGrow: 1, paddingBottom: isWeb ? 40 : 24 },
    contentWrapper: { flex: 1, maxWidth: isWeb ? 500 : '100%', width: '100%', alignSelf: 'center', justifyContent: 'space-between', paddingTop: isWeb ? 40 : 20 },
    topLogo: { flexDirection: 'row', alignItems: 'center', gap: 12, justifyContent: isWeb ? 'center' : 'flex-start' },
    logoImage: { width: 44, height: 44 },
    brandName: { fontFamily: theme.fonts.black, fontSize: 24, color: '#FFFFFF', letterSpacing: -0.5 },
    mainContent: { flex: 1, justifyContent: 'center', marginTop: isWeb ? 0 : 40 },
    header: { marginBottom: 36, alignItems: isWeb ? 'center' : 'flex-start' },
    title: { fontFamily: theme.fonts.black, fontSize: isWeb ? 56 : 42, color: '#FFFFFF', lineHeight: isWeb ? 64 : 48, textAlign: isWeb ? 'center' : 'left' },
    titleAccent: { fontFamily: theme.fonts.black, fontSize: isWeb ? 56 : 42, color: theme.colors.primary, lineHeight: isWeb ? 64 : 48, textAlign: isWeb ? 'center' : 'left' },
    subtitle: { fontFamily: theme.fonts.regular, fontSize: isWeb ? 16 : 15, color: 'rgba(255,255,255,0.7)', lineHeight: 24, marginTop: 16, maxWidth: isWeb ? '80%' : '95%', textAlign: isWeb ? 'center' : 'left' },
    inputWrapper: { marginTop: 8, width: '100%' },
    inputLabel: { fontFamily: theme.fonts.bold, fontSize: 12, color: theme.colors.textMuted, letterSpacing: 1.5, marginBottom: 12 },
    phoneInputContainer: { flexDirection: 'row', alignItems: 'center', backgroundColor: theme.colors.surface, height: 64, borderRadius: 16, paddingHorizontal: 20, borderWidth: 1, borderColor: theme.colors.border },
    countryCode: { fontFamily: theme.fonts.bold, fontSize: 18, color: '#FFFFFF' },
    divider: { width: 1, height: 28, backgroundColor: theme.colors.border, marginHorizontal: 16 },
    input: { flex: 1, fontFamily: theme.fonts.bold, fontSize: 18, color: '#FFFFFF' },
    errorText: { color: theme.colors.error || '#FF4444', fontFamily: theme.fonts.medium, fontSize: 13, marginTop: 10, marginLeft: 4 },
    footer: { paddingVertical: 20, backgroundColor: '#000000' },
    primaryBtn: { backgroundColor: theme.colors.primary, height: 60, borderRadius: 16, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 12 },
    primaryBtnText: { color: '#000', fontFamily: theme.fonts.bold, fontSize: 18 },
  });
}
export default OwnerLogin;