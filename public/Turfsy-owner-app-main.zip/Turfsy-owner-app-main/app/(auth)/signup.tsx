import { Ionicons } from '@expo/vector-icons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import React, { useEffect, useState } from 'react';
import {
    ActivityIndicator,
    KeyboardAvoidingView,
    Platform,
    ScrollView,
    StatusBar,
    StyleSheet,
    Text,
    TextInput,
    TextInputProps,
    TextStyle,
    TouchableOpacity,
    View,
    ViewStyle
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuthContext } from '../../src/context/AuthContext';
import { useResponsive } from '../../src/utils/responsive';

interface SignupForm {
  name: string;
  email: string;
  businessName: string;
  upiId: string;
}

const THEME = {
  background: '#000000',
  surface: '#1A1A1A',
  primary: '#ADFF00',
  textMain: '#FFFFFF',
  textMuted: '#888888',
  border: '#333333',
};

export default function OwnerSignupScreen() {
  const router = useRouter();
  const { phone, accessToken } = useLocalSearchParams<{ phone: string; accessToken: string }>();
  const responsive = useResponsive();
  const { establishSession } = useAuthContext();

  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const isSmall = responsive.isCompact;
  const pad = responsive.isTablet ? 32 : isSmall ? 18 : 24;

  const [form, setForm] = useState<SignupForm>({
    name: '',
    email: '',
    businessName: '',
    upiId: '',
  });

  // Automatically fetch existing data if the owner already holds a partial profile
  useEffect(() => {
    const checkExisting = async () => {
      try {
        if (!accessToken) return;
        const res = await fetch('https://turfsy.onrender.com/api/v3/ownerProfile', {
          headers: { Authorization: `Bearer ${accessToken}` },
        });
        
        if (res.ok) {
          const json = await res.json();
          if (json.success && json.data) {
             setForm(prev => ({
               ...prev,
               name: json.data.name || prev.name,
               email: json.data.email || prev.email,
               upiId: json.data.payment?.upiId || prev.upiId,
             }));
          }
        }
      } catch (err) {
        console.log('Setup fetch fallback error:', err);
      }
    };
    checkExisting();
  }, [accessToken]);

  const updateForm = (key: keyof SignupForm, value: string): void => {
    setErrorMsg('');
    setForm(prev => ({ ...prev, [key]: value }));
  };

  const handleContinue = async (): Promise<void> => {
    setErrorMsg('');
    if (!phone || !accessToken) {
      setErrorMsg('Required session data is missing. Please try logging in again.');
      return;
    }

    if (!form.name || !form.email) {
      setErrorMsg('Name and Email are minimally required to set up your profile.');
      return;
    }

    try {
      setIsLoading(true);
      const res = await fetch('https://turfsy.onrender.com/api/v3/ownerProfile', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          name: form.name,
          email: form.email,
          contactNumber: phone,
        }),
      });

      console.log('Signup Request Payload:', {
        name: form.name,
        email: form.email,
        contactNumber: phone,
      });

      const data = await res.json();

      if (!res.ok) {
        console.error('Signup API Error Response:', JSON.stringify(data, null, 2));
        throw new Error(data.message || 'Profile creation failed.');
      }

      const finalUser = data.profile || data.user || {};
      finalUser.accessToken = accessToken; // bind the real token to avoid mock fallbacks
      await establishSession(finalUser);
      router.replace('/(tabs)' as any);
    } catch (error: any) {
      setErrorMsg(error.message || 'There was an issue creating your profile. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#000" />

      {/* Step Indicator */}
      <View style={[styles.stepIndicatorContainer, { paddingHorizontal: pad }]}>
        <View style={styles.progressBar}>
          <View style={[styles.progressFill, { width: '50%' }]} />
        </View>
        <Text style={[styles.stepText, { fontSize: responsive.fp(10) }]}>STEP 2 OF 4</Text>
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.flex}
      >
        <ScrollView
          contentContainerStyle={[styles.scrollContent, { paddingHorizontal: pad }]}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
          bounces={false}
        >
          {/* Header */}
          <View style={styles.header}>
            <Text
              style={[styles.title, { fontSize: responsive.fp(isSmall ? 34 : 38), lineHeight: responsive.fp(isSmall ? 40 : 44) }]}
              numberOfLines={1}
              adjustsFontSizeToFit
              minimumFontScale={0.7}
            >
              Register Your
            </Text>
            <Text
              style={[styles.titleAccent, { fontSize: responsive.fp(isSmall ? 34 : 38), lineHeight: responsive.fp(isSmall ? 40 : 44) }]}
              numberOfLines={1}
              adjustsFontSizeToFit
              minimumFontScale={0.7}
            >
              Empire.
            </Text>
            <Text style={[styles.subtitle, { fontSize: responsive.fp(14), lineHeight: responsive.fp(21) }]}>
              Let's get your turf business details ready for players.
            </Text>
          </View>

          {/* Form Section */}
          <View style={styles.formContainer}>
            <OwnerInput
              label="FULL NAME"
              placeholder="e.g. Rajesh Kumar"
              value={form.name}
              onChangeText={(t) => updateForm('name', t)}
              responsive={responsive}
            />
            <OwnerInput
              label="BUSINESS NAME"
              placeholder="e.g. Green Field Arena"
              value={form.businessName}
              onChangeText={(t) => updateForm('businessName', t)}
              responsive={responsive}
            />
            <OwnerInput
              label="EMAIL ADDRESS"
              placeholder="owner@example.com"
              keyboardType="email-address"
              value={form.email}
              onChangeText={(t) => updateForm('email', t)}
              responsive={responsive}
            />
            <OwnerInput
              label="UPI ID"
              placeholder="user@bank"
              value={form.upiId}
              onChangeText={(t) => updateForm('upiId', t)}
              responsive={responsive}
            />
          </View>

          {!!errorMsg && (
            <Text style={{ color: '#FF4444', fontSize: responsive.fp(13), marginTop: 8, marginBottom: 12, textAlign: 'center' }}>
              {errorMsg}
            </Text>
          )}

          {/* Action Footer */}
          <View style={styles.footer}>
            <TouchableOpacity
              style={[styles.primaryBtn, isLoading && { opacity: 0.7 }]}
              onPress={handleContinue}
              activeOpacity={0.8}
              disabled={isLoading}
            >
              {isLoading ? (
                <ActivityIndicator color="#000" />
              ) : (
                <>
                  <Text style={[styles.primaryBtnText, { fontSize: responsive.fp(16) }]}>Continue</Text>
                  <Ionicons name="arrow-forward" size={18} color="#000" />
                </>
              )}
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => router.back()}
              style={styles.secondaryBtn}
              activeOpacity={0.7}
            >
              <Text style={[styles.secondaryBtnText, { fontSize: responsive.fp(13) }]}>Back to Mobile Login</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

interface OwnerInputProps extends TextInputProps {
  label: string;
  value: string;
  responsive: ReturnType<typeof useResponsive>;
}

const OwnerInput: React.FC<OwnerInputProps> = ({ label, value, responsive, ...props }) => (
  <View style={styles.inputGroup}>
    <Text style={[styles.inputLabel, { fontSize: responsive.fp(10) }]}>{label}</Text>
    <View style={styles.inputWrapper}>
      <TextInput
        style={[styles.input, { fontSize: responsive.fp(15) }]}
        placeholderTextColor="#555"
        autoCapitalize="none"
        value={value}
        {...props}
      />
      {value.length > 3 && (
        <Ionicons name="checkmark-circle" size={20} color={THEME.primary} />
      )}
    </View>
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: THEME.background,
  } as ViewStyle,
  flex: {
    flex: 1,
  } as ViewStyle,
  stepIndicatorContainer: {
    paddingTop: 10,
    alignItems: 'center',
  } as ViewStyle,
  progressBar: {
    height: 4,
    width: '100%',
    backgroundColor: '#1A1A1A',
    borderRadius: 2,
    overflow: 'hidden',
    marginBottom: 8,
  } as ViewStyle,
  progressFill: {
    height: '100%',
    backgroundColor: THEME.primary,
  } as ViewStyle,
  stepText: {
    color: THEME.primary,
    fontWeight: '800',
    letterSpacing: 1.5,
  } as TextStyle,
  scrollContent: {
    paddingTop: 24,
    paddingBottom: 24,
  } as ViewStyle,
  header: {
    marginBottom: 24,
  } as ViewStyle,
  title: {
    fontWeight: '900',
    color: '#FFF',
  } as TextStyle,
  titleAccent: {
    fontWeight: '900',
    color: THEME.primary,
  } as TextStyle,
  subtitle: {
    color: THEME.textMuted,
    marginTop: 8,
  } as TextStyle,
  formContainer: {
    gap: 18,
  } as ViewStyle,
  inputGroup: {
    gap: 8,
  } as ViewStyle,
  inputLabel: {
    color: THEME.textMuted,
    fontWeight: '800',
    letterSpacing: 1.2,
    marginLeft: 4,
  } as TextStyle,
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: THEME.surface,
    height: 54,
    borderRadius: 16,
    paddingHorizontal: 16,
    borderWidth: 1,
    borderColor: THEME.border,
  } as ViewStyle,
  input: {
    flex: 1,
    color: '#FFF',
    fontWeight: '600',
  } as TextStyle,
  footer: {
    marginTop: 28,
    gap: 14,
  } as ViewStyle,
  primaryBtn: {
    backgroundColor: THEME.primary,
    height: 56,
    borderRadius: 28,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 10,
  } as ViewStyle,
  primaryBtnText: {
    color: '#000',
    fontWeight: '800',
  } as TextStyle,
  secondaryBtn: {
    height: 44,
    justifyContent: 'center',
    alignItems: 'center',
  } as ViewStyle,
  secondaryBtnText: {
    color: THEME.textMuted,
    fontWeight: '600',
    textDecorationLine: 'underline',
  } as TextStyle,
});
