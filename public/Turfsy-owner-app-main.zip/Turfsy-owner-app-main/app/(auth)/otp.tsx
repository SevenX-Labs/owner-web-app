import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useLocalSearchParams, useRouter } from 'expo-router';
import React from 'react';
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  Image,
  useWindowDimensions,
} from 'react-native';
import { showInfo } from '@/src/components/ui/CustomAlert';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuthContext } from '@/src/context/AuthContext';
import { STORAGE_KEYS } from '@/src/utils/constants';
import { useResponsive } from '@/src/utils/responsive';
import { useAppTheme } from '@/src/hooks/useAppTheme';

const OTPScreen: React.FC = () => {
  const router = useRouter();
  const { phone } = useLocalSearchParams<{ phone: string }>();
  const { establishSession } = useAuthContext();
  const responsive = useResponsive();
  const { theme } = useAppTheme();
  const { width } = useWindowDimensions();

  const [otp, setOtp] = React.useState('');
  const [isLoading, setIsLoading] = React.useState(false);
  const [errorMsg, setErrorMsg] = React.useState('');
  const [timeLeft, setTimeLeft] = React.useState(60);

  React.useEffect(() => {
    if (timeLeft <= 0) return;
    const interval = setInterval(() => setTimeLeft((prev) => prev - 1), 1000);
    return () => clearInterval(interval);
  }, [timeLeft]);

  const isWeb = width > 768;
  const pad = responsive.isTablet || isWeb ? 40 : 24;
  const styles = getStyles(theme, isWeb);

  const handleResend = async () => {
    try {
      setIsLoading(true);
      setErrorMsg('');
      const res = await fetch('https://turfsy.onrender.com/api/v3/auth/owner/resend-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Failed to resend OTP.');
      setTimeLeft(60);
      showInfo('OTP Sent', 'A new verification code has been sent to your phone.');
    } catch (error: any) {
      setErrorMsg(error.message || 'Failed to resend OTP. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerify = async (codeToVerify?: string | any): Promise<void> => {
    const finalOtp = typeof codeToVerify === 'string' ? codeToVerify : otp;
    setErrorMsg('');
    if (!finalOtp || finalOtp.length < 6) {
      setErrorMsg('Please enter a valid 6-digit verification code.');
      return;
    }
    try {
      setIsLoading(true);
      const res = await fetch('https://turfsy.onrender.com/api/v3/auth/owner/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, otp: finalOtp }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'OTP Verification failed.');

      if (data.isNewUser) {
        await AsyncStorage.setItem(STORAGE_KEYS.AUTH_TOKEN, data.accessToken);
        router.replace({ pathname: '/(auth)/signup', params: { phone, accessToken: data.accessToken } });
      } else {
        data.user = data.user || {};
        data.user.accessToken = data.accessToken; 
        await establishSession(data.user); 
        await AsyncStorage.setItem(STORAGE_KEYS.AUTH_TOKEN, data.accessToken);
        router.replace('/(tabs)' as any);
      }
    } catch (error: any) {
      setErrorMsg(error.message || 'Invalid OTP entered. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#000" />
      <SafeAreaView style={styles.flex}>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.flex}>
          
          <View style={[styles.contentWrapper, { paddingHorizontal: pad }]}>
            
            <View style={styles.headerRow}>
              <TouchableOpacity onPress={() => router.replace('/(auth)/login')} style={styles.backBtn} activeOpacity={0.7} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
                <Ionicons name="arrow-back" size={24} color="#FFF" />
              </TouchableOpacity>
              <View style={styles.topLogo}>
                <Image source={require('@/assets/images/logo.png')} style={styles.logoImage} resizeMode="contain" />
                <Text style={styles.brandName}>Owner App</Text>
              </View>
            </View>

            <View style={styles.mainContent}>
              <Text style={styles.title} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.7}>Check your</Text>
              <Text style={styles.titleAccent} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.7}>Inbox.</Text>
              <Text style={styles.subtitle}>We've sent a 6-digit code to +91 {phone}.</Text>

              <View style={styles.otpContainer}>
                {[0, 1, 2, 3, 4, 5].map((index) => {
                  const isActive = otp.length === index;
                  return (
                    <View key={index} style={[styles.inputBox, isActive && styles.inputBoxActive]}>
                      <Text style={styles.otpInput}>{otp[index] || ''}</Text>
                    </View>
                  );
                })}
                <TextInput
                  style={{ position: 'absolute', width: '100%', height: '100%', opacity: 0 }}
                  value={otp}
                  onChangeText={(val) => {
                    setErrorMsg('');
                    const numericVal = val.replace(/[^0-9]/g, '');
                    if (numericVal.length <= 6) {
                      setOtp(numericVal);
                      if (numericVal.length === 6) {
                        handleVerify(numericVal);
                      }
                    }
                  }}
                  keyboardType="number-pad"
                  maxLength={6}
                  editable={!isLoading}
                  autoFocus
                />
              </View>

              {!!errorMsg && <Text style={styles.errorText}>{errorMsg}</Text>}

              <View style={styles.resendContainer}>
                <TouchableOpacity style={[styles.resendBtn, timeLeft > 0 && { opacity: 0.5 }]} activeOpacity={0.7} disabled={timeLeft > 0} onPress={handleResend}>
                  <Text style={styles.resendText}>{timeLeft > 0 ? `Resend in 0:${timeLeft < 10 ? `0${timeLeft}` : timeLeft}` : 'Resend OTP'}</Text>
                </TouchableOpacity>
              </View>
            </View>

            <View style={styles.footer}>
              <TouchableOpacity style={[styles.primaryBtn, isLoading && { opacity: 0.7 }]} onPress={handleVerify} activeOpacity={0.8} disabled={isLoading}>
                {isLoading ? <ActivityIndicator color="#000" /> : (
                  <>
                    <Text style={styles.primaryBtnText}>Verify & Enter</Text>
                    <Ionicons name="arrow-forward" size={20} color="#000" />
                  </>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </View>
  );
};

function getStyles(theme: any, isWeb: boolean) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: '#000000' },
    flex: { flex: 1 },
    contentWrapper: { flex: 1, maxWidth: isWeb ? 500 : '100%', width: '100%', alignSelf: 'center', justifyContent: 'space-between', paddingTop: isWeb ? 40 : 20, paddingBottom: isWeb ? 40 : 20 },
    headerRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
    backBtn: { width: 44, height: 44, borderRadius: 12, backgroundColor: theme.colors.surface, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: theme.colors.border },
    topLogo: { flexDirection: 'row', alignItems: 'center', gap: 10 },
    logoImage: { width: 32, height: 32 },
    brandName: { fontFamily: theme.fonts.black, fontSize: 18, color: '#FFFFFF', letterSpacing: -0.5 },
    mainContent: { flex: 1, justifyContent: 'center', marginTop: isWeb ? 0 : 40 },
    title: { fontFamily: theme.fonts.black, fontSize: isWeb ? 56 : 42, color: '#FFFFFF', lineHeight: isWeb ? 64 : 48, textAlign: isWeb ? 'center' : 'left' },
    titleAccent: { fontFamily: theme.fonts.black, fontSize: isWeb ? 56 : 42, color: theme.colors.primary, lineHeight: isWeb ? 64 : 48, textAlign: isWeb ? 'center' : 'left' },
    subtitle: { fontFamily: theme.fonts.regular, fontSize: isWeb ? 16 : 15, color: 'rgba(255,255,255,0.7)', lineHeight: 24, marginTop: 16, maxWidth: isWeb ? '80%' : '95%', textAlign: isWeb ? 'center' : 'left', alignSelf: isWeb ? 'center' : 'flex-start' },
    otpContainer: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 32, gap: 8 },
    inputBox: { flex: 1, height: 60, backgroundColor: theme.colors.surface, borderRadius: 16, borderWidth: 1, borderColor: theme.colors.border, justifyContent: 'center', alignItems: 'center' },
    inputBoxActive: { borderColor: theme.colors.primary, backgroundColor: 'rgba(173, 255, 0, 0.05)' },
    otpInput: { fontFamily: theme.fonts.black, fontSize: 24, color: '#FFFFFF', textAlign: 'center' },
    errorText: { color: theme.colors.error || '#FF4444', fontFamily: theme.fonts.medium, fontSize: 14, marginTop: 16, textAlign: 'center' },
    resendContainer: { marginTop: 32, alignItems: 'center' },
    resendBtn: { backgroundColor: theme.colors.surface, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 24, borderWidth: 1, borderColor: theme.colors.border },
    resendText: { fontFamily: theme.fonts.bold, fontSize: 14, color: 'rgba(255,255,255,0.7)' },
    footer: { marginTop: 40 },
    primaryBtn: { backgroundColor: theme.colors.primary, height: 60, borderRadius: 16, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 12 },
    primaryBtnText: { color: '#000', fontFamily: theme.fonts.bold, fontSize: 18 },
  });
}
export default OTPScreen;
