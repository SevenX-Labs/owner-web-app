import React from 'react';
import { Platform, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { BottomTabBarProps } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { useResponsive } from '@/src/utils/responsive';
import { useAppTheme } from '@/src/hooks/useAppTheme';

type TabConfig = {
  route: string;
  label: string;
  activeIcon: keyof typeof Ionicons.glyphMap;
  inactiveIcon: keyof typeof Ionicons.glyphMap;
};

export const bottomTabItems: TabConfig[] = [
  { route: 'index', label: 'Home', activeIcon: 'home', inactiveIcon: 'home-outline' },
  { route: 'bookings', label: 'Booking', activeIcon: 'calendar', inactiveIcon: 'calendar-outline' },
  { route: 'analytics', label: 'Analytics', activeIcon: 'stats-chart', inactiveIcon: 'stats-chart-outline' },
  { route: 'turf', label: 'Turf', activeIcon: 'map', inactiveIcon: 'map-outline' },
  { route: 'profile', label: 'Profile', activeIcon: 'person', inactiveIcon: 'person-outline' },
];

export function ResponsiveTabBar({ state, navigation }: BottomTabBarProps) {
  const responsive = useResponsive();
  const { theme } = useAppTheme();
  const insets = useSafeAreaInsets();

  const SIDE_MARGIN = responsive.isTablet ? 32 : 16;
  const ICON_SIZE = responsive.moderateScale(20);
  const BAR_PADDING_BOTTOM = Platform.OS === 'ios'
    ? Math.max(insets.bottom, 8)
    : 12;

  return (
    <View
      style={[
        styles.wrapper,
        {
          backgroundColor: theme.colors.navBackground,
          borderColor: theme.colors.divider,
          left: SIDE_MARGIN,
          right: SIDE_MARGIN,
          bottom: Platform.OS === 'ios' ? Math.max(insets.bottom - 4, 12) : 12,
          paddingTop: 8,
          paddingBottom: BAR_PADDING_BOTTOM,
          paddingHorizontal: responsive.isCompact ? 4 : 8,
        },
      ]}
    >
      {bottomTabItems.map((config) => {
        const route = state.routes.find((item) => item.name === config.route);
        if (!route) return null;

        const index = state.routes.findIndex((item) => item.key === route.key);
        const isFocused = state.index === index;

        return (
          <TouchableOpacity
            key={route.key}
            accessibilityRole="button"
            accessibilityState={isFocused ? { selected: true } : {}}
            onPress={() => navigation.navigate(route.name as never)}
            style={styles.tabButton}
            activeOpacity={0.75}
          >
            <View style={[
              styles.iconWrap,
              isFocused && {
                backgroundColor: theme.colors.navActiveIcon,
              },
            ]}>
              <Ionicons
                name={isFocused ? config.activeIcon : config.inactiveIcon}
                size={ICON_SIZE}
                color={isFocused ? '#111111' : theme.colors.navInactiveIcon}
              />
            </View>
            <Text
              numberOfLines={1}
              style={[
                styles.label,
                {
                  fontSize: responsive.fp(10),
                  fontFamily: isFocused ? theme.fonts.bold : theme.fonts.medium,
                  color: isFocused ? theme.colors.text : theme.colors.navInactiveIcon,
                },
              ]}
            >
              {config.label}
            </Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    position: 'absolute',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderRadius: 999,
    borderWidth: 1,
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.4,
    shadowRadius: 24,
    elevation: 16,
  },
  tabButton: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    minWidth: 0,
    gap: 4,
  },
  iconWrap: {
    width: 40,
    height: 40,
    borderRadius: 999,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  label: {
    letterSpacing: 0.2,
  },
});
