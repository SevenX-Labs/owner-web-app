import React from 'react';

import { ImmersiveModeProvider } from '@/src/components/layout/ImmersiveModeProvider';

export function AppNavigator({ children }: { children: React.ReactNode }) {
  return <ImmersiveModeProvider>{children}</ImmersiveModeProvider>;
}
