// Navigation Types for Expo Router

// Root Stack Routes
export type RootStackParamList = {
  '(auth)/login': undefined;
  '(auth)/signup': undefined;
  '(tabs)': undefined;
  'booking/[id]': { id: string };
  'booking/filter': undefined;
  'earnings/analytics': undefined;
  'earnings/export': undefined;
  'profile/edit': undefined;
  'profile/support': undefined;
  'profile/settings': undefined;
};

// Bottom Tab Routes
export type TabParamList = {
  index: undefined;      // Dashboard
  bookings: undefined;   // Bookings
  analytics: undefined;  // Analytics
  turf: undefined;       // Turf
  earnings: undefined;   // Backward compatibility alias
  profile: undefined;    // Profile
};

// Auth Stack
export type AuthStackParamList = {
  login: undefined;
  signup: undefined;
};
