// Notification Service — Expo Push Notifications + Backend Token Registration

import * as Device from 'expo-device';
import Constants from 'expo-constants';
import { Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import api from './api';
import { STORAGE_KEYS } from '../utils/constants';

// Load expo-notifications safely (will throw in Expo Go SDK 53+)
let Notifications: any = null;
try {
  Notifications = require('expo-notifications');
} catch (e) {
  console.warn('[Notifications] expo-notifications not supported in this environment (likely Expo Go).');
}

// ─── Notification Types ──────────────────────────────────────────────────────

export type NotificationType =
  | 'NEW_BOOKING_OWNER'
  | 'NEW_PENDING_OWNER'
  | 'PAYMENT_RECEIVED_OWNER'
  | 'BOOKING_CANCELLED_OWNER'
  | 'VISIT_COMPLETED_OWNER'
  | 'MANUAL_COMPLETED_OWNER'
  | 'PIN_WINDOW_OPEN';

export interface NotificationData {
  type: NotificationType;
  bookingId?: string;
}

// ─── Configure notification behavior ─────────────────────────────────────────

if (Notifications) {
  Notifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldShowAlert: true,
      shouldPlaySound: true,
      shouldSetBadge: true,
      shouldShowBanner: true,
      shouldShowList: true,
    }),
  });
}

// ─── Service Functions ───────────────────────────────────────────────────────

class NotificationService {
  /**
   * Request notification permissions and get the Expo Push Token.
   * Returns the token string or null if permissions denied / not a device.
   */
  async registerForPushNotifications(): Promise<string | null> {
    // Push notifications only work on physical devices
    if (!Device.isDevice) {
      console.warn('[Notifications] Must use physical device for push notifications');
      return null;
    }

    if (!Notifications) {
      console.warn('[Notifications] Notifications module not available');
      return null;
    }

    // Check existing permission
    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;

    // Request permission if not already granted
    if (existingStatus !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }

    if (finalStatus !== 'granted') {
      console.warn('[Notifications] Permission not granted');
      return null;
    }

    // Set up Android notification channel
    if (Platform.OS === 'android') {
      await Notifications.setNotificationChannelAsync('default', {
        name: 'Turfsy Notifications',
        importance: Notifications.AndroidImportance.MAX,
        vibrationPattern: [0, 250, 250, 250],
        lightColor: '#ADFF00',
        sound: 'default',
        enableVibrate: true,
        showBadge: true,
      });
    }

    // Get the Expo push token
    try {
      const projectId = Constants.expoConfig?.extra?.eas?.projectId;
      const tokenResponse = await Notifications.getExpoPushTokenAsync({
        projectId,
      });
      const token = tokenResponse.data;
      console.log('[Notifications] Expo Push Token:', token);
      return token;
    } catch (error) {
      console.error('[Notifications] Failed to get push token:', error);
      return null;
    }
  }

  /**
   * Register the push token with the backend.
   * Sends the token + platform to POST /api/v3/notifications/register-token
   */
  async registerTokenWithBackend(token: string): Promise<boolean> {
    try {
      const platform = Platform.OS as 'android' | 'ios';
      await api.post('/api/v3/notifications/register-token', {
        token,
        platform,
      });
      // Persist token locally so we can detect changes
      await AsyncStorage.setItem(STORAGE_KEYS.EXPO_PUSH_TOKEN, token);
      console.log('[Notifications] Token registered with backend');
      return true;
    } catch (error) {
      console.error('[Notifications] Failed to register token with backend:', error);
      return false;
    }
  }

  /**
   * Full registration flow: get token → send to backend.
   * Called after login or when token might have changed.
   */
  async setupPushNotifications(): Promise<string | null> {
    const token = await this.registerForPushNotifications();
    if (!token) return null;

    // Check if token changed since last registration
    const storedToken = await AsyncStorage.getItem(STORAGE_KEYS.EXPO_PUSH_TOKEN);
    if (storedToken !== token) {
      await this.registerTokenWithBackend(token);
    } else {
      console.log('[Notifications] Token unchanged, skipping backend registration');
    }

    return token;
  }

  /**
   * Remove the stored push token (called on logout).
   */
  async clearStoredToken(): Promise<void> {
    try {
      await AsyncStorage.removeItem(STORAGE_KEYS.EXPO_PUSH_TOKEN);
      console.log('[Notifications] Stored token cleared');
    } catch (error) {
      console.error('[Notifications] Failed to clear stored token:', error);
    }
  }

  /**
   * Parse notification data payload safely.
   */
  parseNotificationData(notification: any): NotificationData | null {
    if (!Notifications) return null;
    try {
      const data = notification.request.content.data as NotificationData;
      if (data && data.type) {
        return data;
      }
      return null;
    } catch {
      return null;
    }
  }

  /**
   * Determine the target route based on notification type.
   * All types navigate to the booking detail screen.
   */
  getNavigationTarget(data: NotificationData): { route: string; params: Record<string, string> } | null {
    if (!data.bookingId) return null;

    switch (data.type) {
      case 'NEW_BOOKING_OWNER':
      case 'NEW_PENDING_OWNER':
      case 'PAYMENT_RECEIVED_OWNER':
      case 'BOOKING_CANCELLED_OWNER':
      case 'VISIT_COMPLETED_OWNER':
      case 'MANUAL_COMPLETED_OWNER':
      case 'PIN_WINDOW_OPEN':
        return {
          route: '/booking/[id]',
          params: {
            id: data.bookingId,
            highlightPin: data.type === 'PIN_WINDOW_OPEN' ? 'true' : 'false',
            notificationType: data.type,
          },
        };
      default:
        return null;
    }
  }
}

export const notificationService = new NotificationService();
export default notificationService;
