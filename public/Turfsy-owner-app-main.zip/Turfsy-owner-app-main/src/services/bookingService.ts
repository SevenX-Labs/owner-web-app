// Booking Service — Mock data + API integration

import { Booking, BookingFilter, BookingSummary } from '../types/booking.types';
import { ApiResponse, PaginatedResponse } from '../types/common.types';

// ─── Mock Data ───────────────────────────────────────────────────────────────
export const MOCK_BOOKINGS: Booking[] = [
  {
    id: '1',
    bookingNumber: 'TRF-100234',
    customer: { id: 'c1', name: 'Arjun Sharma', phone: '9876543210', email: 'arjun@example.com' },
    turfId: 't1',
    turfName: 'Green Field Arena',
    sport: 'football',
    date: new Date().toISOString().split('T')[0],
    slot: { startTime: '06:00', endTime: '07:00' },
    duration: 60,
    amount: 800,
    status: 'confirmed',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    paymentStatus: 'paid',
    paymentMethod: 'online',
  },
  {
    id: '2',
    bookingNumber: 'TRF-100235',
    customer: { id: 'c2', name: 'Priya Mehta', phone: '9845632100', email: 'priya@example.com' },
    turfId: 't1',
    turfName: 'Green Field Arena',
    sport: 'badminton',
    date: new Date().toISOString().split('T')[0],
    slot: { startTime: '07:00', endTime: '08:00' },
    duration: 60,
    amount: 600,
    status: 'pending',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    paymentStatus: 'pending',
    paymentMethod: 'upi',
  },
  {
    id: '3',
    bookingNumber: 'TRF-100236',
    customer: { id: 'c3', name: 'Rahul Verma', phone: '9812345678' },
    turfId: 't1',
    turfName: 'Green Field Arena',
    sport: 'cricket',
    date: (() => { const d = new Date(); d.setDate(d.getDate() - 1); return d.toISOString().split('T')[0]; })(),
    slot: { startTime: '08:00', endTime: '10:00' },
    duration: 120,
    amount: 2000,
    status: 'completed',
    createdAt: new Date(Date.now() - 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 86400000).toISOString(),
    paymentStatus: 'paid',
    paymentMethod: 'cash',
  },
  {
    id: '4',
    bookingNumber: 'TRF-100237',
    customer: { id: 'c4', name: 'Sneha Patel', phone: '9900112233', email: 'sneha@example.com' },
    turfId: 't1',
    turfName: 'Green Field Arena',
    sport: 'tennis',
    date: new Date().toISOString().split('T')[0],
    slot: { startTime: '17:00', endTime: '18:00' },
    duration: 60,
    amount: 700,
    status: 'cancelled',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    paymentStatus: 'refunded',
    paymentMethod: 'online',
  },
  {
    id: '5',
    bookingNumber: 'TRF-100238',
    customer: { id: 'c5', name: 'Vikram Singh', phone: '9999001122' },
    turfId: 't1',
    turfName: 'Green Field Arena',
    sport: 'basketball',
    date: (() => { const d = new Date(); d.setDate(d.getDate() + 1); return d.toISOString().split('T')[0]; })(),
    slot: { startTime: '18:00', endTime: '19:30' },
    duration: 90,
    amount: 1200,
    status: 'confirmed',
    notes: 'Need extra equipment',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    paymentStatus: 'paid',
    paymentMethod: 'online',
  },
  {
    id: '6',
    bookingNumber: 'TRF-100239',
    customer: { id: 'c6', name: 'Ananya Rao', phone: '9876001234', email: 'ananya@example.com' },
    turfId: 't1',
    turfName: 'Green Field Arena',
    sport: 'football',
    date: new Date().toISOString().split('T')[0],
    slot: { startTime: '19:00', endTime: '20:00' },
    duration: 60,
    amount: 900,
    status: 'confirmed',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    paymentStatus: 'paid',
    paymentMethod: 'upi',
  },
];

// ─── Service Functions ────────────────────────────────────────────────────────

export const bookingService = {
  getBookings: async (filter?: BookingFilter): Promise<PaginatedResponse<Booking>> => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));
    let bookings = [...MOCK_BOOKINGS];

    if (filter?.status) {
      bookings = bookings.filter(b => b.status === filter.status);
    }
    if (filter?.sport) {
      bookings = bookings.filter(b => b.sport === filter.sport);
    }
    if (filter?.searchQuery) {
      const q = filter.searchQuery.toLowerCase();
      bookings = bookings.filter(
        b =>
          b.customer.name.toLowerCase().includes(q) ||
          b.bookingNumber.toLowerCase().includes(q) ||
          b.customer.phone.includes(q)
      );
    }

    return {
      items: bookings,
      total: bookings.length,
      page: 1,
      pageSize: 20,
      totalPages: 1,
      hasNextPage: false,
      hasPrevPage: false,
    };
  },

  getBookingById: async (id: string): Promise<Booking | null> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    return MOCK_BOOKINGS.find(b => b.id === id) ?? null;
  },

  updateBookingStatus: async (id: string, status: Booking['status']): Promise<ApiResponse<Booking>> => {
    await new Promise(resolve => setTimeout(resolve, 400));
    const booking = MOCK_BOOKINGS.find(b => b.id === id);
    if (!booking) throw new Error('Booking not found');
    booking.status = status;
    booking.updatedAt = new Date().toISOString();
    return { success: true, data: booking, statusCode: 200 };
  },

  getBookingSummary: async (): Promise<BookingSummary> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    const today = new Date().toISOString().split('T')[0];
    return {
      total: MOCK_BOOKINGS.length,
      pending: MOCK_BOOKINGS.filter(b => b.status === 'pending').length,
      confirmed: MOCK_BOOKINGS.filter(b => b.status === 'confirmed').length,
      completed: MOCK_BOOKINGS.filter(b => b.status === 'completed').length,
      cancelled: MOCK_BOOKINGS.filter(b => b.status === 'cancelled').length,
      todayTotal: MOCK_BOOKINGS.filter(b => b.date === today).length,
    };
  },
};

export default bookingService;
