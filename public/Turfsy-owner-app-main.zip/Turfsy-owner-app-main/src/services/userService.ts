// User Service — Profile, settings, support

import AsyncStorage from '@react-native-async-storage/async-storage';
import { AppSettings, AuthCredentials, AuthResponse, OwnerProfile, SupportTicket } from '../types/user.types';
import { STORAGE_KEYS } from '../utils/constants';

export const MOCK_PROFILE: OwnerProfile = {} as OwnerProfile;

export const MOCK_SETTINGS: AppSettings = {
  notifications: {
    newBooking: true,
    cancellation: true,
    payment: true,
    reminders: true,
  },
  language: 'en',
  currency: 'INR',
  darkMode: false,
  soundEnabled: true,
};

const persistAuthSession = async (profile: any): Promise<AuthResponse> => {
  const tokenToSave = profile?.accessToken || ''; // Removed mock-jwt-token fallbacks
  const response: AuthResponse = {
    token: tokenToSave,
    refreshToken: profile?.refreshToken || '',
    user: profile,
    expiresIn: 86400,
  };

  if (response.token) {
    await AsyncStorage.multiSet([
      [STORAGE_KEYS.AUTH_TOKEN, response.token],
      [STORAGE_KEYS.REFRESH_TOKEN, response.refreshToken],
      [STORAGE_KEYS.USER_PROFILE, JSON.stringify(response.user || {})],
    ]);
  } else {
    await AsyncStorage.setItem(STORAGE_KEYS.USER_PROFILE, JSON.stringify(response.user || {}));
  }

  return response;
};

export const userService = {
  establishSession: async (profile?: any): Promise<AuthResponse> => {
    return persistAuthSession(profile || {});
  },

  login: async (credentials: AuthCredentials): Promise<AuthResponse> => {
    await new Promise(resolve => setTimeout(resolve, 800));
    if (credentials.email && credentials.password) {
      return persistAuthSession({});
    }
    throw new Error('Invalid credentials');
  },

  signup: async (data: { name: string; email: string; phone: string; password: string; businessName: string }): Promise<AuthResponse> => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    const newProfile: any = { ...data, id: 'new-owner' };
    return persistAuthSession(newProfile);
  },

  logout: async (): Promise<void> => {
    await AsyncStorage.removeItem(STORAGE_KEYS.AUTH_TOKEN);
    await AsyncStorage.removeItem(STORAGE_KEYS.REFRESH_TOKEN);
    await AsyncStorage.removeItem(STORAGE_KEYS.USER_PROFILE);
  },

  getProfile: async (): Promise<any> => {
    await new Promise(resolve => setTimeout(resolve, 400));
    const stored = await AsyncStorage.getItem(STORAGE_KEYS.USER_PROFILE);
    if (stored) return JSON.parse(stored);
    return {};
  },

  updateProfile: async (updates: Partial<OwnerProfile>): Promise<OwnerProfile> => {
    await new Promise(resolve => setTimeout(resolve, 600));
    const current = await AsyncStorage.getItem(STORAGE_KEYS.USER_PROFILE);
    const parsed = current ? JSON.parse(current) : {};
    const updated = { ...parsed, ...updates };
    await AsyncStorage.setItem(STORAGE_KEYS.USER_PROFILE, JSON.stringify(updated));
    return updated as any;
  },

  getSettings: async (): Promise<AppSettings> => {
    await new Promise(resolve => setTimeout(resolve, 200));
    const stored = await AsyncStorage.getItem(STORAGE_KEYS.APP_SETTINGS);
    if (stored) return JSON.parse(stored);
    return MOCK_SETTINGS;
  },

  updateSettings: async (settings: Partial<AppSettings>): Promise<AppSettings> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    const updated = { ...MOCK_SETTINGS, ...settings };
    await AsyncStorage.setItem(STORAGE_KEYS.APP_SETTINGS, JSON.stringify(updated));
    return updated;
  },

  submitSupportTicket: async (ticket: Omit<SupportTicket, 'id' | 'status' | 'createdAt' | 'updatedAt'>): Promise<SupportTicket> => {
    await new Promise(resolve => setTimeout(resolve, 700));
    return {
      ...ticket,
      id: `ticket-${Date.now()}`,
      status: 'open',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
  },
};

export default userService;
