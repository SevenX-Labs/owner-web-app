// Earnings Service — Mock data + API integration

import { EarningsSummary, Transaction, EarningsAnalytics, EarningsFilter } from '../types/earnings.types';

// ─── Mock Data ───────────────────────────────────────────────────────────────
const generateMockTransactions = (): Transaction[] => {
  const transactions: Transaction[] = [];
  const sports = ['football', 'cricket', 'badminton', 'tennis', 'basketball'];
  const methods: Array<'online' | 'cash' | 'upi'> = ['online', 'cash', 'upi'];
  const statuses: Array<'credited' | 'pending' | 'refunded'> = ['credited', 'credited', 'credited', 'pending', 'refunded'];
  const names = ['Arjun Sharma', 'Priya Mehta', 'Rahul Verma', 'Sneha Patel', 'Vikram Singh', 'Ananya Rao', 'Kiran Bhat', 'Divya Shah'];

  for (let i = 0; i < 30; i++) {
    const date = new Date();
    date.setDate(date.getDate() - Math.floor(Math.random() * 30));
    const amount = [600, 700, 800, 900, 1000, 1200, 1500, 2000][Math.floor(Math.random() * 8)];
    const sport = sports[Math.floor(Math.random() * sports.length)];
    const startHour = 6 + Math.floor(Math.random() * 14);

    transactions.push({
      id: `txn-${i + 1}`,
      bookingId: `${i + 1}`,
      bookingNumber: `TRF-${100234 + i}`,
      customerName: names[Math.floor(Math.random() * names.length)],
      amount,
      date: date.toISOString(),
      status: statuses[Math.floor(Math.random() * statuses.length)],
      paymentMethod: methods[Math.floor(Math.random() * methods.length)],
      sport,
      slot: `${startHour}:00 - ${startHour + 1}:00`,
    });
  }
  return transactions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
};

export const MOCK_TRANSACTIONS = generateMockTransactions();

// ─── Service Functions ────────────────────────────────────────────────────────
export const earningsService = {
  getEarningsSummary: async (_filter?: EarningsFilter): Promise<EarningsSummary> => {
    await new Promise(resolve => setTimeout(resolve, 500));
    const credited = MOCK_TRANSACTIONS.filter(t => t.status === 'credited');
    const pending = MOCK_TRANSACTIONS.filter(t => t.status === 'pending');
    const totalRevenue = credited.reduce((sum, t) => sum + t.amount, 0);
    const pendingPayments = pending.reduce((sum, t) => sum + t.amount, 0);

    return {
      totalRevenue,
      pendingPayments,
      completedPayments: totalRevenue,
      totalBookings: MOCK_TRANSACTIONS.length,
      averagePerBooking: Math.round(totalRevenue / credited.length),
      periodLabel: 'This Month',
    };
  },

  getTransactions: async (filter?: EarningsFilter): Promise<Transaction[]> => {
    await new Promise(resolve => setTimeout(resolve, 400));
    let transactions = [...MOCK_TRANSACTIONS];

    if (filter?.period === 'today') {
      const today = new Date().toISOString().split('T')[0];
      transactions = transactions.filter(t => t.date.startsWith(today));
    } else if (filter?.period === 'week') {
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      transactions = transactions.filter(t => new Date(t.date) >= weekAgo);
    }

    return transactions;
  },

  getEarningsAnalytics: async (): Promise<EarningsAnalytics> => {
    await new Promise(resolve => setTimeout(resolve, 600));

    // Build last 7 days
    const revenueByDay = Array.from({ length: 7 }, (_, i) => {
      const d = new Date();
      d.setDate(d.getDate() - (6 - i));
      const dateStr = d.toISOString().split('T')[0];
      const dayTransactions = MOCK_TRANSACTIONS.filter(
        t => t.date.startsWith(dateStr) && t.status === 'credited'
      );
      return {
        date: dateStr,
        revenue: dayTransactions.reduce((sum, t) => sum + t.amount, 0),
        bookings: dayTransactions.length,
      };
    });

    // Last 6 months
    const revenueByMonth = Array.from({ length: 6 }, (_, i) => {
      const d = new Date();
      d.setMonth(d.getMonth() - (5 - i));
      const month = d.toLocaleDateString('en-IN', { month: 'short', year: 'numeric' });
      const rev = 20000 + Math.floor(Math.random() * 30000);
      const prev = 20000 + Math.floor(Math.random() * 30000);
      return {
        month,
        revenue: rev,
        bookings: Math.floor(rev / 900),
        growth: parseFloat(((rev - prev) / prev * 100).toFixed(1)),
      };
    });

    // By hour
    const revenueByHour = Array.from({ length: 14 }, (_, i) => {
      const hour = 6 + i;
      const label = `${hour}:00`;
      return { hour: label, revenue: Math.floor(Math.random() * 5000) + 500 };
    });

    const sportCounts: Record<string, number> = {};
    MOCK_TRANSACTIONS.forEach(t => {
      sportCounts[t.sport] = (sportCounts[t.sport] || 0) + 1;
    });
    const topSport = Object.entries(sportCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || 'football';

    return {
      revenueByDay,
      revenueByMonth,
      revenueByHour,
      topSport,
      peakHour: '18:00',
      occupancyRate: 72,
      growthRate: 12.5,
    };
  },

  exportEarnings: async (format: 'csv' | 'pdf'): Promise<{ url: string }> => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    return { url: `https://turfsy.com/exports/earnings.${format}` };
  },
};

export default earningsService;
