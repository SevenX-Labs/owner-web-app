// Date Utility Functions

/**
 * Format a date string for display (e.g., "27 Mar 2026")
 */
export const formatDate = (dateStr: string): string => {
  const date = new Date(dateStr);
  return date.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
};

/**
 * Format time (e.g., "10:30 AM")
 */
export const formatTime = (timeStr: string): string => {
  // timeStr can be "HH:mm" or ISO datetime
  if (timeStr.includes('T') || timeStr.includes('-')) {
    const date = new Date(timeStr);
    return date.toLocaleTimeString('en-IN', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });
  }
  // Parse "HH:mm" format
  const [hours, minutes] = timeStr.split(':').map(Number);
  const period = hours >= 12 ? 'PM' : 'AM';
  const h = hours % 12 || 12;
  return `${h}:${String(minutes).padStart(2, '0')} ${period}`;
};

/**
 * Format a slot range (e.g., "10:00 AM - 11:00 AM")
 */
export const formatSlot = (startTime: string, endTime: string): string => {
  return `${formatTime(startTime)} - ${formatTime(endTime)}`;
};

/**
 * Format date and time together
 */
export const formatDateTime = (dateStr: string): string => {
  const date = new Date(dateStr);
  return date.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  });
};

/**
 * Check if a date string is today
 */
export const isToday = (dateStr: string): boolean => {
  const date = new Date(dateStr);
  const today = new Date();
  return (
    date.getDate() === today.getDate() &&
    date.getMonth() === today.getMonth() &&
    date.getFullYear() === today.getFullYear()
  );
};

/**
 * Check if a date string is in the past
 */
export const isPast = (dateStr: string): boolean => {
  return new Date(dateStr) < new Date();
};

/**
 * Get start and end of today as ISO strings
 */
export const getTodayRange = (): { from: string; to: string } => {
  const today = new Date();
  const from = new Date(today.setHours(0, 0, 0, 0)).toISOString();
  const to = new Date(today.setHours(23, 59, 59, 999)).toISOString();
  return { from, to };
};

/**
 * Get start and end of current week
 */
export const getWeekRange = (): { from: string; to: string } => {
  const now = new Date();
  const dayOfWeek = now.getDay();
  const startOfWeek = new Date(now);
  startOfWeek.setDate(now.getDate() - dayOfWeek);
  startOfWeek.setHours(0, 0, 0, 0);
  const endOfWeek = new Date(startOfWeek);
  endOfWeek.setDate(startOfWeek.getDate() + 6);
  endOfWeek.setHours(23, 59, 59, 999);
  return { from: startOfWeek.toISOString(), to: endOfWeek.toISOString() };
};

/**
 * Get start and end of current month
 */
export const getMonthRange = (): { from: string; to: string } => {
  const now = new Date();
  const from = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
  const to = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999).toISOString();
  return { from, to };
};

/**
 * Get a relative label for a date (Today, Yesterday, or formatted date)
 */
export const getRelativeDate = (dateStr: string): string => {
  const date = new Date(dateStr);
  const today = new Date();
  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);

  if (isToday(dateStr)) return 'Today';
  if (
    date.getDate() === yesterday.getDate() &&
    date.getMonth() === yesterday.getMonth() &&
    date.getFullYear() === yesterday.getFullYear()
  ) return 'Yesterday';

  return formatDate(dateStr);
};

/**
 * Format month/year label (e.g., "March 2026")
 */
export const formatMonthYear = (dateStr: string): string => {
  const date = new Date(dateStr);
  return date.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });
};

/**
 * Get day of week short label (e.g., "Mon")
 */
export const getDayShort = (dateStr: string): string => {
  const date = new Date(dateStr);
  return date.toLocaleDateString('en-IN', { weekday: 'short' });
};
