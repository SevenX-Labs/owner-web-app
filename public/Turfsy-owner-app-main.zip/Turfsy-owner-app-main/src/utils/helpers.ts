// Helper Utility Functions

import { BookingStatus } from '../types/booking.types';
import { COLORS } from '../config/theme';

/**
 * Format a number as Indian Rupee currency
 */
export const formatCurrency = (amount: number, symbol = '₹'): string => {
  if (amount >= 100000) {
    return `${symbol}${(amount / 100000).toFixed(1)}L`;
  }
  if (amount >= 1000) {
    return `${symbol}${(amount / 1000).toFixed(1)}K`;
  }
  return `${symbol}${amount.toLocaleString('en-IN')}`;
};

/**
 * Format full currency with decimals
 */
export const formatCurrencyFull = (amount: number): string => {
  return `₹${amount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
};

/**
 * Format Indian phone number
 */
export const formatPhoneNumber = (phone: string): string => {
  const cleaned = phone.replace(/\D/g, '');
  if (cleaned.length === 10) {
    return `+91 ${cleaned.slice(0, 5)} ${cleaned.slice(5)}`;
  }
  return phone;
};

/**
 * Get background color for booking status
 */
export const getStatusBgColor = (status: BookingStatus): string => {
  switch (status) {
    case 'confirmed': return COLORS.successBg;
    case 'pending': return COLORS.warningBg;
    case 'cancelled': return COLORS.errorBg;
    case 'completed': return COLORS.infoBg;
    default: return COLORS.divider;
  }
};

/**
 * Get text color for booking status
 */
export const getStatusColor = (status: BookingStatus): string => {
  switch (status) {
    case 'confirmed': return COLORS.success;
    case 'pending': return COLORS.warning;
    case 'cancelled': return COLORS.error;
    case 'completed': return COLORS.info;
    default: return COLORS.textMuted;
  }
};

/**
 * Capitalize the first letter of a string
 */
export const capitalize = (str: string): string => {
  if (!str) return '';
  return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
};

/**
 * Get initials from a full name
 */
export const getInitials = (name: string): string => {
  const parts = name.trim().split(' ');
  if (parts.length >= 2) {
    return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
  }
  return name.slice(0, 2).toUpperCase();
};

/**
 * Truncate text to max length with ellipsis
 */
export const truncateText = (text: string, maxLength: number): string => {
  if (text.length <= maxLength) return text;
  return `${text.slice(0, maxLength)}...`;
};

/**
 * Format percentage change with +/- sign
 */
export const formatChange = (change: number): string => {
  if (change > 0) return `+${change.toFixed(1)}%`;
  if (change < 0) return `${change.toFixed(1)}%`;
  return '0%';
};

/**
 * Get color for percentage change
 */
export const getChangeColor = (change: number): string => {
  if (change > 0) return COLORS.success;
  if (change < 0) return COLORS.error;
  return COLORS.textMuted;
};

/**
 * Generate a random booking number
 */
export const generateBookingNumber = (): string => {
  const num = Math.floor(Math.random() * 900000) + 100000;
  return `TRF-${num}`;
};

/**
 * Validate email format
 */
export const isValidEmail = (email: string): boolean => {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
};

/**
 * Validate Indian phone number
 */
export const isValidPhone = (phone: string): boolean => {
  return /^[6-9]\d{9}$/.test(phone.replace(/\D/g, ''));
};

/**
 * Calculate duration in hours and minutes
 */
export const formatDuration = (minutes: number): string => {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  if (h === 0) return `${m}m`;
  if (m === 0) return `${h}h`;
  return `${h}h ${m}m`;
};
