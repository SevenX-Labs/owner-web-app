import AsyncStorage from '@react-native-async-storage/async-storage';
import { EMPTY_PROFILE, OwnerProfile } from '../types/profile';
import { STORAGE_KEYS } from './constants';

const PROFILE_KEY = '@turfsy_owner_profile';
const API_URL = 'https://turfsy.onrender.com/api/v3/ownerProfile';

export const saveProfile = async (profile: OwnerProfile): Promise<void> => {
  await AsyncStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
};

export const getProfile = async (): Promise<OwnerProfile | null> => {
  try {
    const token = await AsyncStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
    if (!token) return null;

    const res = await fetch(API_URL, {
      headers: { Authorization: `Bearer ${token}` }
    });
    
    if (!res.ok) throw new Error('API fetch failed');
    const json = await res.json();
    
    if (json.success && json.data) {
      const data = json.data;
      const payment = data.payment || {};
      const turfName = data.turfs && data.turfs.length > 0 ? data.turfs[0].name : '';
      const newProfile: OwnerProfile = {
        ownerName: data.name || '',
        email: data.email || '',
        phone: data.contactNumber || '',
        turf: {
          name: turfName,
        } as any, // casting to avoid overriding the large turf object mock definitions right now
        documents: {
          aadhar: '',
          bank: {
            accountNumber: payment.accountNumber || '',
            ifsc: payment.ifscCode || '',
            upi: payment.upiId || '',
            bankName: payment.bankName || '',
            bankHolderName: payment.bankHolderName || '',
          }
        }
      };
      
      await saveProfile(newProfile);
      return newProfile;
    }
  } catch (err) {
    console.error('Error fetching profile from API:', err);
  }
  
  // Fallback to local cache
  const raw = await AsyncStorage.getItem(PROFILE_KEY);
  return raw ? (JSON.parse(raw) as OwnerProfile) : null;
};

export const updateProfile = async (updates: Partial<OwnerProfile>): Promise<OwnerProfile> => {
  const token = await AsyncStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
  if (!token) throw new Error('Not authenticated');

  const u = updates as OwnerProfile;
  const payload = {
    name: u.ownerName,
    email: u.email,
    contactNumber: u.phone,
    bankHolderName: u.documents?.bank?.bankHolderName || '',
    bankName: u.documents?.bank?.bankName || '',
    accountNumber: u.documents?.bank?.accountNumber || '',
    ifscCode: u.documents?.bank?.ifsc || '',
    upiId: u.documents?.bank?.upi || '',
  };

  const res = await fetch(API_URL, {
    method: 'PATCH',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    },
    body: JSON.stringify(payload)
  });

  const json = await res.json();
  if (!res.ok) throw new Error(json.message || 'Failed to update profile');

  const existing = await getProfile() || EMPTY_PROFILE;
  const updated: OwnerProfile = {
    ...existing,
    ...updates,
    documents: {
      ...existing.documents,
      ...updates.documents,
      bank: {
        ...existing.documents?.bank,
        ...updates.documents?.bank,
      }
    }
  };
  await saveProfile(updated);
  return updated;
};

export const clearProfile = async (): Promise<void> => {
  await AsyncStorage.removeItem(PROFILE_KEY);
};
