import { Dimensions, PixelRatio, useWindowDimensions } from 'react-native';

const BASE_W = 390;
const BASE_H = 844;

const getWindowSize = () => Dimensions.get('window');

const scaleWidth = (px: number, width: number) => {
  const scale = Math.min(width / BASE_W, 1.2); // Cap scaling to 1.2x max
  return Math.round(PixelRatio.roundToNearestPixel(px * scale));
};

const scaleHeight = (px: number, height: number) => {
  const scale = Math.min(height / BASE_H, 1.2); // Cap scaling to 1.2x max
  return Math.round(PixelRatio.roundToNearestPixel(px * scale));
};

export const wp = (px: number): number => scaleWidth(px, getWindowSize().width);

export const hp = (px: number): number => scaleHeight(px, getWindowSize().height);

export const fp = (px: number): number => {
  const { width, height } = getWindowSize();
  const scale = Math.min(width / BASE_W, height / BASE_H, 1.2); // Cap font scale

  return Math.round(PixelRatio.roundToNearestPixel(px * scale));
};

export const moderateScale = (size: number, factor = 0.5): number => {
  const scaled = wp(size);
  return Math.round(size + (scaled - size) * factor);
};

export const getResponsiveSpacing = (base: number): number => moderateScale(base, 0.35);

export const useResponsive = () => {
  const { width, height, fontScale } = useWindowDimensions();
  const tablet = width >= 600;
  const compact = width < 360;

  return {
    width,
    height,
    fontScale,
    isTablet: tablet,
    isCompact: compact,
    wp: (px: number) => scaleWidth(px, width),
    hp: (px: number) => scaleHeight(px, height),
    fp: (px: number) => {
      const scale = Math.min(width / BASE_W, height / BASE_H, 1.2);
      const adjusted = px * scale;
      return Math.round(PixelRatio.roundToNearestPixel(adjusted / Math.max(fontScale, 1)));
    },
    moderateScale: (size: number, factor = 0.5) => {
      const scaled = scaleWidth(size, width);
      return Math.round(size + (scaled - size) * factor);
    },
  };
};

export const isTablet = getWindowSize().width >= 600;

export const screenPadding = isTablet ? wp(48) : wp(24);
