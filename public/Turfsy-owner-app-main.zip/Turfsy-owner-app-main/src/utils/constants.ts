// App-wide Constants

import { SelectOption } from '../types/common.types';
import { BookingStatus, SportType } from '../types/booking.types';

export const APP_NAME = 'Turfsy Owner';

export const BOOKING_STATUS_LABELS: Record<BookingStatus, string> = {
  pending: 'Pending',
  confirmed: 'Confirmed',
  completed: 'Completed',
  cancelled: 'Cancelled',
};

export const BOOKING_STATUS_OPTIONS: SelectOption[] = [
  { label: 'All Status', value: '' },
  { label: 'Pending', value: 'pending' },
  { label: 'Confirmed', value: 'confirmed' },
  { label: 'Completed', value: 'completed' },
  { label: 'Cancelled', value: 'cancelled' },
];

export const SPORT_OPTIONS: SelectOption[] = [
  { label: 'All Sports', value: '' },
  { label: 'Football', value: 'football' },
  { label: 'Cricket', value: 'cricket' },
  { label: 'Basketball', value: 'basketball' },
  { label: 'Badminton', value: 'badminton' },
  { label: 'Tennis', value: 'tennis' },
  { label: 'Volleyball', value: 'volleyball' },
  { label: 'Other', value: 'other' },
];

export const SPORT_EMOJIS: Record<SportType | string, string> = {
  football: '⚽',
  cricket: '🏏',
  basketball: '🏀',
  badminton: '🏸',
  tennis: '🎾',
  volleyball: '🏐',
  other: '🏅',
};

export const PAYMENT_METHOD_OPTIONS: SelectOption[] = [
  { label: 'All Methods', value: '' },
  { label: 'Online', value: 'online' },
  { label: 'Cash', value: 'cash' },
  { label: 'UPI', value: 'upi' },
];

export const EARNINGS_PERIOD_OPTIONS: SelectOption[] = [
  { label: 'Today', value: 'today' },
  { label: 'This Week', value: 'week' },
  { label: 'This Month', value: 'month' },
  { label: 'This Year', value: 'year' },
  { label: 'Custom Range', value: 'custom' },
];

export const STORAGE_KEYS = {
  AUTH_TOKEN: '@turfsy_auth_token',
  REFRESH_TOKEN: '@turfsy_refresh_token',
  USER_PROFILE: '@turfsy_user_profile',
  APP_SETTINGS: '@turfsy_app_settings',
  THEME_MODE: '@turfsy_theme_mode',
  EXPO_PUSH_TOKEN: '@turfsy_expo_push_token',
};

export const DATE_FORMATS = {
  display: 'DD MMM YYYY',
  api: 'YYYY-MM-DD',
  time: 'hh:mm A',
  datetime: 'DD MMM YYYY, hh:mm A',
  monthYear: 'MMM YYYY',
};

export const TURF_SURFACES = ['Natural Grass', 'Artificial Turf', 'Concrete', 'Clay', 'Rubber'];

export const PAGE_SIZE = 20;

export const SUPPORT_CATEGORIES = [
  'Booking Issue',
  'Payment Problem',
  'Account Access',
  'Technical Bug',
  'Feature Request',
  'Other',
];
