// Earnings Types

export type EarningsPeriod = 'today' | 'week' | 'month' | 'year' | 'custom';

export interface EarningsSummary {
  totalRevenue: number;
  pendingPayments: number;
  completedPayments: number;
  totalBookings: number;
  averagePerBooking: number;
  periodLabel: string;
}

export interface Transaction {
  id: string;
  bookingId: string;
  bookingNumber: string;
  customerName: string;
  amount: number;
  date: string;
  status: 'credited' | 'pending' | 'refunded';
  paymentMethod: 'online' | 'cash' | 'upi';
  sport: string;
  slot: string;
}

export interface EarningsFilter {
  period: EarningsPeriod;
  dateFrom?: string;
  dateTo?: string;
  sport?: string;
  paymentMethod?: string;
}

export interface DailyEarnings {
  date: string;
  revenue: number;
  bookings: number;
}

export interface MonthlyEarnings {
  month: string;
  revenue: number;
  bookings: number;
  growth?: number;
}

export interface EarningsAnalytics {
  revenueByDay: DailyEarnings[];
  revenueByMonth: MonthlyEarnings[];
  revenueByHour: { hour: string; revenue: number }[];
  topSport: string;
  peakHour: string;
  occupancyRate: number;
  growthRate: number;
}
