// User / Owner Types

export interface TurfVenue {
  id: string;
  name: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  sports: string[];
  surfaces: string[];
  openTime: string;
  closeTime: string;
  pricePerHour: number;
  images: string[];
  rating: number;
  reviewCount: number;
  isActive: boolean;
}

export interface OwnerProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  avatar?: string;
  businessName: string;
  venues: TurfVenue[];
  isVerified: boolean;
  joinedAt: string;
  bankDetails?: {
    accountNumber: string;
    ifscCode: string;
    bankName: string;
    accountHolderName: string;
  };
}

export interface SupportTicket {
  id: string;
  subject: string;
  description: string;
  status: 'open' | 'in_progress' | 'resolved' | 'closed';
  priority: 'low' | 'medium' | 'high';
  createdAt: string;
  updatedAt: string;
}

export interface AppSettings {
  notifications: {
    newBooking: boolean;
    cancellation: boolean;
    payment: boolean;
    reminders: boolean;
  };
  language: string;
  currency: string;
  darkMode: boolean;
  soundEnabled: boolean;
}

export interface AuthCredentials {
  email: string;
  password: string;
}

export interface AuthResponse {
  token: string;
  refreshToken: string;
  user: OwnerProfile;
  expiresIn: number;
}
