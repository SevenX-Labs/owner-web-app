export interface Turf {
  id: string;
  name: string;
  location: string;
  sport: string;
  pricePerHour: number;
  status: 'active' | 'maintenance';
  slotsAvailable: number;
}
