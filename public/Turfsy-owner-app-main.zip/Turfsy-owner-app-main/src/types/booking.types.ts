// Booking Types

export type BookingStatus = 'pending' | 'confirmed' | 'completed' | 'cancelled';

export type SportType =
  | 'football'
  | 'cricket'
  | 'basketball'
  | 'badminton'
  | 'tennis'
  | 'volleyball'
  | 'other';

export interface TimeSlot {
  startTime: string; // HH:mm
  endTime: string;   // HH:mm
}

export interface BookingCustomer {
  id: string;
  name: string;
  phone: string;
  email?: string;
  avatar?: string;
}

export interface Booking {
  id: string;
  bookingNumber: string;
  customer: BookingCustomer;
  turfId: string;
  turfName: string;
  sport: SportType;
  date: string; // ISO date string
  slot: TimeSlot;
  duration: number; // in minutes
  amount: number;
  status: BookingStatus;
  notes?: string;
  createdAt: string;
  updatedAt: string;
  paymentStatus: 'paid' | 'pending' | 'refunded';
  paymentMethod?: 'online' | 'cash' | 'upi';
}

export interface BookingFilter {
  status?: BookingStatus;
  sport?: SportType;
  dateFrom?: string;
  dateTo?: string;
  searchQuery?: string;
}

export interface BookingSummary {
  total: number;
  pending: number;
  confirmed: number;
  completed: number;
  cancelled: number;
  todayTotal: number;
}
