export interface TurfDetails {
  name: string;
  description: string;
  sportsType: string;
  size: string;
  address: string;
  city: string;
  pincode: string;
  lat: number;
  lng: number;
}

export interface Pricing {
  weekdayDay: number;
  weekdayNight: number;
  weekendDay: number;
  weekendNight: number;
  minSlot: number;
  openTime: string;
  closeTime: string;
}

export interface Documents {
  aadhar?: string;
  bank: {
    accountNumber?: string;
    ifsc?: string;
    upi?: string;
    bankName?: string;
    bankHolderName?: string;
  };
}

export interface OwnerProfile {
  ownerName: string;
  email: string;
  phone: string;
  turf?: {
    name: string;
  };
  documents?: Documents;
}

export const EMPTY_PROFILE: OwnerProfile = {
  ownerName: '',
  email: '',
  phone: '',
  documents: {
    aadhar: '',
    bank: {
      accountNumber: '',
      ifsc: '',
      upi: '',
      bankName: '',
      bankHolderName: '',
    },
  },
};
