// Common Shared Types

export interface ApiResponse<T> {
  success: boolean;
  data: T;
  message?: string;
  error?: string;
  statusCode: number;
}

export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
  hasNextPage: boolean;
  hasPrevPage: boolean;
}

export type LoadingState = 'idle' | 'loading' | 'success' | 'error';

export interface ErrorState {
  message: string;
  code?: string | number;
}

export interface SelectOption {
  label: string;
  value: string;
}

export interface DateRange {
  from: string;
  to: string;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'booking' | 'payment' | 'alert' | 'info';
  isRead: boolean;
  createdAt: string;
  data?: Record<string, unknown>;
}

export interface StatCard {
  label: string;
  value: string | number;
  icon: string;
  change?: number;
  changeLabel?: string;
  color?: string;
}
