// Environment Configuration
const ENV = {
  dev: {
    apiBaseUrl: 'https://api.turfsy.com/dev/v1',
    appEnv: 'development',
  },
  staging: {
    apiBaseUrl: 'https://api.turfsy.com/staging/v1',
    appEnv: 'staging',
  },
  prod: {
    apiBaseUrl: 'https://api.turfsy.com/v1',
    appEnv: 'production',
  },
};

const getEnv = () => {
  // In a real app, use process.env.EXPO_PUBLIC_APP_ENV
  return ENV.dev;
};

export const Config = getEnv();

export const API_TIMEOUT = 30000; // 30 seconds
export const APP_NAME = 'Turfsy Owner';
export const APP_VERSION = '1.0.0';
