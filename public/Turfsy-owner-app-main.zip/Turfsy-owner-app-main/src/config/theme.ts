// Turfsy Owner App — Theme Configuration

export const COLORS = {
  // Primary Brand
  primary: '#1A8D4E',
  primaryDark: '#146B3A',
  primaryLight: '#22B566',
  primaryBg: '#E8F5EE',

  // Accent
  accent: '#F5A623',
  accentDark: '#D4891A',
  accentLight: '#FFD08A',
  accentBg: '#FFF8EC',

  // Semantic
  success: '#1A8D4E',
  successBg: '#E8F5EE',
  warning: '#F5A623',
  warningBg: '#FFF8EC',
  error: '#E53E3E',
  errorBg: '#FFF0F0',
  info: '#3B82F6',
  infoBg: '#EFF6FF',

  // Neutral
  white: '#FFFFFF',
  black: '#0A0A0A',
  background: '#F8FAFC',
  surface: '#FFFFFF',
  border: '#E2E8F0',
  divider: '#F1F5F9',

  // Text
  textPrimary: '#1A202C',
  textSecondary: '#4A5568',
  textMuted: '#A0AEC0',
  textInverse: '#FFFFFF',

  // Tab Bar
  tabActive: '#1A8D4E',
  tabInactive: '#A0AEC0',

  // Status Colors
  statusConfirmed: '#1A8D4E',
  statusPending: '#F5A623',
  statusCancelled: '#E53E3E',
  statusCompleted: '#3B82F6',

  // Gradient
  gradientStart: '#1A8D4E',
  gradientEnd: '#146B3A',

  // Dark Mode
  dark: {
    background: '#0F172A',
    surface: '#1E293B',
    border: '#334155',
    textPrimary: '#F1F5F9',
    textSecondary: '#94A3B8',
    textMuted: '#64748B',
  },
};

export const SPACING = {
  xs: 4,
  sm: 8,
  md: 12,
  base: 16,
  lg: 20,
  xl: 24,
  '2xl': 32,
  '3xl': 40,
  '4xl': 48,
  '5xl': 64,
};

export const BORDER_RADIUS = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  '2xl': 24,
  full: 9999,
};

export const FONT_SIZE = {
  xs: 11,
  sm: 12,
  base: 14,
  md: 15,
  lg: 16,
  xl: 18,
  '2xl': 20,
  '3xl': 24,
  '4xl': 28,
  '5xl': 32,
  '6xl': 36,
};

export const FONT_WEIGHT = {
  regular: '400' as const,
  medium: '500' as const,
  semibold: '600' as const,
  bold: '700' as const,
  extrabold: '800' as const,
};

export const SHADOWS = {
  sm: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  md: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 4,
  },
  lg: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 16,
    elevation: 8,
  },
  green: {
    shadowColor: '#1A8D4E',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 6,
  },
};

export const ICON_SIZES = {
  sm: 16,
  md: 20,
  lg: 24,
  xl: 28,
  '2xl': 32,
};
