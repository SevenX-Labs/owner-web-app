import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';

import { userService } from '../services/userService';
import { notificationService } from '../services/notificationService';
import { AuthCredentials, OwnerProfile } from '../types/user.types';
import { STORAGE_KEYS } from '../utils/constants';

interface AuthContextType {
  user: OwnerProfile | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (credentials: AuthCredentials) => Promise<void>;
  establishSession: (profile?: OwnerProfile) => Promise<void>;
  signup: (data: {
    name: string;
    email: string;
    phone: string;
    password: string;
    businessName: string;
  }) => Promise<void>;
  logout: () => Promise<void>;
  updateUser: (updates: Partial<OwnerProfile>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<OwnerProfile | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const restoreAuth = async () => {
      try {
        const [[, storedToken], [, storedUser]] = await AsyncStorage.multiGet([
          STORAGE_KEYS.AUTH_TOKEN,
          STORAGE_KEYS.USER_PROFILE,
        ]);

        if (storedToken && storedUser) {
          const parsedUser = JSON.parse(storedUser) as OwnerProfile;
          
          // Clear legacy mock data cache if detected
          if (parsedUser?.name === 'Rajesh Kumar') {
            await userService.logout();
            setToken(null);
            setUser(null);
          } else {
            setToken(storedToken);
            setUser(parsedUser);
          }
        }
      } catch (err) {
        console.error('Failed to restore auth:', err);
      } finally {
        setIsLoading(false);
      }
    };

    restoreAuth();
  }, []);

  const login = useCallback(async (credentials: AuthCredentials) => {
    const response = await userService.login(credentials);
    setToken(response.token);
    setUser(response.user);
  }, []);

  const establishSession = useCallback(async (profile?: OwnerProfile) => {
    const response = await userService.establishSession(profile);
    setToken(response.token);
    setUser(response.user);
  }, []);

  const signup = useCallback(async (data: {
    name: string;
    email: string;
    phone: string;
    password: string;
    businessName: string;
  }) => {
    const response = await userService.signup(data);
    setToken(response.token);
    setUser(response.user);
  }, []);

  const logout = useCallback(async () => {
    // Clear push token on logout
    await notificationService.clearStoredToken();
    await userService.logout();
    setToken(null);
    setUser(null);
  }, []);

  const updateUser = useCallback((updates: Partial<OwnerProfile>) => {
    setUser(prev => (prev ? { ...prev, ...updates } : null));
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isAuthenticated: !!token && !!user,
        isLoading,
        login,
        establishSession,
        signup,
        logout,
        updateUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuthContext = (): AuthContextType => {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuthContext must be used within AuthProvider');
  }
  return ctx;
};

export default AuthContext;
