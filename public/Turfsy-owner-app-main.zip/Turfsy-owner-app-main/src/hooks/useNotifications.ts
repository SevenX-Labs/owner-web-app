// useNotifications — Hook for managing push notification lifecycle

import { useEffect, useRef, useState, useCallback } from 'react';
// Load expo-notifications safely (will throw in Expo Go SDK 53+)
let Notifications: any = null;
try {
  Notifications = require('expo-notifications');
} catch (e) {
  // Ignored, handled gracefully
}
import { useRouter } from 'expo-router';
import { useAuthContext } from '../context/AuthContext';
import notificationService, { NotificationData } from '../services/notificationService';

export interface InAppNotification {
  id: string;
  title: string;
  body: string;
  data: NotificationData | null;
  timestamp: number;
}

export const useNotifications = () => {
  const router = useRouter();
  const { isAuthenticated } = useAuthContext();
  const [expoPushToken, setExpoPushToken] = useState<string | null>(null);
  const [inAppNotification, setInAppNotification] = useState<InAppNotification | null>(null);

  const notificationListener = useRef<Notifications.EventSubscription | null>(null);
  const responseListener = useRef<Notifications.EventSubscription | null>(null);

  // Use a ref to always have the latest router available inside listeners
  // This prevents stale closures in the notification event listeners
  const routerRef = useRef(router);
  useEffect(() => {
    routerRef.current = router;
  }, [router]);

  // ─── Navigate based on notification type ────────────────────────────────────
  // Uses routerRef so it's always up-to-date even inside listeners

  const navigateToBooking = useCallback((data: NotificationData) => {
    if (!data.bookingId) {
      console.warn('[Notifications] No bookingId in notification data, skipping navigation');
      return;
    }

    const params: Record<string, string> = {
      id: data.bookingId,
      notificationType: data.type,
    };

    if (data.type === 'PIN_WINDOW_OPEN') {
      params.highlightPin = 'true';
    }

    try {
      console.log('[Notifications] Navigating to booking:', data.bookingId);
      // Use string path with the actual ID for expo-router
      routerRef.current.push(`/booking/${data.bookingId}` as any);
    } catch (error) {
      console.error('[Notifications] Navigation error:', error);
      // Fallback: try alternate navigation approach
      try {
        routerRef.current.navigate(`/booking/${data.bookingId}` as any);
      } catch (fallbackError) {
        console.error('[Notifications] Fallback navigation also failed:', fallbackError);
      }
    }
  }, []);

  // ─── Register token when authenticated ──────────────────────────────────────

  const registerToken = useCallback(async () => {
    if (!isAuthenticated) return;
    try {
      const token = await notificationService.setupPushNotifications();
      if (token) {
        setExpoPushToken(token);
        console.log('[Notifications] Token registered successfully');
      }
    } catch (error) {
      console.error('[Notifications] Token registration failed:', error);
    }
  }, [isAuthenticated]);

  useEffect(() => {
    if (isAuthenticated) {
      registerToken();
    }
  }, [isAuthenticated, registerToken]);

  // ─── Handle foreground + background notification listeners ──────────────────

  useEffect(() => {
    if (!Notifications) return;

    // Listener for notifications received while app is in foreground
    notificationListener.current = Notifications.addNotificationReceivedListener(
      (notification: any) => {
        console.log('[Notifications] Foreground notification received');
        const data = notificationService.parseNotificationData(notification);
        const content = notification.request.content;

        setInAppNotification({
          id: notification.request.identifier,
          title: content.title || 'Turfsy',
          body: content.body || '',
          data,
          timestamp: Date.now(),
        });
      }
    );

    // Listener for when user taps a notification (foreground or background)
    responseListener.current = Notifications.addNotificationResponseReceivedListener(
      (response: any) => {
        console.log('[Notifications] Notification tapped');
        const notification = response.notification;
        const data = notificationService.parseNotificationData(notification);

        if (data) {
          // Small delay to ensure navigation is ready (especially coming from background)
          setTimeout(() => {
            navigateToBooking(data);
          }, 500);
        }
      }
    );

    return () => {
      if (!Notifications) return;
      if (notificationListener.current) {
        Notifications.removeNotificationSubscription(notificationListener.current);
      }
      if (responseListener.current) {
        Notifications.removeNotificationSubscription(responseListener.current);
      }
    };
  }, [navigateToBooking]);

  // ─── Check for notification that launched the app (cold start) ──────────────

  useEffect(() => {
    if (!isAuthenticated) return;

    const checkInitialNotification = async () => {
      if (!Notifications) return;
      const response = await Notifications.getLastNotificationResponseAsync();
      if (response) {
        const data = notificationService.parseNotificationData(response.notification);
        if (data) {
          // Longer delay for cold start — navigation tree needs time to mount
          setTimeout(() => {
            navigateToBooking(data);
          }, 1500);
        }
      }
    };

    checkInitialNotification();
  }, [isAuthenticated, navigateToBooking]);

  // ─── Dismiss in-app notification ────────────────────────────────────────────

  const dismissInAppNotification = useCallback(() => {
    setInAppNotification(null);
  }, []);

  // ─── Handle tap on in-app notification toast ────────────────────────────────

  const handleInAppNotificationTap = useCallback(() => {
    if (inAppNotification?.data) {
      navigateToBooking(inAppNotification.data);
    }
    setInAppNotification(null);
  }, [inAppNotification, navigateToBooking]);

  return {
    expoPushToken,
    inAppNotification,
    dismissInAppNotification,
    handleInAppNotificationTap,
    registerToken,
  };
};

export default useNotifications;
