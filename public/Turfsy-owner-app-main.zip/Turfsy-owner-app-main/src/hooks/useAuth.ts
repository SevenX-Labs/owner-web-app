// useAuth — Authentication hook

import { useCallback, useState } from 'react';
import { useAuthContext } from '../context/AuthContext';
import { AuthCredentials } from '../types/user.types';

export const useAuth = () => {
  const { user, token, isAuthenticated, isLoading, login, signup, logout, updateUser } = useAuthContext();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleLogin = useCallback(async (credentials: AuthCredentials) => {
    setLoading(true);
    setError(null);
    try {
      await login(credentials);
    } catch (err) {
      setError((err as Error).message || 'Login failed. Please try again.');
      throw err;
    } finally {
      setLoading(false);
    }
  }, [login]);

  const handleSignup = useCallback(async (data: {
    name: string;
    email: string;
    phone: string;
    password: string;
    businessName: string;
  }) => {
    setLoading(true);
    setError(null);
    try {
      await signup(data);
    } catch (err) {
      setError((err as Error).message || 'Signup failed. Please try again.');
      throw err;
    } finally {
      setLoading(false);
    }
  }, [signup]);

  const handleLogout = useCallback(async () => {
    setLoading(true);
    try {
      await logout();
    } finally {
      setLoading(false);
    }
  }, [logout]);

  return {
    user,
    token,
    isAuthenticated,
    isAuthLoading: isLoading,
    loading,
    error,
    login: handleLogin,
    signup: handleSignup,
    logout: handleLogout,
    updateUser,
    clearError: () => setError(null),
  };
};

export default useAuth;
