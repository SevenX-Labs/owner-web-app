// useBookings — Custom hook for booking state and actions

import { useEffect, useCallback } from 'react';
import { useBookingStore } from '../store/bookingSlice';
import { BookingFilter } from '../types/booking.types';

export const useBookings = (autoFetch = true) => {
  const {
    bookings,
    selectedBooking,
    summary,
    filter,
    loadingState,
    error,
    fetchBookings,
    fetchBookingById,
    fetchSummary,
    updateBookingStatus,
    setFilter,
    clearFilter,
    clearSelectedBooking,
    clearError,
  } = useBookingStore();

  useEffect(() => {
    if (autoFetch) {
      fetchBookings();
      fetchSummary();
    }
  }, [autoFetch]);

  const applyFilter = useCallback((newFilter: BookingFilter) => {
    setFilter(newFilter);
    fetchBookings(newFilter);
  }, [setFilter, fetchBookings]);

  const refresh = useCallback(() => {
    fetchBookings(filter);
    fetchSummary();
  }, [fetchBookings, fetchSummary, filter]);

  return {
    bookings,
    selectedBooking,
    summary,
    filter,
    isLoading: loadingState === 'loading',
    isSuccess: loadingState === 'success',
    isError: loadingState === 'error',
    error,
    fetchBookings,
    fetchBookingById,
    fetchSummary,
    updateBookingStatus,
    applyFilter,
    clearFilter,
    clearSelectedBooking,
    clearError,
    refresh,
  };
};

export default useBookings;
