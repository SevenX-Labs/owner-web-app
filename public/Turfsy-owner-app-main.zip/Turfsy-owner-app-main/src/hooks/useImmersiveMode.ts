import { useEffect } from 'react';
import { Platform } from 'react-native';
import { setStatusBarHidden } from 'expo-status-bar';
import { NavigationBar, addVisibilityListener } from 'expo-navigation-bar';

export function useImmersiveMode() {
  useEffect(() => {
    if (Platform.OS !== 'android') {
      return;
    }

    let mounted = true;

    const applyImmersiveMode = async () => {
      try {
        NavigationBar.setHidden(true);
        setStatusBarHidden(true, 'fade');
      } catch {
        // Ignore when the module is unavailable in the current build.
      }
    };

    void applyImmersiveMode();

    const subscription = addVisibilityListener(
      ({ visibility }: { visibility: 'visible' | 'hidden' }) => {
      if (!mounted || visibility !== 'visible') {
        return;
      }

      setTimeout(() => {
        if (mounted) {
          void applyImmersiveMode();
        }
      }, 1600);
      }
    );

    return () => {
      mounted = false;
      subscription.remove();
      setStatusBarHidden(false, 'fade');
    };
  }, []);
}
