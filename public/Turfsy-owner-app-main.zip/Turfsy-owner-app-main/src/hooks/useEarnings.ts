// useEarnings — Custom hook for earnings state and actions

import { useEffect, useCallback } from 'react';
import { useEarningsStore } from '../store/earningsSlice';
import { EarningsPeriod, EarningsFilter } from '../types/earnings.types';

export const useEarnings = (autoFetch = true) => {
  const {
    summary,
    transactions,
    analytics,
    filter,
    selectedPeriod,
    loadingState,
    analyticsLoading,
    error,
    fetchSummary,
    fetchTransactions,
    fetchAnalytics,
    setPeriod,
    setFilter,
    exportEarnings,
    clearError,
  } = useEarningsStore();

  useEffect(() => {
    if (autoFetch) {
      fetchSummary();
      fetchTransactions();
    }
  }, [autoFetch]);

  const changePeriod = useCallback((period: EarningsPeriod) => {
    setPeriod(period);
    fetchSummary();
    fetchTransactions({ ...filter, period });
  }, [setPeriod, fetchSummary, fetchTransactions, filter]);

  const applyFilter = useCallback((newFilter: EarningsFilter) => {
    setFilter(newFilter);
    fetchSummary();
    fetchTransactions(newFilter);
  }, [setFilter, fetchSummary, fetchTransactions]);

  const refresh = useCallback(() => {
    fetchSummary();
    fetchTransactions(filter);
  }, [fetchSummary, fetchTransactions, filter]);

  const handleExport = useCallback(async (format: 'csv' | 'pdf'): Promise<string> => {
    return exportEarnings(format);
  }, [exportEarnings]);

  return {
    summary,
    transactions,
    analytics,
    filter,
    selectedPeriod,
    isLoading: loadingState === 'loading',
    isAnalyticsLoading: analyticsLoading === 'loading',
    isError: loadingState === 'error',
    error,
    fetchSummary,
    fetchTransactions,
    fetchAnalytics,
    changePeriod,
    applyFilter,
    exportEarnings: handleExport,
    clearError,
    refresh,
  };
};

export default useEarnings;
