import AsyncStorage from '@react-native-async-storage/async-storage';
import { useColorScheme } from 'react-native';
import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';

export type ThemeMode = 'light' | 'dark' | 'system';

interface ThemeState {
  mode: ThemeMode;
  setMode: (mode: ThemeMode) => void;
}

export const useThemeStore = create<ThemeState>()(
  persist(
    (set) => ({
      mode: 'dark', // Force dark mode
      setMode: (mode) => set({ mode }),
    }),
    {
      name: 'theme-storage',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);

// ─── 2026 Premium SaaS Dark Theme ──────────────────────────────────────────
// Inspired by Stripe, Linear, Vercel — Turfzy Owner Pro
export const darkTheme = {
  colors: {
    // Backgrounds
    background: '#0C0D10',
    surface: '#181B20',
    surfaceMuted: '#121417',
    surfaceElevated: '#20242A',

    // Primary Accent — Lime Green (use sparingly: 5%)
    primary: '#B8FF17',
    primaryHover: '#A5EA15',
    primaryPressed: '#90D113',
    primarySoft: 'rgba(184, 255, 23, 0.10)',
    primarySoftOpaque: '#1A2208',

    // Text
    text: '#FFFFFF',
    textSecondary: '#B2B7C2',
    textMuted: '#7D8592',

    // Borders & Dividers
    border: '#2A2F37',
    divider: '#22262D',

    // Status
    success: '#2ED573',
    warning: '#FFC857',
    error: '#FF5D5D',
    info: '#4DA3FF',
    danger: '#FF5D5D',
    dangerSoft: 'rgba(255, 93, 93, 0.12)',

    // Input
    inputBackground: '#14171C',
    inputBorder: '#2D323B',
    inputFocusBorder: '#B8FF17',
    inputPlaceholder: '#6E7480',

    // Cards
    cardBorder: '#262A31',
    cardShadow: 'rgba(0, 0, 0, 0.22)',

    // Bottom Navigation
    navBackground: '#15181C',
    navActiveIcon: '#B8FF17',
    navInactiveIcon: '#8B9099',
  },
  radius: {
    card: 24,
    button: 18,
    input: 18,
    badge: 12,
    pill: 999,
  },
  spacing: {
    xs: 4,
    sm: 8,
    md: 16,
    lg: 24,
    xl: 32,
    xxl: 48,
  },
  fonts: {
    regular: 'Geist_400Regular',
    medium: 'Geist_500Medium',
    semiBold: 'Geist_600SemiBold',
    bold: 'Geist_700Bold',
    extraBold: 'Geist_800ExtraBold',
    black: 'Geist_900Black',
  },
};

// ─── 2026 Premium SaaS Light Theme ─────────────────────────────────────────
export const lightTheme = {
  colors: {
    // Backgrounds
    background: '#F9FAFB',
    surface: '#FFFFFF',
    surfaceMuted: '#F3F4F6',
    surfaceElevated: '#FFFFFF',

    // Primary Accent — Lime Green (adjusted for light mode)
    primary: '#90D113', // slightly darker lime for contrast
    primaryHover: '#7BB310',
    primaryPressed: '#66960D',
    primarySoft: 'rgba(144, 209, 19, 0.10)',
    primarySoftOpaque: '#ECF5D8',

    // Text
    text: '#111827',
    textSecondary: '#4B5563',
    textMuted: '#9CA3AF',

    // Borders & Dividers
    border: '#E5E7EB',
    divider: '#F3F4F6',

    // Status
    success: '#10B981',
    warning: '#F59E0B',
    error: '#EF4444',
    info: '#3B82F6',
    danger: '#EF4444',
    dangerSoft: 'rgba(239, 68, 68, 0.1)',

    // Input
    inputBackground: '#F9FAFB',
    inputBorder: '#D1D5DB',
    inputFocusBorder: '#90D113',
    inputPlaceholder: '#9CA3AF',

    // Cards
    cardBorder: '#E5E7EB',
    cardShadow: 'rgba(0, 0, 0, 0.05)',

    // Bottom Navigation
    navBackground: '#FFFFFF',
    navActiveIcon: '#90D113',
    navInactiveIcon: '#9CA3AF',
  },
  radius: darkTheme.radius,
  spacing: darkTheme.spacing,
  fonts: darkTheme.fonts,
};

export const useAppTheme = () => {
  const mode = useThemeStore((s) => s.mode);
  const setMode = useThemeStore((s) => s.setMode);
  const systemScheme = useColorScheme();

  const activeMode = mode === 'system' ? systemScheme : mode;
  const isDark = activeMode === 'dark';
  const theme = isDark ? darkTheme : lightTheme;

  return {
    isDark,
    theme,
    mode,
    setMode,
  };
};
