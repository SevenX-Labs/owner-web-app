// Earnings Zustand Store Slice

import { create } from 'zustand';
import { EarningsSummary, Transaction, EarningsAnalytics, EarningsFilter, EarningsPeriod } from '../types/earnings.types';
import { LoadingState } from '../types/common.types';
import earningsService from '../services/earningsService';

interface EarningsState {
  summary: EarningsSummary | null;
  transactions: Transaction[];
  analytics: EarningsAnalytics | null;
  filter: EarningsFilter;
  selectedPeriod: EarningsPeriod;
  loadingState: LoadingState;
  analyticsLoading: LoadingState;
  error: string | null;

  // Actions
  fetchSummary: () => Promise<void>;
  fetchTransactions: (filter?: EarningsFilter) => Promise<void>;
  fetchAnalytics: () => Promise<void>;
  setPeriod: (period: EarningsPeriod) => void;
  setFilter: (filter: EarningsFilter) => void;
  exportEarnings: (format: 'csv' | 'pdf') => Promise<string>;
  clearError: () => void;
}

export const useEarningsStore = create<EarningsState>((set, get) => ({
  summary: null,
  transactions: [],
  analytics: null,
  filter: { period: 'month' },
  selectedPeriod: 'month',
  loadingState: 'idle',
  analyticsLoading: 'idle',
  error: null,

  fetchSummary: async () => {
    set({ loadingState: 'loading', error: null });
    try {
      const summary = await earningsService.getEarningsSummary(get().filter);
      set({ summary, loadingState: 'success' });
    } catch (err) {
      set({ loadingState: 'error', error: (err as Error).message });
    }
  },

  fetchTransactions: async (filter?: EarningsFilter) => {
    set({ loadingState: 'loading', error: null });
    try {
      const transactions = await earningsService.getTransactions(filter ?? get().filter);
      set({ transactions, loadingState: 'success' });
    } catch (err) {
      set({ loadingState: 'error', error: (err as Error).message });
    }
  },

  fetchAnalytics: async () => {
    set({ analyticsLoading: 'loading' });
    try {
      const analytics = await earningsService.getEarningsAnalytics();
      set({ analytics, analyticsLoading: 'success' });
    } catch (err) {
      set({ analyticsLoading: 'error', error: (err as Error).message });
    }
  },

  setPeriod: (period: EarningsPeriod) => {
    set({ selectedPeriod: period, filter: { ...get().filter, period } });
  },

  setFilter: (filter: EarningsFilter) => set({ filter }),

  exportEarnings: async (format: 'csv' | 'pdf'): Promise<string> => {
    const result = await earningsService.exportEarnings(format);
    return result.url;
  },

  clearError: () => set({ error: null }),
}));
