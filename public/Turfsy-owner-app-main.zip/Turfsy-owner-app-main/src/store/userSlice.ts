// User Zustand Store Slice

import { create } from 'zustand';
import { OwnerProfile, AppSettings, AuthCredentials } from '../types/user.types';
import { LoadingState } from '../types/common.types';
import userService from '../services/userService';

interface UserState {
  profile: OwnerProfile | null;
  settings: AppSettings | null;
  isAuthenticated: boolean;
  loadingState: LoadingState;
  error: string | null;

  // Actions
  login: (credentials: AuthCredentials) => Promise<void>;
  logout: () => Promise<void>;
  fetchProfile: () => Promise<void>;
  updateProfile: (updates: Partial<OwnerProfile>) => Promise<void>;
  fetchSettings: () => Promise<void>;
  updateSettings: (settings: Partial<AppSettings>) => Promise<void>;
  clearError: () => void;
}

export const useUserStore = create<UserState>((set) => ({
  profile: null,
  settings: null,
  isAuthenticated: false,
  loadingState: 'idle',
  error: null,

  login: async (credentials: AuthCredentials) => {
    set({ loadingState: 'loading', error: null });
    try {
      const response = await userService.login(credentials);
      set({ profile: response.user, isAuthenticated: true, loadingState: 'success' });
    } catch (err) {
      set({ loadingState: 'error', error: (err as Error).message });
      throw err;
    }
  },

  logout: async () => {
    set({ loadingState: 'loading' });
    try {
      await userService.logout();
      set({ profile: null, settings: null, isAuthenticated: false, loadingState: 'idle' });
    } catch (err) {
      set({ loadingState: 'error', error: (err as Error).message });
    }
  },

  fetchProfile: async () => {
    set({ loadingState: 'loading', error: null });
    try {
      const profile = await userService.getProfile();
      set({ profile, isAuthenticated: true, loadingState: 'success' });
    } catch (err) {
      set({ loadingState: 'error', error: (err as Error).message });
    }
  },

  updateProfile: async (updates: Partial<OwnerProfile>) => {
    set({ loadingState: 'loading', error: null });
    try {
      const updated = await userService.updateProfile(updates);
      set({ profile: updated, loadingState: 'success' });
    } catch (err) {
      set({ loadingState: 'error', error: (err as Error).message });
    }
  },

  fetchSettings: async () => {
    try {
      const settings = await userService.getSettings();
      set({ settings });
    } catch (err) {
      console.error('Failed to load settings:', err);
    }
  },

  updateSettings: async (updates: Partial<AppSettings>) => {
    try {
      const updated = await userService.updateSettings(updates);
      set({ settings: updated });
    } catch (err) {
      console.error('Failed to update settings:', err);
    }
  },

  clearError: () => set({ error: null }),
}));
