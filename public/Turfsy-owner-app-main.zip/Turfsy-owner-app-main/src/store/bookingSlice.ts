// Booking Zustand Store Slice

import { create } from 'zustand';
import { Booking, BookingFilter, BookingSummary } from '../types/booking.types';
import { LoadingState } from '../types/common.types';
import bookingService from '../services/bookingService';

interface BookingState {
  bookings: Booking[];
  selectedBooking: Booking | null;
  summary: BookingSummary | null;
  filter: BookingFilter;
  loadingState: LoadingState;
  error: string | null;

  // Actions
  fetchBookings: (filter?: BookingFilter) => Promise<void>;
  fetchBookingById: (id: string) => Promise<void>;
  fetchSummary: () => Promise<void>;
  updateBookingStatus: (id: string, status: Booking['status']) => Promise<void>;
  setFilter: (filter: BookingFilter) => void;
  clearFilter: () => void;
  clearSelectedBooking: () => void;
  clearError: () => void;
}

export const useBookingStore = create<BookingState>((set, get) => ({
  bookings: [],
  selectedBooking: null,
  summary: null,
  filter: {},
  loadingState: 'idle',
  error: null,

  fetchBookings: async (filter?: BookingFilter) => {
    set({ loadingState: 'loading', error: null });
    try {
      const activeFilter = filter ?? get().filter;
      const result = await bookingService.getBookings(activeFilter);
      set({ bookings: result.items, loadingState: 'success' });
    } catch (err) {
      set({ loadingState: 'error', error: (err as Error).message });
    }
  },

  fetchBookingById: async (id: string) => {
    set({ loadingState: 'loading', error: null });
    try {
      const booking = await bookingService.getBookingById(id);
      set({ selectedBooking: booking, loadingState: 'success' });
    } catch (err) {
      set({ loadingState: 'error', error: (err as Error).message });
    }
  },

  fetchSummary: async () => {
    try {
      const summary = await bookingService.getBookingSummary();
      set({ summary });
    } catch (err) {
      console.error('Failed to fetch summary:', err);
    }
  },

  updateBookingStatus: async (id: string, status: Booking['status']) => {
    set({ loadingState: 'loading', error: null });
    try {
      const result = await bookingService.updateBookingStatus(id, status);
      set(state => ({
        bookings: state.bookings.map(b => b.id === id ? result.data : b),
        selectedBooking: state.selectedBooking?.id === id ? result.data : state.selectedBooking,
        loadingState: 'success',
      }));
    } catch (err) {
      set({ loadingState: 'error', error: (err as Error).message });
    }
  },

  setFilter: (filter: BookingFilter) => set({ filter }),

  clearFilter: () => set({ filter: {} }),

  clearSelectedBooking: () => set({ selectedBooking: null }),

  clearError: () => set({ error: null }),
}));
