import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect, useRouter } from 'expo-router';
import React, { useCallback, useState, useEffect } from 'react';
import { RefreshControl, StyleSheet, View, TouchableOpacity, Text } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { AppHeader } from '@/src/components/common/AppHeader';
import { HeroRevenueCard } from '@/src/components/dashboard/HeroRevenueCard';
import { RecentBookingsList } from '@/src/components/dashboard/RecentBookingsList';
import { Screen } from '@/src/components/layout/Screen';
import { StatCard } from '@/src/components/ui/StatCard';
import { PendingApprovalsList } from '@/src/components/dashboard/PendingApprovalsList';
import { RevenueChartCard } from '@/src/components/dashboard/RevenueChartCard';
import { SettlementOverviewCard } from '@/src/components/dashboard/SettlementOverviewCard';
import { useAuthContext } from '@/src/context/AuthContext';
import { useAppTheme } from '@/src/hooks/useAppTheme';
import { STORAGE_KEYS } from '@/src/utils/constants';
import { useResponsive } from '@/src/utils/responsive';
import { getProfile } from '@/src/utils/storage';

import { Skeleton } from '@/src/components/ui/Skeleton';

interface DashboardState {
  summary?: {
    revenue?: { today?: number; month?: number; overall?: number };
    counts?: { total?: number; today?: number; upcoming?: number; completed?: number; cancelled?: number; noShow?: number };
    quickStats?: { avgBookingValue?: number; cancellationRate?: string };
  };
  trends?: {
    peakHour?: string;
    paymentSplit?: { online?: number; cash?: number };
    mostBookedTurf?: string;
  };
  recentBookings?: any[];
  alerts?: any[];
}

export default function HomeScreen() {
  const router = useRouter();
  const responsive = useResponsive();
  const { theme } = useAppTheme();
  const { user } = useAuthContext();

  const [loading, setLoading] = useState(true);
  const [dashboardData, setDashboardData] = useState<DashboardState | null>(null);
  const [profileName, setProfileName] = useState<string>('');

  const dashboardDataRef = React.useRef(dashboardData);
  useEffect(() => {
    dashboardDataRef.current = dashboardData;
  }, [dashboardData]);

  const fetchDashboard = useCallback(async () => {
    try {
      if (!dashboardDataRef.current) {
        setLoading(true);
      }
      const token = await AsyncStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
      if (!token) return;

      const res = await fetch('https://turfsy.onrender.com/api/v3/owner-home/dashboard', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Accept': 'application/json',
        }
      });
      const data = await res.json();
      if (data.success) {
        setDashboardData(data.data);
      }
      
      const p = await getProfile();
      if (p) {
        setProfileName(p.ownerName || (p as any).name || user?.name || '');
      }
    } catch (error) {
      console.warn('Failed to load dashboard data:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      fetchDashboard();
    }, [fetchDashboard])
  );

  const handleSeeAll = () => router.push('/bookings');

  // ─── Greeting based on time ────────────────────────────────────────────────
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good Morning';
    if (hour < 17) return 'Good Afternoon';
    return 'Good Evening';
  };

  const monthlyRevenue = dashboardData?.summary?.revenue?.month || 0;
  const todayCount = dashboardData?.summary?.counts?.today || 0;
  const upcomingCount = dashboardData?.summary?.counts?.upcoming || 0;
  const completedCount = dashboardData?.summary?.counts?.completed || 0;
  
  const displayFirstName = (profileName || user?.name || 'Owner').split(' ')[0];

  if (loading && !dashboardData) {
    return <Skeleton.HomeScreen />;
  }

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.background }}>
      <Screen
        scrollable
      refreshControl={<RefreshControl refreshing={loading} onRefresh={fetchDashboard} tintColor={theme.colors.primary} />}
      contentStyle={{ paddingHorizontal: responsive.isTablet ? 32 : 24, paddingTop: 16 }}
    >
      {/* ─── Header ──────────────────────────────────────────── */}
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <Text style={{ fontSize: responsive.fp(28), color: theme.colors.text }}>
          <Text style={{ fontFamily: theme.fonts.medium, color: theme.colors.textMuted }}>Hi, </Text>
          <Text style={{ fontFamily: theme.fonts.black, letterSpacing: -0.5 }}>
            {displayFirstName}
          </Text>
        </Text>
        <TouchableOpacity
          style={{
            width: 44,
            height: 44,
            borderRadius: 14,
            borderWidth: 1,
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: theme.colors.surfaceElevated,
            borderColor: theme.colors.border,
          }}
          onPress={() => router.push('/notifications')}
        >
          <Ionicons name="notifications-outline" size={18} color={theme.colors.textSecondary} />
        </TouchableOpacity>
      </View>

      {/* ─── Revenue Hero Card ──────────────────────────────────────────────── */}
      <HeroRevenueCard 
        monthlyRevenue={monthlyRevenue}
        upcomingCount={upcomingCount}
        onViewAll={handleSeeAll}
      />

      {/* ─── Quick Stats Grid ───────────────────────────────────────────────── */}
      <View style={styles.statsGrid}>
        <StatCard
          label="TODAY"
          value={String(todayCount)}
          icon="calendar-outline"
          style={{ flex: 1 }}
        />
        <StatCard
          label="PENDING"
          value={String(upcomingCount)}
          icon="time-outline"
          style={{ flex: 1 }}
        />
        <StatCard
          label="COMPLETED"
          value={String(completedCount)}
          icon="checkmark-done-outline"
          style={{ flex: 1 }}
        />
      </View>

      {/* ─── Revenue Trends Chart ───────────────────────────────────────────── */}
      <RevenueChartCard data={(dashboardData?.trends as any)?.revenueChart} />

      {/* ─── Pending Approvals List ───────────────────────────────────────── */}
      <PendingApprovalsList />

      {/* ─── Settlements Overview ─────────────────────────────────────────── */}
      <SettlementOverviewCard />

      {/* ─── Recent Bookings List ─────────────────────────────────────────── */}
      <RecentBookingsList 
        recentBookings={dashboardData?.recentBookings}
        onSeeAll={handleSeeAll}
      />

      {/* Bottom spacer for nav bar */}
      <View style={{ height: 100 }} />
      </Screen>

      {/* ─── QR Scanner FAB ──────────────────────────────────────────────── */}
      <TouchableOpacity 
        style={[styles.fab, { backgroundColor: theme.colors.primary }]} 
        activeOpacity={0.85}
        onPress={() => router.push('/scanner')}
      >
        <Ionicons name="qr-code-outline" size={20} color="#000000" />
        <Text style={styles.fabText}>Scan QR</Text>
      </TouchableOpacity>
    </View>
  );
}

// ─── Styles ────────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  statsGrid: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 32,
  },
  fab: {
    position: 'absolute',
    bottom: 24,
    right: 24,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderRadius: 30,
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  fabText: {
    color: '#000000',
    fontWeight: '900',
    fontSize: 16,
    letterSpacing: 0.5,
  },
});
