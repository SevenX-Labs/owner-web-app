import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect, useRouter } from 'expo-router';
import React, { useCallback, useMemo, useState, useEffect } from 'react';
import { FlatList, RefreshControl, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';

import { AppHeader } from '@/src/components/common/AppHeader';
import { Screen } from '@/src/components/layout/Screen';
import { SectionCard } from '@/src/components/ui/SectionCard';
import { StatCard } from '@/src/components/ui/StatCard';
import { STORAGE_KEYS } from '@/src/utils/constants';
import { useResponsive } from '@/src/utils/responsive';
import { useAppTheme } from '@/src/hooks/useAppTheme';
import { Skeleton } from '@/src/components/ui/Skeleton';

interface ApiBooking {
  _id?: string;
  id?: string;
  displayId?: string;
  userName?: string;
  user?: {
    name?: string;
  };
  turf?: {
    name?: string;
  };
  bookingDate: string;
  startTime: string;
  endTime: string;
  status?: string;
  bookingStatus?: string;
  totalAmount?: number;
  amount?: number;
}

const filters: { label: string; value: string }[] = [
  { label: 'All', value: '' },
  { label: 'Pending', value: 'PENDING' },
  { label: 'Confirmed', value: 'CONFIRMED' },
  { label: 'Completed', value: 'COMPLETED' },
];

function getStyles(theme: any) {
  return StyleSheet.create({
    content: {
      paddingTop: 16,
      paddingBottom: 120,
    },
    statsContainer: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      backgroundColor: theme.colors.surfaceMuted,
      borderRadius: 24,
      paddingVertical: 20,
      paddingHorizontal: 16,
      marginBottom: 20,
      borderWidth: 1,
      borderColor: theme.colors.border,
    },
    statBox: {
      flex: 1,
      alignItems: 'center',
      gap: 4,
    },
    statDivider: {
      width: 1,
      height: '80%',
      backgroundColor: theme.colors.border,
      marginHorizontal: 8,
    },
    statValue: {
      color: theme.colors.text,
      fontWeight: '900',
      letterSpacing: -0.5,
    },
    statLabel: {
      color: theme.colors.textMuted,
      fontWeight: '700',
      letterSpacing: 0.5,
    },
    searchBox: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 12,
      backgroundColor: theme.colors.surface,
      borderRadius: 20,
      borderWidth: 1.5,
      borderColor: theme.colors.border,
      paddingHorizontal: 16,
      paddingVertical: 14,
      marginBottom: 16,
    },
    searchInput: {
      flex: 1,
      color: theme.colors.text,
      fontWeight: '700',
      padding: 0,
    },
    filterRow: {
      flexDirection: 'row',
      flexWrap: 'wrap',
      gap: 10,
      marginBottom: 20,
    },
    filterChip: {
      paddingHorizontal: 16,
      paddingVertical: 10,
      borderRadius: 24,
      backgroundColor: theme.colors.surfaceMuted,
      borderWidth: 1,
      borderColor: theme.colors.border,
    },
    filterChipActive: {
      backgroundColor: theme.colors.primary,
      borderColor: theme.colors.primary,
    },
    filterText: {
      color: theme.colors.textMuted,
      fontWeight: '700',
      letterSpacing: 0.5,
    },
    filterTextActive: {
      color: '#000000',
    },
    bookingCard: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 16,
      padding: 16,
      marginBottom: 10,
      backgroundColor: theme.colors.surface,
    },
    bookingIconWrap: {
      width: 60,
      height: 60,
      borderRadius: 16,
      backgroundColor: theme.colors.surfaceMuted,
      alignItems: 'center',
      justifyContent: 'center',
      borderWidth: 1,
      borderColor: theme.colors.border,
    },
    bookingDateDay: {
        color: theme.colors.text,
        fontSize: 22,
        fontWeight: '900',
        lineHeight: 26,
    },
    bookingDateMonth: {
        color: theme.colors.primary,
        fontSize: 12,
        fontWeight: '800',
        letterSpacing: 1,
    },
    bookingInfo: {
      flex: 1,
      gap: 6,
    },
    bookingTitle: {
      color: theme.colors.text,
      fontWeight: '800',
      letterSpacing: 0.5,
    },
    timeRow: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 6,
    },
    bookingMeta: {
      color: theme.colors.textMuted,
      fontWeight: '500',
    },
    metaDivider: {
        width: 4,
        height: 4,
        borderRadius: 2,
        backgroundColor: theme.colors.border,
        marginHorizontal: 4,
    },
    bookingAmount: {
        color: theme.colors.text,
        fontWeight: '700',
    },
    statusBadge: {
      flexDirection: 'row',
      alignItems: 'center',
      alignSelf: 'flex-start',
      backgroundColor: theme.colors.surfaceMuted,
      paddingHorizontal: 8,
      paddingVertical: 4,
      borderRadius: 8,
      gap: 4,
      marginTop: 2,
      borderWidth: 1,
      borderColor: theme.colors.border,
    },
    statusDot: {
        width: 6,
        height: 6,
        borderRadius: 3,
    },
    statusText: {
      color: theme.colors.textMuted,
      fontWeight: '700',
      letterSpacing: 0.5,
    },
    bookingAction: {
      width: 40,
      height: 40,
      borderRadius: 20,
      backgroundColor: theme.colors.surfaceMuted,
      alignItems: 'center',
      justifyContent: 'center',
    },
    emptyState: {
        paddingVertical: 48,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: theme.colors.surface,
        borderRadius: 24,
        borderWidth: 1,
        borderColor: theme.colors.border,
        borderStyle: 'dashed',
        marginTop: 24,
    },
    emptyStateText: {
        color: theme.colors.text,
        fontSize: 16,
        fontWeight: '700',
        marginTop: 16,
        marginBottom: 4,
    },
    emptyStateSubtext: {
        color: theme.colors.textMuted,
        fontSize: 14,
    }
  });
}

export default function BookingScreen() {
  const router = useRouter();
  const responsive = useResponsive();
  const { theme } = useAppTheme();
  const styles = getStyles(theme);
  const STATUS_COLORS: Record<string, string> = {
    CONFIRMED: '#22C55E',
    PENDING: '#F59E0B',
    COMPLETED: theme.colors.textMuted,
    CANCELLED: '#EF4444',
    NO_SHOW: '#8B5CF6',
  };

  const [query, setQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<string>('');

  const [loading, setLoading] = useState(true);
  const [bookings, setBookings] = useState<ApiBooking[]>([]);
  const [analytics, setAnalytics] = useState<any>(null);

  const bookingsRef = React.useRef(bookings);
  useEffect(() => {
    bookingsRef.current = bookings;
  }, [bookings]);

  const fetchData = useCallback(async () => {
    try {
      if (bookingsRef.current.length === 0) {
        setLoading(true);
      }
      const token = await AsyncStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
      if (!token) {
        setLoading(false);
        return;
      }

      const [bookingsRes, analyticsRes] = await Promise.all([
        fetch('https://turfsy.onrender.com/api/v3/booking/owner/bookings', {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Accept': 'application/json',
          }
        }),
        fetch('https://turfsy.onrender.com/api/v3/owner-analytics/overall', {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Accept': 'application/json',
          }
        })
      ]);

      const [bookingsData, analyticsData] = await Promise.all([
        bookingsRes.json(),
        analyticsRes.json()
      ]);

      if (bookingsData.success) {
        setBookings(bookingsData.data);
      }
      if (analyticsData.success) {
        setAnalytics(analyticsData.data);
      }
    } catch (error) {
      console.warn('Failed to load bookings data:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      fetchData();
    }, [fetchData])
  );

  const filteredBookings = useMemo(() => {
    return bookings.filter(b => {
      const displayIdStr = b.displayId || b.id || '';
      const userNameStr = (b as any).userName || b.user?.name || '';
      const matchesQuery = displayIdStr.toLowerCase().includes(query.toLowerCase()) || 
                          userNameStr.toLowerCase().includes(query.toLowerCase());
      const bookingStatusVal = b.bookingStatus || b.status || '';
      const matchesFilter = activeFilter === '' || bookingStatusVal === activeFilter;
      return matchesQuery && matchesFilter;
    });
  }, [bookings, query, activeFilter]);

  if (loading && bookings.length === 0) {
    return <Skeleton.BookingScreen />;
  }

  return (
    <Screen 
      contentStyle={{ paddingHorizontal: responsive.isTablet ? 32 : 24, paddingTop: 12 }}
    >
      <AppHeader title="Bookings" action={{ icon: 'filter-outline' }} />
      
      <FlatList
        data={filteredBookings}
        keyExtractor={(item, index) => item.id || item._id || index.toString()}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={fetchData} tintColor={theme.colors.primary} />}
        ListHeaderComponent={
          <>
            {/* Quick Metrics */}
            <View style={styles.statsContainer}>
              <View style={styles.statBox}>
                <Text style={[styles.statValue, { fontSize: responsive.fp(22) }]}>{analytics?.totalBookings || '0'}</Text>
                <Text style={[styles.statLabel, { fontSize: responsive.fp(11) }]}>TOTAL</Text>
              </View>
              <View style={styles.statDivider} />
              <View style={styles.statBox}>
                <Text style={[styles.statValue, { fontSize: responsive.fp(22) }]}>{analytics?.completedBookings || '0'}</Text>
                <Text style={[styles.statLabel, { fontSize: responsive.fp(11) }]}>DONE</Text>
              </View>
              <View style={styles.statDivider} />
              <View style={styles.statBox}>
                <Text style={[styles.statValue, { fontSize: responsive.fp(22) }]}>{analytics?.cancelledBookings || '0'}</Text>
                <Text style={[styles.statLabel, { fontSize: responsive.fp(11) }]}>LOST</Text>
              </View>
            </View>

            {/* Search & Filter */}
            <View style={styles.searchBox}>
              <Ionicons name="search-outline" size={20} color={theme.colors.textMuted} />
              <TextInput
                style={[styles.searchInput, { fontSize: responsive.fp(15) }]}
                placeholder="Search by ID or User..."
                placeholderTextColor={theme.colors.textMuted}
                value={query}
                onChangeText={setQuery}
              />
            </View>

            <View style={styles.filterRow}>
              {filters.map((f) => (
                <TouchableOpacity
                  key={f.value}
                  onPress={() => setActiveFilter(f.value)}
                  style={[styles.filterChip, activeFilter === f.value && styles.filterChipActive]}
                >
                  <Text style={[styles.filterText, { fontSize: responsive.fp(13) }, activeFilter === f.value && styles.filterTextActive]}>
                    {f.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </>
        }
        renderItem={({ item }) => {
          const bookingStatusVal = item.bookingStatus || item.status || 'PENDING';
          const statusColor = STATUS_COLORS[bookingStatusVal] || theme.colors.textMuted;
          const bDate = new Date(item.bookingDate);
          const bookingId = item.id || item._id || '';
          return (
            <TouchableOpacity
              activeOpacity={0.8}
              onPress={() => router.push(`/booking/${bookingId}` as any)}
            >
              <SectionCard style={styles.bookingCard}>
                <View style={styles.bookingIconWrap}>
                    <Text style={styles.bookingDateDay}>
                        {isNaN(bDate.getTime()) ? '--' : bDate.toLocaleDateString('en-US', { day: 'numeric' })}
                    </Text>
                    <Text style={styles.bookingDateMonth}>
                        {isNaN(bDate.getTime()) ? '---' : bDate.toLocaleDateString('en-US', { month: 'short' }).toUpperCase()}
                    </Text>
                </View>
                <View style={styles.bookingInfo}>
                  <Text style={[styles.bookingTitle, { fontSize: responsive.fp(16) }]} numberOfLines={1}>
                    {(item as any).userName || item.user?.name || 'Guest User'} <Text style={{color: theme.colors.textMuted, fontWeight: '600'}}>• {item.displayId || (bookingId ? bookingId.substring(bookingId.length - 6) : '')}</Text>
                  </Text>
                  <View style={styles.timeRow}>
                    <Ionicons name="time-outline" size={responsive.moderateScale(14)} color={theme.colors.textMuted} />
                    <Text style={[styles.bookingMeta, { fontSize: responsive.fp(13) }]}>
                      {item.startTime} - {item.endTime}
                    </Text>
                    <View style={styles.metaDivider} />
                    <Text style={[styles.bookingAmount, { fontSize: responsive.fp(13) }]}>
                      Rs {item.amount || item.totalAmount || 0}
                    </Text>
                  </View>
                  <View style={[styles.statusBadge, { borderColor: statusColor, backgroundColor: `${statusColor}15` }]}>
                    <View style={[styles.statusDot, { backgroundColor: statusColor }]} />
                    <Text style={[styles.statusText, { fontSize: responsive.fp(10), color: statusColor }]}>
                      {bookingStatusVal.charAt(0).toUpperCase() + bookingStatusVal.slice(1).toLowerCase()}
                    </Text>
                  </View>
                </View>
                <View style={styles.bookingAction}>
                  <Ionicons name="chevron-forward" size={responsive.moderateScale(20)} color={theme.colors.textMuted} />
                </View>
              </SectionCard>
            </TouchableOpacity>
          );
        }}
        ListEmptyComponent={
          <View style={styles.emptyState}>
              <Ionicons name="calendar-outline" size={48} color={theme.colors.border} />
              <Text style={styles.emptyStateText}>No bookings match this filter.</Text>
              <Text style={styles.emptyStateSubtext}>Try changing the filter or search term.</Text>
          </View>
        }
      />
    </Screen>
  );
}
