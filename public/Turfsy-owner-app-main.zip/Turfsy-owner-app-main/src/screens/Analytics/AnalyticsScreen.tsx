import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect, useRouter } from 'expo-router';
import React, { useCallback, useState } from 'react';
import { RefreshControl, StyleSheet, Text, View, TouchableOpacity } from 'react-native';

import { AppHeader } from '@/src/components/common/AppHeader';
import { Screen } from '@/src/components/layout/Screen';
import { SectionCard } from '@/src/components/ui/SectionCard';
import { STORAGE_KEYS } from '@/src/utils/constants';
import { useResponsive } from '@/src/utils/responsive';
import { useAppTheme } from '@/src/hooks/useAppTheme';
import { Skeleton } from '@/src/components/ui/Skeleton';

interface OverallMetrics {
  totalRevenue: number;
  totalBookings: number;
  completedBookings: number;
  cancelledBookings: number;
  noShowBookings: number;
  cancellationRate: string;
  noShowRate: string;
}

function getStyles(theme: any) {
  return StyleSheet.create({
    statsContainer: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      backgroundColor: theme.colors.surfaceMuted,
      borderRadius: 24,
      paddingVertical: 20,
      paddingHorizontal: 16,
      marginBottom: 20,
      borderWidth: 1,
      borderColor: theme.colors.border,
    },
    statBox: {
      flex: 1,
      alignItems: 'center',
      gap: 4,
    },
    statDivider: {
      width: 1,
      height: '80%',
      backgroundColor: theme.colors.border,
      marginHorizontal: 8,
    },
    statValue: {
      color: theme.colors.text,
      fontWeight: '900',
      letterSpacing: -0.5,
    },
    statLabel: {
      color: theme.colors.textMuted,
      fontWeight: '700',
      letterSpacing: 0.5,
    },
    heroCard: {
      borderRadius: 24,
      padding: 24,
      marginBottom: 24,
      borderWidth: 1,
      shadowColor: '#000000',
      shadowOffset: { width: 0, height: 10 },
      shadowOpacity: 0.22,
      shadowRadius: 30,
      elevation: 8,
    },
    heroContent: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'flex-start',
      marginBottom: 24,
    },
    heroEyebrow: {
      color: theme.colors.textMuted,
      fontFamily: theme.fonts.semiBold,
      letterSpacing: 1.5,
      marginBottom: 8,
    },
    heroValue: {
      color: theme.colors.text,
      fontFamily: theme.fonts.black,
      letterSpacing: -1,
    },
    heroIconWrapper: {
      width: 48,
      height: 48,
      borderRadius: 16,
      alignItems: 'center',
      justifyContent: 'center',
    },
    heroFooter: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      paddingTop: 16,
      borderTopWidth: 1,
    },
    heroNoteRow: {
      flex: 1,
      flexDirection: 'row',
      alignItems: 'center',
      gap: 8,
      paddingRight: 10,
    },
    heroNote: {
      flex: 1,
      flexWrap: 'wrap',
      color: theme.colors.textSecondary,
      fontFamily: theme.fonts.medium,
    },
    chartCard: {
      padding: 20,
      borderRadius: 24,
      backgroundColor: theme.colors.surfaceMuted,
      marginBottom: 24,
      borderWidth: 1,
      borderColor: theme.colors.border,
    },
    sectionLabel: {
      color: theme.colors.textMuted,
      fontWeight: '800',
      letterSpacing: 1.5,
      marginBottom: 14,
    },
    chartRow: {
      flexDirection: 'row',
      alignItems: 'flex-end',
      gap: 6,
    },
    barGroup: {
      flex: 1,
      alignItems: 'center',
      minWidth: 0,
    },
    barTrack: {
      width: '100%',
      maxWidth: 28,
      justifyContent: 'flex-end',
      borderRadius: 8,
      backgroundColor: theme.colors.surface,
      overflow: 'hidden',
    },
    barFill: {
      width: '100%',
      borderRadius: 8,
      backgroundColor: theme.colors.primary,
    },
    barLabel: {
      color: theme.colors.textMuted,
      fontWeight: '700',
      marginTop: 8,
    },
    metricRow: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 12,
      paddingVertical: 12,
      borderBottomWidth: 1,
      borderBottomColor: theme.colors.border,
    },
    metricRowLast: {
      borderBottomWidth: 0,
      paddingBottom: 0,
    },
    metricLabelRow: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 8,
      flex: 1,
    },
    metricLabel: {
      color: theme.colors.textMuted,
      fontWeight: '600',
    },
    metricValue: {
      color: theme.colors.text,
      fontWeight: '800',
    }
  });
}

export default function AnalyticsScreen() {
  const router = useRouter();
  const responsive = useResponsive();
  const { theme } = useAppTheme();
  const styles = getStyles(theme);
  const BAR_HEIGHT = responsive.hp(120);

  const [loading, setLoading] = useState(true);
  const [overall, setOverall] = useState<OverallMetrics | null>(null);
  const [revenueByDate, setRevenueByDate] = useState<{ date: string, revenue: number }[]>([]);
  const [peakHours, setPeakHours] = useState<{ hour: string, count: number }[]>([]);

  const fetchAnalytics = useCallback(async () => {
    try {
      setLoading(true);
      const token = await AsyncStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
      if (!token) {
        setLoading(false);
        return;
      }

      const headers = {
        'Authorization': `Bearer ${token}`,
        'Accept': 'application/json',
      };

      const [overallRes, revRes, peakRes] = await Promise.all([
        fetch('https://turfsy.onrender.com/api/v3/owner-analytics/overall', { headers }),
        fetch('https://turfsy.onrender.com/api/v3/owner-analytics/revenue-by-date', { headers }),
        fetch('https://turfsy.onrender.com/api/v3/owner-analytics/peak-hours', { headers })
      ]);

      const [overallData, revData, peakData] = await Promise.all([
        overallRes.json(), revRes.json(), peakRes.json()
      ]);

      if (overallData.success) setOverall(overallData.data);
      if (revData.success) {
        setRevenueByDate(revData.data.slice(-7));
      }
      if (peakData.success) setPeakHours(peakData.data);

    } catch (err) {
      console.warn('Failed to fetch analytics:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      fetchAnalytics();
    }, [fetchAnalytics])
  );

  const maxRevenue = Math.max(...(revenueByDate.map(r => r.revenue) || [1]));
  const primaryPeakHour = peakHours.length > 0 ? peakHours[0].hour : 'N/A';

  if (loading && !overall) {
    return <Skeleton.AnalyticsScreen />;
  }

  return (
    <Screen
      scrollable
      refreshControl={<RefreshControl refreshing={loading} onRefresh={fetchAnalytics} tintColor={theme.colors.primary} />}
      contentStyle={{ paddingHorizontal: responsive.isTablet ? 32 : 24, paddingTop: 12 }}
    >
        <AppHeader
          eyebrow="BUSINESS INSIGHTS"
          title="Analytics"
          subtitle="Bookings and earnings combined for a single performance view."
        />

        {/* Stats Row */}
        <View style={styles.statsContainer}>
          <View style={styles.statBox}>
            <Ionicons name="calendar-outline" size={responsive.moderateScale(20)} color={theme.colors.primary} />
            <Text style={[styles.statValue, { fontSize: responsive.fp(22) }]}>{overall?.totalBookings.toString() || '0'}</Text>
            <Text style={[styles.statLabel, { fontSize: responsive.fp(11) }]}>BOOKINGS</Text>
          </View>
          <View style={styles.statDivider} />
          <TouchableOpacity 
            style={styles.statBox} 
            onPress={() => router.push('/earnings' as any)}
            activeOpacity={0.75}
          >
             <Ionicons name="wallet-outline" size={responsive.moderateScale(20)} color={theme.colors.primary} />
            <Text style={[styles.statValue, { fontSize: responsive.fp(22) }]} adjustsFontSizeToFit numberOfLines={1}>{overall?.totalRevenue.toLocaleString() || '0'}</Text>
            <Text style={[styles.statLabel, { fontSize: responsive.fp(11) }]}>EARNINGS</Text>
          </TouchableOpacity>
        </View>

        {/* Monthly Overview */}
        <View style={[styles.heroCard, {
          backgroundColor: theme.colors.surface,
          borderColor: theme.colors.cardBorder,
        }]}>
          <View style={styles.heroContent}>
            <View>
              <Text style={[styles.heroEyebrow, { fontSize: responsive.fp(12) }]}>ALL-TIME REVENUE</Text>
              <Text style={[styles.heroValue, { fontSize: responsive.fp(36) }]} numberOfLines={1} adjustsFontSizeToFit>
                ₹{overall?.totalRevenue.toLocaleString() || '0'}
              </Text>
            </View>
            <View style={[styles.heroIconWrapper, { backgroundColor: theme.colors.primarySoft }]}>
              <Ionicons name="podium-outline" size={responsive.moderateScale(24)} color={theme.colors.primary} />
            </View>
          </View>

          <View style={[styles.heroFooter, { borderTopColor: theme.colors.divider }]}>
            <View style={styles.heroNoteRow}>
              <Ionicons name="stats-chart-outline" size={responsive.moderateScale(16)} color={theme.colors.textMuted} />
              <Text style={[styles.heroNote, { fontSize: responsive.fp(13) }]}>
                Total cumulative revenue mapped from all your turf properties.
              </Text>
            </View>
          </View>
        </View>

        {/* Weekly Bar Chart */}
        <SectionCard style={styles.chartCard}>
          <Text style={[styles.sectionLabel, { fontSize: responsive.fp(10) }]}>REVENUE TREND (LAST {revenueByDate.length} DAYS)</Text>
          {revenueByDate.length > 0 ? (
            <View style={[styles.chartRow, { height: BAR_HEIGHT + 28 }]}>
              {revenueByDate.map((item, index) => {
                const percentage = Math.max(5, (item.revenue / (maxRevenue || 1)) * 100);
                const dayLabel = new Date(item.date).toLocaleDateString('en-US', { weekday: 'short' });
                return (
                  <View key={item.date + index} style={styles.barGroup}>
                    <View style={[styles.barTrack, { height: BAR_HEIGHT }]}>
                      <View style={[styles.barFill, { height: `${percentage}%` }]} />
                    </View>
                    <Text style={[styles.barLabel, { fontSize: responsive.fp(10) }]} numberOfLines={1}>{dayLabel}</Text>
                  </View>
                );
              })}
            </View>
          ) : (
            <View style={{ height: BAR_HEIGHT, justifyContent: 'center', alignItems: 'center' }}>
              <Text style={{ color: theme.colors.textMuted }}>No recent revenue data</Text>
            </View>
          )}
        </SectionCard>

        {/* Key Operations */}
        <SectionCard style={styles.chartCard}>
          <Text style={[styles.sectionLabel, { fontSize: responsive.fp(12) }]}>KEY OPERATIONS</Text>
          
          <View style={styles.metricRow}>
            <View style={styles.metricLabelRow}>
              <Ionicons name="trending-up-outline" size={responsive.moderateScale(14)} color={theme.colors.textMuted} />
              <Text style={[styles.metricLabel, { fontSize: responsive.fp(13) }]}>Peak booking hour</Text>
            </View>
            <Text style={[styles.metricValue, { fontSize: responsive.fp(13) }]}>{primaryPeakHour}</Text>
          </View>

          <View style={styles.metricRow}>
            <View style={styles.metricLabelRow}>
              <Ionicons name="close-circle-outline" size={responsive.moderateScale(14)} color={theme.colors.textMuted} />
              <Text style={[styles.metricLabel, { fontSize: responsive.fp(13) }]}>Cancellation rate</Text>
            </View>
            <Text style={[styles.metricValue, { fontSize: responsive.fp(13) }]}>{overall?.cancellationRate || '0%'}</Text>
          </View>

          <View style={[styles.metricRow, styles.metricRowLast]}>
            <View style={styles.metricLabelRow}>
              <Ionicons name="alert-circle-outline" size={responsive.moderateScale(14)} color={theme.colors.textMuted} />
              <Text style={[styles.metricLabel, { fontSize: responsive.fp(13) }]}>No-show rate</Text>
            </View>
            <Text style={[styles.metricValue, { fontSize: responsive.fp(13) }]}>{overall?.noShowRate || '0%'}</Text>
          </View>
        </SectionCard>
    </Screen>
  );
}
