import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect, useRouter } from 'expo-router';
import React, { useCallback, useState } from 'react';
import { ActivityIndicator, StyleSheet, Text, TouchableOpacity, View } from 'react-native';

import { AppHeader } from '@/src/components/common/AppHeader';
import { Screen } from '@/src/components/layout/Screen';
import { SectionCard } from '@/src/components/ui/SectionCard';
import { StatCard } from '@/src/components/ui/StatCard';
import { theme } from '@/src/constants/theme';
import { useAuthContext } from '@/src/context/AuthContext';
import { OwnerProfile as StorageProfile } from '@/src/types/profile';
import { STORAGE_KEYS } from '@/src/utils/constants';
import { useResponsive } from '@/src/utils/responsive';
import { getProfile } from '@/src/utils/storage';
import { useAppTheme } from '@/src/hooks/useAppTheme';

const menuSections = [
  {
    icon: 'person-outline' as const,
    label: 'Edit Profile',
    sub: 'Update your name, email and details',
    route: '/profile/edit',
  },
  {
    icon: 'wallet-outline' as const,
    label: 'Settlements & Payouts',
    sub: 'View revenue, settlements and configure bank details',
    route: '/earnings',
  },
  {
    icon: 'settings-outline' as const,
    label: 'Venue Settings',
    sub: 'Manage notifications and preferences',
    route: '/profile/settings',
  },
  {
    icon: 'help-circle-outline' as const,
    label: 'Support',
    sub: 'Get help or report an issue',
    route: '/profile/support',
  },
];

export default function ProfileScreen() {
  const router = useRouter();
  const responsive = useResponsive();
  const { theme } = useAppTheme();
  const styles = getStyles(theme);
  const { logout, user } = useAuthContext();
  const [profileData, setProfileData] = useState<StorageProfile | null>(null);
  const [ratingsData, setRatingsData] = useState<{ totalVenues: number; totalReviews: number; averageRating: number } | null>(null);
  const [loading, setLoading] = useState(true);

  useFocusEffect(
    useCallback(() => {
      const fetchData = async () => {
        setLoading(true);
        try {
          // Load live profile dynamically
          const p = await getProfile();
          if (p) setProfileData(p);

          // Fetch venues, ratings and reviews summary
          const token = await AsyncStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
          if (token) {
            const res = await fetch('https://turfsy.onrender.com/api/v3/owner-analytics/venues-ratings-summary', {
              headers: {
                'Authorization': `Bearer ${token}`,
                'Accept': 'application/json',
              }
            });
            const json = await res.json();
            if (json.success && json.data) {
              setRatingsData(json.data);
            }
          }
        } catch (e) {
          console.log('Profile fetch error', e);
        } finally {
          setLoading(false);
        }
      };

      fetchData();
    }, [])
  );

  const handleLogout = async () => {
    await logout();
    router.replace('/(auth)/welcome' as any);
  };

  const displayName = profileData?.ownerName || user?.name || 'Owner Name';
  const displayInitials = displayName
    .split(' ')
    .filter((n: string) => n.length > 0)
    .map((n: string) => n[0])
    .join('')
    .substring(0, 2)
    .toUpperCase() || 'OW';
  
  // Use turf names combined, backend handles multiple turfs in array
  const displayBusinessName = profileData?.turf?.name || user?.businessName || '';
  
  const ratingValue = ratingsData?.averageRating?.toFixed(1) || '0.0';
  const reviewsValue = ratingsData?.totalReviews?.toString() || '0';
  const venuesValue = ratingsData?.totalVenues || user?.venues?.length || 1;

  if (loading) {
    return (
      <Screen>
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <ActivityIndicator size="large" color={theme.colors.primary} />
          <Text style={{ marginTop: 12, color: theme.colors.textMuted, fontWeight: '700' }}>Loading Profile...</Text>
        </View>
      </Screen>
    );
  }

  return (
    <Screen 
      scrollable 
      contentStyle={{ paddingHorizontal: responsive.isTablet ? 32 : 24, paddingTop: 12, paddingBottom: 120 }}
    >
      <AppHeader eyebrow="OWNER ACCOUNT" title="Profile" action={{ icon: 'settings-outline', onPress: () => router.push('/profile/settings' as any) }} />

      {/* Profile Hero Card */}
      <SectionCard style={[styles.profileCard, { marginBottom: responsive.hp(14) }]}>
        <View style={[styles.profileRow, { gap: responsive.moderateScale(14), marginBottom: responsive.hp(14) }]}>
          <View style={[styles.avatar, { width: responsive.moderateScale(64), height: responsive.moderateScale(64), borderRadius: responsive.moderateScale(32) }]}>
            <Text style={[styles.avatarText, { fontSize: responsive.fp(24) }]}>{displayInitials}</Text>
          </View>
          <View style={styles.profileInfo}>
            <Text style={[styles.name, { fontSize: responsive.fp(20) }]}>{displayName}</Text>
            {displayBusinessName ? <Text style={[styles.subtitle, { fontSize: responsive.fp(13) }]}>Owner, {displayBusinessName}</Text> : null}
            <View style={styles.verifiedRow}>
              <Ionicons name="checkmark-circle" size={responsive.moderateScale(13)} color={theme.colors.primary} />
              <Text style={[styles.verifiedText, { fontSize: responsive.fp(11) }]}>Verified Owner</Text>
            </View>
          </View>
        </View>
        <TouchableOpacity
          style={[styles.editButton, { paddingVertical: responsive.hp(10), gap: responsive.moderateScale(6) }]}
          onPress={() => router.push('/profile/edit')}
          activeOpacity={0.8}
        >
          <Ionicons name="create-outline" size={responsive.moderateScale(14)} color={theme.colors.background} />
          <Text style={[styles.editButtonText, { fontSize: responsive.fp(12) }]}>Edit Profile</Text>
        </TouchableOpacity>
      </SectionCard>

      {/* Stats Row */}
      <View style={styles.statsContainer}>
        <View style={styles.statBox}>
          <Ionicons name="star" size={responsive.moderateScale(20)} color={theme.colors.primary} />
          <Text style={[styles.statValue, { fontSize: responsive.fp(22) }]}>{ratingValue}</Text>
          <Text style={[styles.statLabel, { fontSize: responsive.fp(11) }]}>RATING</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statBox}>
          <Ionicons name="chatbubbles" size={responsive.moderateScale(20)} color="#F59E0B" />
          <Text style={[styles.statValue, { fontSize: responsive.fp(22) }]}>{reviewsValue}</Text>
          <Text style={[styles.statLabel, { fontSize: responsive.fp(11) }]}>REVIEWS</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statBox}>
           <Ionicons name="business" size={responsive.moderateScale(20)} color={theme.colors.primary} />
          <Text style={[styles.statValue, { fontSize: responsive.fp(22) }]}>{venuesValue < 10 && venuesValue > 0 ? `0${venuesValue}` : String(venuesValue)}</Text>
          <Text style={[styles.statLabel, { fontSize: responsive.fp(11) }]}>VENUES</Text>
        </View>
      </View>

      <Text style={[styles.menuSectionLabel, { fontSize: responsive.fp(10), marginBottom: responsive.hp(10), marginLeft: responsive.wp(2) }]}>ACCOUNT</Text>
      {menuSections.map((item, index) => (
        <TouchableOpacity
          key={item.label}
          onPress={() => router.push(item.route as never)}
          activeOpacity={0.75}
        >
          <SectionCard style={[styles.menuCard, { minHeight: responsive.hp(56), gap: responsive.moderateScale(12) }, index < menuSections.length - 1 && { marginBottom: responsive.hp(10) }]}>
            <View style={[styles.menuIcon, { width: responsive.moderateScale(40), height: responsive.moderateScale(40), borderRadius: responsive.moderateScale(13) }]}>
              <Ionicons
                name={item.icon}
                size={responsive.moderateScale(18)}
                color={theme.colors.primary}
              />
            </View>
            <View style={styles.menuTextWrap}>
              <Text style={[styles.menuLabel, { fontSize: responsive.fp(14) }]}>{item.label}</Text>
              <Text style={[styles.menuSub, { fontSize: responsive.fp(11) }]}>{item.sub}</Text>
            </View>
            <Ionicons name="chevron-forward" size={responsive.moderateScale(16)} color={theme.colors.border} />
          </SectionCard>
        </TouchableOpacity>
      ))}

      {/* Logout Button */}
      <TouchableOpacity onPress={handleLogout} activeOpacity={0.75} style={{ marginTop: responsive.hp(24), paddingVertical: responsive.hp(12) }}>
        <SectionCard style={[styles.menuCard, { borderColor: 'rgba(255, 75, 75, 0.2)', minHeight: responsive.hp(56), gap: responsive.moderateScale(12) }]}>
          <View style={[styles.menuIcon, { width: responsive.moderateScale(40), height: responsive.moderateScale(40), borderRadius: responsive.moderateScale(13), backgroundColor: 'rgba(255, 75, 75, 0.1)', borderColor: 'rgba(255, 75, 75, 0.2)' }]}>
            <Ionicons name="log-out-outline" size={responsive.moderateScale(18)} color={theme.colors.danger} />
          </View>
          <View style={styles.menuTextWrap}>
            <Text style={[styles.menuLabel, { color: theme.colors.danger, fontSize: responsive.fp(14) }]}>Log Out</Text>
            <Text style={[styles.menuSub, { fontSize: responsive.fp(11) }]}>Sign out of your account</Text>
          </View>
        </SectionCard>
      </TouchableOpacity>
    </Screen>
  );
}

const getStyles = (theme: any) => StyleSheet.create({
  profileCard: {
    padding: 24,
    borderRadius: 24,
    backgroundColor: theme.colors.surfaceMuted,
    borderWidth: 1,
    borderColor: theme.colors.border,
  },
  profileRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatar: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: theme.colors.surface,
    borderWidth: 2,
    borderColor: theme.colors.primary,
    flexShrink: 0,
  },
  avatarText: {
    color: theme.colors.text,
    fontWeight: '900',
  },
  profileInfo: {
    flex: 1,
    minWidth: 0,
    gap: 3,
  },
  name: {
    color: theme.colors.text,
    fontWeight: '900',
  },
  subtitle: {
    color: theme.colors.textMuted,
  },
  verifiedRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 2,
  },
  verifiedText: {
    color: theme.colors.primary,
    fontWeight: '700',
  },
  editButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 16,
    backgroundColor: theme.colors.primary,
  },
  editButtonText: {
    color: theme.colors.background,
    fontWeight: '900',
    letterSpacing: 0.5,
  },
  statsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: theme.colors.surfaceMuted,
    borderRadius: 24,
    paddingVertical: 20,
    paddingHorizontal: 16,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: theme.colors.border,
  },
  statBox: {
    flex: 1,
    alignItems: 'center',
    gap: 4,
  },
  statDivider: {
    width: 1,
    height: '80%',
    backgroundColor: theme.colors.border,
    marginHorizontal: 8,
  },
  statValue: {
    color: theme.colors.text,
    fontWeight: '900',
    letterSpacing: -0.5,
  },
  statLabel: {
    color: theme.colors.textMuted,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
  menuSectionLabel: {
    color: theme.colors.textMuted,
    fontWeight: '800',
    letterSpacing: 1.5,
  },
  menuCard: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 20,
    padding: 16,
  },
  menuIcon: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: theme.colors.primarySoft,
    borderWidth: 1,
    borderColor: 'rgba(173,255,0,0.2)',
    flexShrink: 0,
  },
  menuTextWrap: {
    flex: 1,
    minWidth: 0,
    gap: 2,
  },
  menuLabel: {
    color: theme.colors.text,
    fontWeight: '700',
  },
  menuSub: {
    color: theme.colors.textMuted,
  },
});
