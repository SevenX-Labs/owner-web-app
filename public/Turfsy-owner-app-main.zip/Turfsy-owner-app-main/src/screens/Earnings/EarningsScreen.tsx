import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect, useRouter } from 'expo-router';
import React, { useCallback, useState } from 'react';
import { RefreshControl, StyleSheet, Text, TouchableOpacity, View, FlatList } from 'react-native';

import { AppHeader } from '@/src/components/common/AppHeader';
import { Screen } from '@/src/components/layout/Screen';
import { SectionCard } from '@/src/components/ui/SectionCard';
import { STORAGE_KEYS } from '@/src/utils/constants';
import { useResponsive } from '@/src/utils/responsive';
import { useAppTheme } from '@/src/hooks/useAppTheme';

interface BankDetails {
  bankHolderName: string;
  bankName: string;
  accountNumber: string;
  ifscCode: string;
  accountType: string;
}

interface SettlementSummary {
  totalRevenue: number;
  totalOwed: number;
  totalSettled: number;
  pendingSettlements: number;
  bankDetails: BankDetails | null;
}

interface SettlementHistory {
  id: string;
  amount: number;
  status: 'PENDING' | 'PAID' | 'COMPLETED';
  txRef: string;
  notes: string;
  bookingCount: number;
  period: string;
  paidAt: string;
  createdAt: string;
}

export default function EarningsScreen() {
  const responsive = useResponsive();
  const { theme } = useAppTheme();
  const router = useRouter();
  
  const [loading, setLoading] = useState(true);
  const [summary, setSummary] = useState<SettlementSummary | null>(null);
  const [history, setHistory] = useState<SettlementHistory[]>([]);

  const fetchSettlements = useCallback(async () => {
    try {
      setLoading(true);
      const token = await AsyncStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
      if (!token) return;

      const headers = {
        'Authorization': `Bearer ${token}`,
        'Accept': 'application/json',
      };

      const [summaryRes, historyRes] = await Promise.all([
        fetch('https://turfsy.onrender.com/api/v3/owner-settlements/summary', { headers }),
        fetch('https://turfsy.onrender.com/api/v3/owner-settlements/history', { headers })
      ]);

      const summaryData = await summaryRes.json();
      const historyData = await historyRes.json();

      if (summaryData.success) {
        setSummary(summaryData.data);
      }
      if (historyData.success) {
        setHistory(historyData.data);
      }
    } catch (err) {
      console.warn('Failed to fetch settlements:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      fetchSettlements();
    }, [fetchSettlements])
  );

  const renderHistoryItem = ({ item }: { item: SettlementHistory }) => {
    const isCompleted = item.status === 'COMPLETED' || item.status === 'PAID';
    const dateStr = new Date(item.createdAt).toLocaleDateString('en-IN', {
      day: 'numeric', month: 'short', year: 'numeric'
    });

    return (
      <View style={[styles.historyItem, { borderBottomColor: theme.colors.divider }]}>
        <View style={styles.historyRow}>
          <View style={styles.historyLeft}>
            <Text style={[styles.historyAmount, { color: theme.colors.text, fontSize: responsive.fp(16) }]}>
              ₹{item.amount.toLocaleString()}
            </Text>
            <Text style={[styles.historyDate, { color: theme.colors.textMuted, fontSize: responsive.fp(12) }]}>
              {dateStr}
            </Text>
          </View>
          <View style={styles.historyRight}>
            <View style={[
              styles.statusPill, 
              { backgroundColor: isCompleted ? 'rgba(16, 185, 129, 0.1)' : 'rgba(245, 158, 11, 0.1)' }
            ]}>
              <Text style={[
                styles.statusText, 
                { color: isCompleted ? '#10B981' : '#F59E0B', fontSize: responsive.fp(10) }
              ]}>
                {item.status}
              </Text>
            </View>
          </View>
        </View>
        {item.txRef ? (
          <Text style={[styles.txRef, { color: theme.colors.textSecondary, fontSize: responsive.fp(11) }]}>
            Ref: {item.txRef}
          </Text>
        ) : null}
      </View>
    );
  };

  return (
    <Screen
      scrollable={false}
      contentStyle={{ paddingHorizontal: responsive.isTablet ? 32 : 24, paddingTop: 12 }}
    >
      <AppHeader
        eyebrow="FINANCIALS"
        title="Settlements"
        subtitle="Track your revenue, pending payouts, and bank details."
        action={{ icon: 'settings-outline', onPress: () => router.push('/profile/payout-setup' as any) }}
      />

      <FlatList
        data={history}
        keyExtractor={(item) => item.id}
        renderItem={renderHistoryItem}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={fetchSettlements} tintColor={theme.colors.primary} />}
        contentContainerStyle={{ paddingBottom: responsive.hp(120) }}
        ListHeaderComponent={
          <>
            <View style={styles.cardsGrid}>
              <View style={[styles.metricCard, { backgroundColor: theme.colors.surfaceMuted, borderColor: theme.colors.border }]}>
                <Text style={[styles.metricLabel, { color: theme.colors.textMuted, fontSize: responsive.fp(11) }]}>All-Time Revenue</Text>
                <Text style={[styles.metricValue, { color: theme.colors.text, fontSize: responsive.fp(22) }]}>
                  ₹{summary?.totalRevenue.toLocaleString() || '0'}
                </Text>
              </View>
              
              <View style={[styles.metricCard, { backgroundColor: theme.colors.surfaceMuted, borderColor: theme.colors.border }]}>
                <Text style={[styles.metricLabel, { color: theme.colors.textMuted, fontSize: responsive.fp(11) }]}>Total Settled</Text>
                <Text style={[styles.metricValue, { color: theme.colors.text, fontSize: responsive.fp(22) }]}>
                  ₹{summary?.totalSettled.toLocaleString() || '0'}
                </Text>
              </View>
            </View>

            <View style={[styles.pendingCard, { backgroundColor: theme.colors.primarySoft, borderColor: 'rgba(16, 185, 129, 0.2)' }]}>
              <View>
                <Text style={[styles.metricLabel, { color: theme.colors.primary, fontSize: responsive.fp(11), fontWeight: '800' }]}>Pending Settlement</Text>
                <Text style={[styles.metricValue, { color: theme.colors.text, fontSize: responsive.fp(28) }]}>
                  ₹{summary?.pendingSettlements.toLocaleString() || '0'}
                </Text>
              </View>
              <Ionicons name="time-outline" size={responsive.moderateScale(32)} color={theme.colors.primary} />
            </View>

            <SectionCard style={styles.bankCard}>
              <View style={styles.bankHeader}>
                <Text style={[styles.sectionLabel, { color: theme.colors.textMuted, fontSize: responsive.fp(12) }]}>PAYOUT METHOD</Text>
                <TouchableOpacity onPress={() => router.push('/profile/payout-setup' as any)}>
                  <Text style={[styles.editLink, { color: theme.colors.primary, fontSize: responsive.fp(12) }]}>Edit</Text>
                </TouchableOpacity>
              </View>
              
              {summary?.bankDetails ? (
                <View style={styles.bankInfo}>
                  <Ionicons 
                    name="business-outline"
                    size={responsive.moderateScale(24)} 
                    color={theme.colors.text} 
                  />
                  <View style={styles.bankDetailsText}>
                    <Text style={[styles.bankName, { color: theme.colors.text, fontSize: responsive.fp(15) }]}>
                      {summary.bankDetails.bankName}
                    </Text>
                    <Text style={[styles.bankAcc, { color: theme.colors.textSecondary, fontSize: responsive.fp(13) }]}>
                      •••• {summary.bankDetails.accountNumber.slice(-4)}
                    </Text>
                  </View>
                </View>
              ) : (
                <Text style={{ color: theme.colors.textSecondary, marginTop: 8 }}>No payout method configured.</Text>
              )}
            </SectionCard>

            <Text style={[styles.sectionTitle, { color: theme.colors.text, fontSize: responsive.fp(16) }]}>Settlement History</Text>
          </>
        }
        ListEmptyComponent={
          !loading ? (
            <View style={styles.emptyState}>
              <Ionicons name="receipt-outline" size={responsive.moderateScale(48)} color={theme.colors.textMuted} />
              <Text style={[styles.emptyText, { color: theme.colors.textMuted, fontSize: responsive.fp(14) }]}>No settlements found</Text>
            </View>
          ) : null
        }
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  cardsGrid: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 12,
  },
  metricCard: {
    flex: 1,
    padding: 16,
    borderRadius: 20,
    borderWidth: 1,
  },
  pendingCard: {
    padding: 20,
    borderRadius: 20,
    borderWidth: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  metricLabel: {
    fontWeight: '700',
    letterSpacing: 0.5,
    marginBottom: 4,
    textTransform: 'uppercase',
  },
  metricValue: {
    fontWeight: '900',
    letterSpacing: -0.5,
  },
  bankCard: {
    padding: 20,
    borderRadius: 20,
    marginBottom: 24,
  },
  bankHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionLabel: {
    fontWeight: '800',
    letterSpacing: 1.5,
  },
  editLink: {
    fontWeight: '700',
  },
  bankInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  bankDetailsText: {
    flex: 1,
  },
  bankName: {
    fontWeight: '700',
  },
  bankAcc: {
    marginTop: 2,
  },
  sectionTitle: {
    fontWeight: '800',
    marginBottom: 16,
    marginTop: 8,
  },
  historyItem: {
    paddingVertical: 16,
    borderBottomWidth: 1,
  },
  historyRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  historyLeft: {
    gap: 4,
  },
  historyRight: {
    alignItems: 'flex-end',
  },
  historyAmount: {
    fontWeight: '800',
  },
  historyDate: {
    fontWeight: '600',
  },
  statusPill: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  statusText: {
    fontWeight: '800',
  },
  txRef: {
    marginTop: 8,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 40,
    gap: 12,
  },
  emptyText: {
    fontWeight: '600',
  },
});
