import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect } from 'expo-router';
import React, { useCallback, useState } from 'react';
import { ActivityIndicator, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { AppHeader } from '@/src/components/common/AppHeader';
import { Screen } from '@/src/components/layout/Screen';
import { CreateTurfModal } from '@/src/components/turf/CreateTurfModal';
import { SectionCard } from '@/src/components/ui/SectionCard';
import { STORAGE_KEYS } from '@/src/utils/constants';
import { useResponsive } from '@/src/utils/responsive';
import { useAppTheme } from '@/src/hooks/useAppTheme';
import { useAuthContext } from '@/src/context/AuthContext';

export default function TurfScreen() {
  const responsive = useResponsive();
  const { theme } = useAppTheme();
  const styles = getStyles(theme);
  
  const STATUS_COLORS: Record<string, string> = {
    ACTIVE: '#22C55E',
    INACTIVE: theme.colors.textMuted,
    MAINTENANCE: '#F59E0B',
    active: '#22C55E',
    inactive: theme.colors.textMuted,
    maintenance: '#F59E0B',
  };

  function getStyles(theme: any) {
    return StyleSheet.create({
      turfCard: {
        marginBottom: 16,
        padding: 20,
        backgroundColor: theme.colors.surfaceMuted,
        borderRadius: 24,
        borderWidth: 1,
        borderColor: theme.colors.border,
      },
      turfTopRow: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: 12,
        marginBottom: 16,
      },
      turfTitleWrap: {
        flex: 1,
        minWidth: 0,
        gap: 4,
      },
      turfName: {
        color: theme.colors.text,
        fontWeight: '900',
        letterSpacing: 0.5,
      },
      turfSubRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 4,
        marginTop: 2,
      },
      turfLocation: {
        color: theme.colors.textMuted,
        flex: 1,
        fontWeight: '600',
      },
      editButton: {
        width: 44,
        height: 44,
        borderRadius: 16,
        borderWidth: 1,
        borderColor: 'rgba(173,255,0,0.2)',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: theme.colors.primarySoft,
        flexShrink: 0,
      },
      divider: {
        height: 1,
        backgroundColor: theme.colors.border,
        marginBottom: 16,
      },
      turfMetricsRow: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
      },
      metricPill: {
        flex: 1,
        alignItems: 'center',
        gap: 4,
      },
      metricDivider: {
        width: 1,
        height: 32,
        backgroundColor: theme.colors.border,
      },
      metricLabel: {
        color: theme.colors.textMuted,
        fontWeight: '700',
        letterSpacing: 0.5,
      },
      metricValue: {
        color: theme.colors.text,
        fontWeight: '800',
      },
      statusRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 6,
        marginTop: 2,
        paddingHorizontal: 8,
        paddingVertical: 4,
        backgroundColor: theme.colors.surface,
        borderRadius: 12,
      },
      statusDot: {
        width: 8,
        height: 8,
        borderRadius: 4,
      },
      statusValue: {
        fontWeight: '800',
        letterSpacing: 0.5,
      },
      addButton: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        gap: 12,
        borderRadius: 20,
        backgroundColor: theme.colors.surfaceMuted,
        paddingVertical: 18,
        marginTop: 12,
        borderWidth: 1,
        borderColor: theme.colors.border,
        borderStyle: 'dashed',
      },
      addIconWrap: {
        width: 36,
        height: 36,
        borderRadius: 18,
        backgroundColor: theme.colors.primarySoft,
        alignItems: 'center',
        justifyContent: 'center',
      },
      addButtonText: {
        color: theme.colors.text,
        fontWeight: '800',
        letterSpacing: 0.5,
      },
      modalBackdrop: {
        flex: 1,
        backgroundColor: 'rgba(0,0,0,0.7)',
        justifyContent: 'flex-end',
      },
      modalCard: {
        borderTopLeftRadius: 28,
        borderTopRightRadius: 28,
        backgroundColor: theme.colors.surface,
        borderTopWidth: 1,
        borderColor: theme.colors.border,
        padding: 20,
        paddingBottom: 40,
        maxHeight: '85%',
      },
      modalHandle: {
        width: 36,
        height: 4,
        backgroundColor: theme.colors.border,
        borderRadius: 2,
        alignSelf: 'center',
        marginBottom: 18,
      },
      modalTitle: {
        color: theme.colors.text,
        fontWeight: '800',
        marginBottom: 18,
      },
      inputGroup: {
        marginBottom: 14,
      },
      inputRow: {
        flexDirection: 'row',
        gap: 12,
        marginBottom: 0,
      },
      inputLabel: {
        color: theme.colors.textMuted,
        fontWeight: '700',
        letterSpacing: 1,
        marginBottom: 6,
      },
      input: {
        borderRadius: 14,
        borderWidth: 1,
        borderColor: theme.colors.border,
        backgroundColor: theme.colors.background,
        color: theme.colors.text,
        paddingHorizontal: 14,
        paddingVertical: 14,
      },
      saveButton: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
        borderRadius: 14,
        backgroundColor: theme.colors.primary,
        paddingVertical: 15,
        marginTop: 18,
      },
      saveButtonText: {
        color: '#000000',
        fontWeight: '900',
      },
    });
  }
  
  const insets = useSafeAreaInsets();
  const { token } = useAuthContext();
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedTurf, setSelectedTurf] = useState<any>(null);
  const [isViewOnly, setIsViewOnly] = useState(false);
  const [turfs, setTurfs] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchTurfs = useCallback(async () => {
    try {
      setLoading(true);
      const authToken = token || await AsyncStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
      if (!authToken) return;

      const response = await fetch('https://turfsy.onrender.com/api/v3/turfs/my', {
        headers: {
          'Authorization': `Bearer ${authToken}`,
          'Accept': 'application/json',
        }
      });
      const data = await response.json();
      
      if (data.success && Array.isArray(data.data)) {
        setTurfs(data.data);
      } else if (Array.isArray(data)) {
        setTurfs(data);
      }
    } catch (err) {
      console.warn("Failed to fetch turfs:", err);
    } finally {
      setLoading(false);
    }
  }, [token]);

  useFocusEffect(
    useCallback(() => {
      fetchTurfs();
    }, [fetchTurfs])
  );

  return (
    <Screen 
      scrollable 
      contentStyle={{ paddingHorizontal: responsive.isTablet ? 32 : 24, paddingTop: 12, paddingBottom: 120 }}
    >
      <AppHeader
        eyebrow="VENUE OPERATIONS"
        title="Turf"
        subtitle="View and manage your active turfs."
        action={{ icon: 'add', onPress: () => {
          setSelectedTurf(null);
          setIsViewOnly(false);
          setShowCreateModal(true);
        }}}
      />

      {loading ? (
        <ActivityIndicator size="large" color={theme.colors.primary} style={{ marginTop: 40 }} />
      ) : turfs.length === 0 ? (
        <View style={{ padding: 20, alignItems: 'center' }}>
          <Text style={{ color: theme.colors.textMuted, textAlign: 'center', marginBottom: 20 }}>No turfs found. Add your first turf to get started!</Text>
        </View>
      ) : (
        <View style={{ flex: 1 }}>
          {turfs.map((turf: any) => {
            const statusColor = STATUS_COLORS[turf.status] ?? theme.colors.textMuted;
            
            return (
              <SectionCard key={turf.id} style={styles.turfCard}>
                {/* Header Row */}
            <View style={styles.turfTopRow}>
              <View style={styles.turfTitleWrap}>
                <Text
                  style={[styles.turfName, { fontSize: responsive.fp(15) }]}
                  numberOfLines={1}
                >
                  {turf.name}
                </Text>
                <View style={styles.turfSubRow}>
                  <Ionicons name="location-outline" size={responsive.moderateScale(11)} color={theme.colors.textMuted} />
                  <Text
                    style={[styles.turfLocation, { fontSize: responsive.fp(12) }]}
                    numberOfLines={1}
                  >
                    {turf.city || turf.location} · {turf.sportsType || turf.sport}
                  </Text>
                </View>
              </View>
              <TouchableOpacity
                style={styles.editButton}
                onPress={() => {
                  setSelectedTurf(turf);
                  setIsViewOnly(false);
                  setShowCreateModal(true);
                }}
                activeOpacity={0.75}
              >
                <Ionicons name="create-outline" size={responsive.moderateScale(16)} color={theme.colors.primary} />
              </TouchableOpacity>
            </View>

            {/* Divider */}
            <View style={styles.divider} />

            {/* Metrics Row */}
            <View style={styles.turfMetricsRow}>
              <View style={styles.metricPill}>
                <Text style={[styles.metricLabel, { fontSize: responsive.fp(10) }]}>DAY (WK)</Text>
                <Text style={[styles.metricValue, { fontSize: responsive.fp(13) }]}>
                  ₹ {turf.weekdayDayPrice}/hr
                </Text>
              </View>
              <View style={styles.metricDivider} />
              <View style={styles.metricPill}>
                <Text style={[styles.metricLabel, { fontSize: responsive.fp(10) }]}>NIGHT (WK)</Text>
                <Text style={[styles.metricValue, { fontSize: responsive.fp(13) }]}>
                   ₹ {turf.weekdayNightPrice}/hr
                </Text>
              </View>
              <View style={styles.metricDivider} />
              <View style={styles.metricPill}>
                <Text style={[styles.metricLabel, { fontSize: responsive.fp(10) }]}>STATUS</Text>
                <View style={styles.statusRow}>
                  <View style={[styles.statusDot, { backgroundColor: statusColor }]} />
                  <Text style={[styles.statusValue, { fontSize: responsive.fp(12), color: statusColor }]}>
                    {turf.status ? (turf.status.charAt(0).toUpperCase() + turf.status.slice(1).toLowerCase()) : 'Unknown'}
                  </Text>
                </View>
              </View>
            </View>

            {/* View Details Action */}
            <View style={[styles.divider, { marginTop: 16, marginBottom: 12 }]} />
            <TouchableOpacity 
              style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 4 }}
              activeOpacity={0.7}
              onPress={() => {
                setSelectedTurf(turf);
                setIsViewOnly(true);
                setShowCreateModal(true);
              }}
            >
              <Ionicons name="eye-outline" size={responsive.moderateScale(16)} color={theme.colors.primary} />
              <Text style={{ color: theme.colors.primary, fontWeight: '800', fontSize: responsive.fp(13) }}>View Full Details</Text>
            </TouchableOpacity>

          </SectionCard>
        );
      })}
        </View>
      )}
      
      {/* Add Turf Button */}
      <TouchableOpacity style={styles.addButton} onPress={() => {
        setSelectedTurf(null);
        setIsViewOnly(false);
        setShowCreateModal(true);
      }} activeOpacity={0.85}>
        <View style={styles.addIconWrap}>
          <Ionicons name="add" size={responsive.moderateScale(20)} color={theme.colors.primary} />
        </View>
        <Text style={[styles.addButtonText, { fontSize: responsive.fp(15) }]}>Add New Turf</Text>
      </TouchableOpacity>

      <CreateTurfModal 
        visible={showCreateModal}
        initialData={selectedTurf}
        isViewOnly={isViewOnly}
        onClose={() => {
          setShowCreateModal(false);
          setSelectedTurf(null);
          setIsViewOnly(false);
        }}
        onSuccess={() => {
          setShowCreateModal(false);
          setSelectedTurf(null);
          setIsViewOnly(false);
          fetchTurfs();
        }}
      />
    </Screen>
  );
}



