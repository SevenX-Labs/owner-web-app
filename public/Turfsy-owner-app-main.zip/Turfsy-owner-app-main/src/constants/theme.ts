export const theme = {
  colors: {
    background: '#0C0D10',
    surface: '#181B20',
    surfaceMuted: '#121417',
    surfaceElevated: '#20242A',
    border: '#2A2F37',
    divider: '#22262D',
    primary: '#B8FF17',
    primaryHover: '#A5EA15',
    primaryPressed: '#90D113',
    primarySoft: 'rgba(184, 255, 23, 0.10)',
    text: '#FFFFFF',
    textSecondary: '#B2B7C2',
    textMuted: '#7D8592',
    danger: '#FF5D5D',
    dangerSoft: 'rgba(255, 93, 93, 0.12)',
    success: '#2ED573',
    warning: '#FFC857',
    info: '#4DA3FF',
    chart: ['#B8FF17', '#2ED573', '#4DA3FF'],
  },
  radius: {
    sm: 12,
    md: 18,
    lg: 24,
    xl: 30,
    pill: 999,
  },
} as const;

export type AppTheme = typeof theme;
