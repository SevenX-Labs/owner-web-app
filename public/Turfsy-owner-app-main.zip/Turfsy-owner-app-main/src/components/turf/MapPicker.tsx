import React, { useRef, useEffect, useCallback } from 'react';
import { View, StyleSheet, Platform, ActivityIndicator } from 'react-native';
import { WebView } from 'react-native-webview';

interface MarkerProps {
  coordinate: {
    latitude: number;
    longitude: number;
  };
  draggable?: boolean;
  onDragEnd?: (e: any) => void;
}

// Dummy Marker component to keep compatibility with existing usage if needed, 
// though the WebView handles the marker internally.
export const Marker: React.FC<MarkerProps> = () => null;

interface MapViewProps {
  style?: any;
  region: {
    latitude: number;
    longitude: number;
    latitudeDelta: number;
    longitudeDelta: number;
  };
  onPress?: (e: any) => void;
  children?: React.ReactNode;
}

export const MapView: React.FC<MapViewProps> = ({ style, region, onPress }) => {
  const webViewRef = useRef<WebView>(null);

  // Leaflet + OpenStreetMap HTML
  const mapHtml = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes" />
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
        <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
        <style>
          body { margin: 0; padding: 0; }
          #map { height: 100vh; width: 100vw; }
          .leaflet-control-attribution { display: none; }
          
          /* Custom Search Controls */
          .search-container {
            position: absolute;
            top: 10px;
            left: 50px;
            right: 10px;
            z-index: 1000;
            display: flex;
            gap: 5px;
          }
          input {
            flex: 1;
            padding: 10px;
            border-radius: 8px;
            border: 1px solid #ccc;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            font-size: 14px;
          }
          button {
            padding: 10px;
            background: #ADFF00;
            border: none;
            border-radius: 8px;
            color: #000;
            font-weight: bold;
            cursor: pointer;
          }
          .locate-btn {
            position: absolute;
            bottom: 20px;
            right: 20px;
            z-index: 1000;
            width: 44px;
            height: 44px;
            background: white;
            border-radius: 22px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 6px rgba(0,0,0,0.3);
          }
        </style>
      </head>
      <body>
        <div class="search-container">
          <input type="text" id="search-input" placeholder="Search address..." />
          <button onclick="searchLocation()">Search</button>
        </div>
        <div id="map"></div>
        <div class="locate-btn" onclick="locateUser()">
           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#333" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><circle cx="12" cy="12" r="3"></circle><line x1="12" y1="2" x2="12" y2="5"></line><line x1="12" y1="19" x2="12" y2="22"></line><line x1="2" y1="12" x2="5" y2="12"></line><line x1="19" y1="12" x2="22" y2="12"></line></svg>
        </div>

        <script>
          var map = L.map('map', { zoomControl: true }).setView([${region.latitude}, ${region.longitude}], 13);
          L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
          }).addTo(map);

          var marker = L.marker([${region.latitude}, ${region.longitude}], { draggable: true }).addTo(map);

          marker.on('dragend', function(event) {
            var position = marker.getLatLng();
            window.ReactNativeWebView.postMessage(JSON.stringify({
              type: 'ON_DRAG_END',
              latitude: position.lat,
              longitude: position.lng
            }));
          });

          map.on('click', function(e) {
            marker.setLatLng(e.latlng);
            window.ReactNativeWebView.postMessage(JSON.stringify({
              type: 'ON_PRESS',
              latitude: e.latlng.lat,
              longitude: e.latlng.lng
            }));
          });

          function searchLocation() {
            var query = document.getElementById('search-input').value;
            if(!query) return;
            fetch('https://nominatim.openstreetmap.org/search?format=json&q=' + encodeURIComponent(query))
              .then(res => res.json())
              .then(data => {
                if(data.length > 0) {
                  var res = data[0];
                  var lat = parseFloat(res.lat);
                  var lon = parseFloat(res.lon);
                  map.setView([lat, lon], 16);
                  marker.setLatLng([lat, lon]);
                  window.ReactNativeWebView.postMessage(JSON.stringify({
                    type: 'ON_PRESS',
                    latitude: lat,
                    longitude: lon
                  }));
                }
              });
          }

          function locateUser() {
            window.ReactNativeWebView.postMessage(JSON.stringify({ type: 'GET_LOCATION' }));
          }

          window.addEventListener('message', function(event) {
            var data = JSON.parse(event.data);
            if(data.type === 'SET_LOCATION') {
               map.setView([data.lat, data.lng], 16);
               marker.setLatLng([data.lat, data.lng]);
            }
          });
        </script>
      </body>
    </html>
  `;

  const onMessage = (event: any) => {
    try {
      const data = JSON.parse(event.nativeEvent.data);
      if (data.type === 'ON_DRAG_END' || data.type === 'ON_PRESS') {
        if (onPress) {
          onPress({
            nativeEvent: {
              coordinate: {
                latitude: data.latitude,
                longitude: data.longitude,
              },
            },
          });
        }
      } else if (data.type === 'GET_LOCATION') {
        // We handle this via the parent component usually, 
        // but can trigger a refresh if needed.
      }
    } catch (e) {
      console.error('Map message error:', e);
    }
  };

  return (
    <View style={[styles.container, style]}>
      <WebView
        ref={webViewRef}
        originWhitelist={['*']}
        source={{ html: mapHtml }}
        onMessage={onMessage}
        style={styles.map}
        javaScriptEnabled={true}
        domStorageEnabled={true}
        nestedScrollEnabled={true}
        startInLoadingState={true}
        renderLoading={() => <ActivityIndicator style={StyleSheet.absoluteFill} color="#ADFF00" />}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    overflow: 'hidden',
  },
  map: {
    flex: 1,
  },
});

export default MapView;