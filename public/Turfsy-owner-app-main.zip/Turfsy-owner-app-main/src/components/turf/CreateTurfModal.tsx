import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as ImagePicker from 'expo-image-picker';
import * as Location from 'expo-location';
import * as FileSystem from 'expo-file-system/legacy';
import React, { useState } from 'react';
import {
  ActivityIndicator,
  Image,
  KeyboardAvoidingView,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Switch,
} from 'react-native';
import { showAlert, showSuccess, showError, showWarning } from '../ui/CustomAlert';

import { MapView, Marker } from './MapPicker';

import InputField from '../../../components/profile/InputField';
import { STORAGE_KEYS } from '../../utils/constants';
import { fp, hp, wp } from '../../utils/responsive';
import { VideoPreview } from './VideoPreview';
import { useAppTheme } from '../../hooks/useAppTheme';


const AMENITIES = [
  'floodLights', 'parking', 'washroom', 'changingRoom', 'drinkingWater', 'seatingArea', 'cafeteria'
];
const AMENITY_LABELS: Record<string, string> = {
  floodLights: 'Flood Lights',
  parking: 'Parking',
  washroom: 'Washroom',
  changingRoom: 'Changing Room',
  drinkingWater: 'Drinking Water',
  seatingArea: 'Seating Area',
  cafeteria: 'Cafeteria'
};

const AMENITY_ICONS: Record<string, keyof typeof Ionicons.glyphMap> = {
  floodLights: 'flashlight-outline',
  parking: 'car-outline',
  washroom: 'water-outline',
  changingRoom: 'shirt-outline',
  drinkingWater: 'cafe-outline',
  seatingArea: 'people-outline',
  cafeteria: 'restaurant-outline'
};

function getStyles(theme: any) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: theme.colors.background },
    header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 24, borderBottomWidth: 1, borderColor: theme.colors.border, paddingTop: Platform.OS === 'ios' ? 60 : 30 },
    headerTitle: { color: theme.colors.text, fontSize: fp(20), fontWeight: '900', letterSpacing: 0.5 },
    iconBtn: { padding: 4 },
    scroll: { padding: 24 },
    section: { gap: hp(18), marginBottom: hp(8) },
    row: { flexDirection: 'row', gap: wp(12) },
    sectionHeader: { flexDirection: 'row', alignItems: 'center', gap: wp(10) },
    sectionLine: { flex: 1, height: 1 },
    sectionTitle: { fontSize: fp(11), fontWeight: '900', letterSpacing: 2 },
    amenitiesGrid: {
      flexDirection: 'row',
      flexWrap: 'wrap',
      gap: 10,
      marginBottom: hp(16),
    },
    amenityChip: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 6,
      paddingHorizontal: 16,
      paddingVertical: 12,
      borderRadius: 24,
      backgroundColor: theme.colors.surfaceMuted,
      borderWidth: 1,
      borderColor: theme.colors.border,
    },
    amenityChipActive: {
      backgroundColor: theme.colors.primary,
      borderColor: theme.colors.primary,
    },
    amenityChipText: {
      color: theme.colors.text,
      fontWeight: '700',
      fontSize: fp(13),
    },
    amenityChipTextActive: {
      color: theme.colors.background,
    },
    imageUploadBox: { height: hp(120), backgroundColor: theme.colors.surfaceMuted, borderRadius: 16, alignItems: 'center', justifyContent: 'center', borderWidth: 1.5, borderColor: 'rgba(173,255,0,0.2)', borderStyle: 'dashed', marginBottom: 12, overflow: 'hidden' },
    uploadText: { color: theme.colors.textMuted, fontSize: fp(13), marginTop: 8, fontWeight: '700' },
    uploadedImage: { width: '100%', height: '100%', resizeMode: 'cover' },
    submitBtn: { backgroundColor: theme.colors.primary, padding: 16, borderRadius: 24, alignItems: 'center', marginTop: 24, paddingVertical: 18, shadowColor: theme.colors.primary, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.2, shadowRadius: 8, elevation: 6 },
    submitBtnText: { color: theme.colors.background, fontSize: fp(17), fontWeight: '900', letterSpacing: 0.5 },
    inputLabel: { color: theme.colors.textMuted, fontSize: fp(11), fontWeight: '800', letterSpacing: 1.5, marginTop: 4 },
    mapContainer: { height: 200, width: '100%', borderRadius: 16, overflow: 'hidden', borderWidth: 1, borderColor: theme.colors.border, marginTop: -4 },
    map: { flex: 1 },
    webMapFallback: { flex: 1, backgroundColor: theme.colors.surfaceMuted, alignItems: 'center', justifyContent: 'center' },
    videoOverlayLabel: {
      position: 'absolute',
      bottom: 0,
      backgroundColor: 'rgba(0,0,0,0.7)',
      width: '100%',
      paddingVertical: 14,
      flexDirection: 'row',
      justifyContent: 'center',
      alignItems: 'center',
    }
  });
}

const SectionHeader = ({ title, theme, styles }: { title: string, theme: any, styles: any }) => (
  <View style={[styles.sectionHeader, { marginVertical: hp(24) }]}>
    <View style={[styles.sectionLine, { backgroundColor: theme.colors.border }]} />
    <Text style={[styles.sectionTitle, { color: theme.colors.primary }]}>{title}</Text>
    <View style={[styles.sectionLine, { backgroundColor: theme.colors.border }]} />
  </View>
);


export const CreateTurfModal = ({ visible, onClose, onSuccess, initialData, isViewOnly }: { visible: boolean, onClose: () => void, onSuccess: () => void, initialData?: any, isViewOnly?: boolean }) => {
  const { theme } = useAppTheme();
  const styles = getStyles(theme);
  
  const [form, setForm] = useState<any>({
    name: '',
    description: '',
    sportsType: '',
    turfSize: '',
    address: '',
    city: '',
    pincode: '',
    lat: 19.0760,
    lng: 72.8777,
    openTime: '06:00',
    closeTime: '23:00',
    minSlotDurationMins: '60',
    weekdayDayPrice: '',
    weekdayNightPrice: '',
    weekendDayPrice: '',
    weekendNightPrice: '',
    floodLights: false,
    parking: false,
    washroom: false,
    changingRoom: false,
    drinkingWater: false,
    seatingArea: false,
    cafeteria: false,
    bookingApprovalType: 'INSTANT',
    paymentPreferences: ['FULL_ONLINE', 'ADVANCE_PAYMENT', 'FULL_CASH'],
  });

  const [images, setImages] = useState<any>({
    entrance: null,
    dayTurf: null,
    nightTurf: null,
  });
  const [video, setVideo] = useState<any>(null);

  const [loading, setLoading] = useState(false);
  const [detectingLocation, setDetectingLocation] = useState(false);
  const [errors, setErrors] = useState<any>({});
  const [scrollEnabled, setScrollEnabled] = useState(true);

  React.useEffect(() => {
    if (visible) {
      if (initialData) {
        setForm({
          name: initialData.name || '',
          description: initialData.description || '',
          sportsType: initialData.sportsType || initialData.sport || '',
          turfSize: initialData.turfSize || '',
          address: initialData.address || initialData.location || '',
          city: initialData.city || '',
          pincode: initialData.pincode || '',
          lat: initialData.lat !== undefined ? Number(initialData.lat) : 19.0760,
          lng: initialData.lng !== undefined ? Number(initialData.lng) : 72.8777,
          openTime: initialData.openTime || '06:00',
          closeTime: initialData.closeTime || '23:00',
          minSlotDurationMins: String(initialData.minSlotDurationMins || 60),
          weekdayDayPrice: String(initialData.weekdayDayPrice || ''),
          weekdayNightPrice: String(initialData.weekdayNightPrice || ''),
          weekendDayPrice: String(initialData.weekendDayPrice || ''),
          weekendNightPrice: String(initialData.weekendNightPrice || ''),
          floodLights: !!initialData.floodLights,
          parking: !!initialData.parking,
          washroom: !!initialData.washroom,
          changingRoom: !!initialData.changingRoom,
          drinkingWater: !!initialData.drinkingWater,
          seatingArea: !!initialData.seatingArea,
          cafeteria: !!initialData.cafeteria,
          bookingApprovalType: initialData.bookingApprovalType || 'INSTANT',
          paymentPreferences: Array.isArray(initialData.paymentPreferences) && initialData.paymentPreferences.length > 0 
            ? initialData.paymentPreferences 
            : ['FULL_ONLINE', 'ADVANCE_PAYMENT', 'FULL_CASH'],
        });
        setErrors({});
        
        // Pre-fill images and video if available in initialData
        setImages({
          entrance: initialData.entranceUrl ? { uri: initialData.entranceUrl, isExisting: true } : null,
          dayTurf: initialData.groundDayUrl ? { uri: initialData.groundDayUrl, isExisting: true } : null,
          nightTurf: initialData.groundNightUrl ? { uri: initialData.groundNightUrl, isExisting: true } : null,
        });
        setVideo(initialData.videoUrl ? { uri: initialData.videoUrl, isExisting: true } : null);
      } else {
        setForm({
          name: '', description: '', sportsType: '', turfSize: '', address: '',
          city: '', pincode: '', openTime: '06:00', closeTime: '23:00',
          minSlotDurationMins: '60', weekdayDayPrice: '', weekdayNightPrice: '',
          weekendDayPrice: '', weekendNightPrice: '',
          floodLights: false, parking: false, washroom: false, changingRoom: false,
          drinkingWater: false, seatingArea: false, cafeteria: false,
          bookingApprovalType: 'INSTANT',
          paymentPreferences: ['FULL_ONLINE', 'ADVANCE_PAYMENT', 'FULL_CASH'],
          lat: 19.0760, lng: 72.8777,
        });
        setErrors({});
        setImages({ entrance: null, dayTurf: null, nightTurf: null });
        setVideo(null);

        // Fetch user location
        (async () => {
          try {
            const { status } = await Location.requestForegroundPermissionsAsync();
            if (status !== 'granted') return;
            const location = await Location.getCurrentPositionAsync({
              accuracy: Location.Accuracy.Balanced,
            });
            if (location && location.coords) {
              setForm((p: any) => ({ 
                ...p, 
                lat: location.coords.latitude, 
                lng: location.coords.longitude 
              }));
            }
          } catch (err) {
            console.warn("Failed to get initial location:", err);
          }
        })();
      }
    }
  }, [visible, initialData]);

  const set = (key: string, value: any) => setForm((p: any) => ({ ...p, [key]: value }));

  const togglePaymentPreference = (pref: string) => {
    const current = form.paymentPreferences || [];
    if (current.includes(pref)) {
      if (current.length === 1) {
        showWarning('Cannot Disable', 'You must accept at least one payment method.');
        return;
      }
      set('paymentPreferences', current.filter((p: string) => p !== pref));
    } else {
      set('paymentPreferences', [...current, pref]);
    }
  };

  const pickVideo = async () => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Videos,
        allowsEditing: false, // Video editing can be flaky on some devices
      });

      if (!result.canceled && result.assets && result.assets[0]) {
        setVideo(result.assets[0]);
      }
    } catch (e) {
      console.log('Video picker error', e);
      showError('Error', 'Could not select video.');
    }
  };

  const pickImage = async (type: string) => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images, // legacy enum syntax works here too
        allowsEditing: true,
        quality: 0.8,
      });

      if (!result.canceled && result.assets && result.assets[0]) {
        setImages((prev: any) => ({ ...prev, [type]: result.assets[0] }));
      }
    } catch (e) {
      console.log('Image picker error', e);
    }
  };

  const handleSubmit = async () => {
    if (loading) return; // Prevent double clicks
    setLoading(true);
    
    setErrors({});
    let hasError = false;
    const newErrors: any = {};

    if (!form.name?.trim()) { newErrors.name = 'Name is required'; hasError = true; }
    if (!form.sportsType?.trim()) { newErrors.sportsType = 'Sport is required'; hasError = true; }
    if (!form.address?.trim()) { newErrors.address = 'Address is required'; hasError = true; }
    if (!form.turfSize?.trim()) { newErrors.turfSize = 'Turf size is required'; hasError = true; }
    if (!form.city?.trim()) { newErrors.city = 'City is required'; hasError = true; }
    if (!form.pincode?.trim()) { newErrors.pincode = 'Pincode is required'; hasError = true; }
    if (!form.weekdayDayPrice) { newErrors.weekdayDayPrice = 'Price is required'; hasError = true; }
    if (!form.weekdayNightPrice) { newErrors.weekdayNightPrice = 'Price is required'; hasError = true; }

    if (!form.paymentPreferences || form.paymentPreferences.length === 0) {
      newErrors.paymentPreferences = 'Must select at least one payment method';
      hasError = true;
    }

    if (hasError) {
      setErrors(newErrors);
      showWarning('Required Fields', 'Please fill in all highlighted fields or ensure requirements are met.');
      setLoading(false);
      return;
    }

    try {
      const token = await AsyncStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
      
      console.log('Using Token:', token);
      if (!token) {
        showError('Auth Error', 'No active session found. Please completely log out and log back in.');
        setLoading(false);
        return;
      }
      
      const payload: any = {};
      
      // Build JSON payload first because submitting as File-Mixed FormData throws 500 on Render backend
      Object.keys(form).forEach((key) => {
        let val = form[key];
        if (['minSlotDurationMins', 'weekdayDayPrice', 'weekdayNightPrice', 'weekendDayPrice', 'weekendNightPrice'].includes(key)) {
          payload[key] = Number(val) || 0;
        } else {
          payload[key] = val;
        }
      });
      
      // Enforce uppercase for sportsType to survive backend validation
      if (payload.sportsType) {
        payload.sportsType = String(payload.sportsType).toUpperCase().trim();
      }

      console.log('Sending JSON Payload:', JSON.stringify(payload, null, 2));

      const isEdit = !!initialData?.id;
      const url = isEdit 
        ? `https://turfsy.onrender.com/api/v3/turfs/${initialData.id}` 
        : 'https://turfsy.onrender.com/api/v3/turfs';

      // 1. Create/Update Turf Setup via JSON mapping (Bypasses backend Multi-part class-validator parsing failure)
      const res = await fetch(url, {
        method: isEdit ? 'PATCH' : 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(payload)
      });

      const data = await res.json();
      console.log(`Turf ${isEdit ? 'Update' : 'Creation'} Response:`, data);
      
      if (!res.ok) throw new Error(data.message ? (Array.isArray(data.message) ? data.message.join(', ') : data.message) : `Failed to ${isEdit ? 'update' : 'create'} turf settings`);
      
      const turfId = isEdit ? initialData.id : data.id;

      // 2. Upload Images using the robust single-image endpoint
      if (images.entrance || images.dayTurf || images.nightTurf) {
        const uploadPromises = ['entrance', 'dayTurf', 'nightTurf'].map(async (type) => {
          if (!images[type] || images[type].isExisting) return null;

          if (Platform.OS === 'web') {
            const imageFormData = new FormData();
            let filename = images[type].uri.split('/').pop() || `${type}.jpg`;
            if (filename.includes('blob:')) filename = `${type}.jpg`;

            const imgRes = await fetch(images[type].uri);
            const blob = await imgRes.blob();
            imageFormData.append('file', blob, filename);
            
            const imageRes = await fetch(`https://turfsy.onrender.com/api/v3/turfs/${turfId}/upload-image/${type}`, {
              method: 'PATCH',
              headers: { Authorization: `Bearer ${token}` },
              body: imageFormData
            });
            if (!imageRes.ok) throw new Error(`Failed to upload ${type} image.`);
            return imageRes.json();
          } else {
            const uploadRes = await FileSystem.uploadAsync(
              `https://turfsy.onrender.com/api/v3/turfs/${turfId}/upload-image/${type}`,
              images[type].uri,
              {
                httpMethod: 'PATCH',
                uploadType: 1, // 1 represents FileSystemUploadType.MULTIPART
                fieldName: 'file',
                mimeType: images[type].mimeType || 'image/jpeg',
                headers: { Authorization: `Bearer ${token}` }
              }
            );
            if (uploadRes.status < 200 || uploadRes.status >= 300) {
              throw new Error(`Failed to upload ${type} image.`);
            }
            return JSON.parse(uploadRes.body);
          }
        });

        await Promise.all(uploadPromises);
      }

      // 3. Upload Video natively
      if (video && !video.isExisting) {
        if (Platform.OS === 'web') {
          const videoFormData = new FormData();
          let filename = video.uri.split('/').pop() || 'video.mp4';
          if (filename.includes('blob:')) filename = 'video.mp4';

          const vidRes = await fetch(video.uri);
          const blob = await vidRes.blob();
          videoFormData.append('file', blob, filename);

          const uploadRes = await fetch(`https://turfsy.onrender.com/api/v3/turfs/${turfId}/video`, {
            method: isEdit ? 'PATCH' : 'POST',
            headers: { Authorization: `Bearer ${token}` },
            body: videoFormData
          });
          if (!uploadRes.ok) console.warn('Failed to upload video:', await uploadRes.text());
        } else {
          const uploadRes = await FileSystem.uploadAsync(
            `https://turfsy.onrender.com/api/v3/turfs/${turfId}/video`,
            video.uri,
            {
              httpMethod: isEdit ? 'PATCH' : 'POST',
              uploadType: 1, // 1 represents FileSystemUploadType.MULTIPART
              fieldName: 'file',
              mimeType: video.mimeType || 'video/mp4',
              headers: { Authorization: `Bearer ${token}` }
            }
          );
          if (uploadRes.status < 200 || uploadRes.status >= 300) {
            console.warn('Failed to upload video:', uploadRes.body);
          }
        }
      }

      // Show successful creation animation / states inline without blocking browser logic
      if (Platform.OS !== 'web') {
        showSuccess('Success', `Turf ${isEdit ? 'updated' : 'created'} successfully!`, [
          { text: 'OK', onPress: () => {
            onClose();
            onSuccess();
          }}
        ]);
      } else {
        // Fast close for web to avoid jarring window.alerts
        onClose();
        onSuccess();
      }
      
    } catch (err: any) {
      showError('Error', err.message || 'Failed to create turf');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet" onRequestClose={onClose}>
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={onClose} style={styles.iconBtn}>
            <Ionicons name="close" size={24} color={theme.colors.text} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>{isViewOnly ? 'Turf Details' : initialData ? 'Update Turf' : 'Create New Turf'}</Text>
          <View style={{ width: 24 }} />
        </View>

        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
          <ScrollView 
            scrollEnabled={scrollEnabled}
            contentContainerStyle={styles.scroll} 
            showsVerticalScrollIndicator={false}
          >
            
            <SectionHeader title="TURF DETAILS" theme={theme} styles={styles} />
            <View style={styles.section}>
              <InputField label="TURF NAME" value={form.name} error={errors.name} onChangeText={(v) => set('name', v)} placeholder="Champions Arena" editable={!isViewOnly} />
              <InputField label="DESCRIPTION" value={form.description} onChangeText={(v) => set('description', v)} placeholder="Premium 5-a-side football turf" multiline editable={!isViewOnly} />
              <Text style={styles.inputLabel}>SPORTS TYPE</Text>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginTop: 4 }}>
                {[
                  { label: 'Football ⚽', value: 'FOOTBALL' },
                  { label: 'Cricket 🏏', value: 'CRICKET' },
                  { label: 'Football & Cricket ⚽🏏', value: 'BOTH' }
                ].map(sport => {
                  const isActive = form.sportsType === sport.value;
                  return (
                    <TouchableOpacity
                      key={sport.value}
                      style={[styles.amenityChip, isActive && styles.amenityChipActive, { paddingVertical: 10 }, isViewOnly && { opacity: 0.8 }]}
                      onPress={() => set('sportsType', sport.value)}
                      activeOpacity={0.7}
                      disabled={isViewOnly}
                    >
                      <Text style={[styles.amenityChipText, isActive && styles.amenityChipTextActive, { fontSize: fp(12) }]}>{sport.label}</Text>
                    </TouchableOpacity>
                  );
                })}
              </View>
              {errors.sportsType && <Text style={{ color: theme.colors.danger || '#ef4444', fontSize: fp(11), marginTop: -10, fontWeight: '700' }}>{errors.sportsType}</Text>}
              <InputField label="TURF SIZE" value={form.turfSize} error={errors.turfSize} onChangeText={(v) => set('turfSize', v)} placeholder="60x40 ft" editable={!isViewOnly} />
              <InputField label="ADDRESS" value={form.address} error={errors.address} onChangeText={(v) => set('address', v)} placeholder="Survey No. 12, Baner Road" multiline editable={!isViewOnly} />
              <View style={styles.row}>
                <View style={{ flex: 1 }}>
                  <InputField label="CITY" value={form.city} error={errors.city} onChangeText={(v) => set('city', v)} placeholder="Pune" editable={!isViewOnly} />
                </View>
                <View style={{ flex: 1 }}>
                  <InputField label="PINCODE" value={form.pincode} error={errors.pincode} onChangeText={(v) => set('pincode', v)} keyboardType="number-pad" placeholder="411045" editable={!isViewOnly} />
                </View>
              </View>
              
              
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 4 }}>
                <Text style={styles.inputLabel}>EXACT LOCATION (Drag or tap map)</Text>
              </View>
              <View style={styles.mapContainer}>
                {Platform.OS === 'web' ? (
                  <View style={styles.webMapFallback}>
                    <Ionicons name="map" size={40} color={theme.colors.primary} />
                    <Text style={{ color: theme.colors.textMuted, marginTop: 10 }}>Interactive maps not supported on web preview.</Text>
                    <Text style={{ color: theme.colors.primary, marginTop: 5 }}>Coordinates captured: {form.lat.toFixed(4)}, {form.lng.toFixed(4)}</Text>
                  </View>
                ) : (
                  <MapView
                    style={styles.map}
                    region={{
                      latitude: form.lat,
                      longitude: form.lng,
                      latitudeDelta: 0.05,
                      longitudeDelta: 0.05,
                    }}
                    scrollEnabled={!isViewOnly}
                    zoomEnabled={!isViewOnly}
                    pitchEnabled={!isViewOnly}
                    rotateEnabled={!isViewOnly}
                    onPress={(e) => {
                      if (isViewOnly) return;
                      set('lat', e.nativeEvent.coordinate.latitude);
                      set('lng', e.nativeEvent.coordinate.longitude);
                    }}
                  >
                    <Marker
                      coordinate={{ latitude: form.lat, longitude: form.lng }}
                      draggable={!isViewOnly}
                      onDragEnd={(e) => {
                        if (isViewOnly) return;
                        set('lat', e.nativeEvent.coordinate.latitude);
                        set('lng', e.nativeEvent.coordinate.longitude);
                      }}
                    />
                  </MapView>
                )}
              </View>

              {!isViewOnly && (
                <TouchableOpacity
                  style={{ 
                    flexDirection: 'row', 
                    alignItems: 'center', 
                    justifyContent: 'center',
                    width: '100%', 
                    marginTop: 16, 
                    gap: 8, 
                    paddingVertical: 14, 
                    backgroundColor: 'rgba(16, 185, 129, 0.1)', 
                    borderRadius: 16,
                    borderWidth: 1,
                    borderColor: 'rgba(16, 185, 129, 0.3)',
                    opacity: detectingLocation ? 0.7 : 1 
                  }}
                  activeOpacity={0.7}
                  disabled={detectingLocation}
                  onPress={async () => {
                    try {
                      setDetectingLocation(true);
                      const { status } = await Location.requestForegroundPermissionsAsync();
                      if (status === 'granted') {
                        const location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
                        if (location && location.coords) {
                          const { latitude, longitude } = location.coords;
                          set('lat', latitude);
                          set('lng', longitude);
                          
                          try {
                            const geocode = await Location.reverseGeocodeAsync({ latitude, longitude });
                            if (geocode && geocode.length > 0) {
                              const place = geocode[0];
                              const formattedAddress = [place.name, place.street, place.district, place.subregion].filter(Boolean).join(', ');
                              if (formattedAddress) set('address', formattedAddress);
                              if (place.city || place.district) set('city', place.city || place.district);
                              if (place.postalCode) set('pincode', place.postalCode);
                            }
                          } catch (geoErr) {
                            console.log('Geocoding error:', geoErr);
                          }
                        }
                      } else {
                        showWarning('Permission Denied', 'Please grant location permissions to use this feature.');
                      }
                    } catch (err) {
                      console.log('Location error:', err);
                    } finally {
                      setDetectingLocation(false);
                    }
                  }}
                >
                  {detectingLocation ? (
                    <ActivityIndicator size="small" color={theme.colors.primary} />
                  ) : (
                    <Ionicons name="location" size={18} color={theme.colors.primary} />
                  )}
                  <Text style={{ color: theme.colors.primary, fontSize: fp(14), fontWeight: '800' }}>
                    {detectingLocation ? 'Detecting Location...' : 'Use Current Location'}
                  </Text>
                  {!detectingLocation && <Text style={{ color: theme.colors.primary, fontSize: fp(12), opacity: 0.7 }}>(Auto-fill)</Text>}
                </TouchableOpacity>
              )}
            </View>

            <SectionHeader title="PRICING & HOURS" theme={theme} styles={styles} />
            <View style={styles.section}>
              <View style={styles.row}>
                <View style={{ flex: 1 }}>
                  <InputField label="OPEN TIME" value={form.openTime} error={errors.openTime} onChangeText={(v) => set('openTime', v)} placeholder="06:00" editable={!isViewOnly} />
                </View>
                <View style={{ flex: 1 }}>
                  <InputField label="CLOSE TIME" value={form.closeTime} error={errors.closeTime} onChangeText={(v) => set('closeTime', v)} placeholder="23:00" editable={!isViewOnly} />
                </View>
              </View>
              <InputField label="MIN SLOT (MINS)" value={form.minSlotDurationMins} error={errors.minSlotDurationMins} onChangeText={(v) => set('minSlotDurationMins', v)} keyboardType="number-pad" placeholder="60" editable={!isViewOnly} />
              
              <View style={styles.row}>
                <View style={{ flex: 1 }}>
                  <InputField label="WEEKDAY DAY (₹)" value={form.weekdayDayPrice} error={errors.weekdayDayPrice} onChangeText={(v) => set('weekdayDayPrice', v)} keyboardType="number-pad" placeholder="800" editable={!isViewOnly} />
                </View>
                <View style={{ flex: 1 }}>
                  <InputField label="WEEKDAY NIGHT (₹)" value={form.weekdayNightPrice} error={errors.weekdayNightPrice} onChangeText={(v) => set('weekdayNightPrice', v)} keyboardType="number-pad" placeholder="1200" editable={!isViewOnly} />
                </View>
              </View>
              
              <View style={styles.row}>
                <View style={{ flex: 1 }}>
                  <InputField label="WEEKEND DAY (₹)" value={form.weekendDayPrice} error={errors.weekendDayPrice} onChangeText={(v) => set('weekendDayPrice', v)} keyboardType="number-pad" placeholder="1000" editable={!isViewOnly} />
                </View>
                <View style={{ flex: 1 }}>
                  <InputField label="WEEKEND NIGHT (₹)" value={form.weekendNightPrice} error={errors.weekendNightPrice} onChangeText={(v) => set('weekendNightPrice', v)} keyboardType="number-pad" placeholder="1500" editable={!isViewOnly} />
                </View>
              </View>
            </View>

            <SectionHeader title="AMENITIES" theme={theme} styles={styles} />
            <View style={styles.amenitiesGrid}>
              {AMENITIES.map((key) => {
                const isActive = form[key];
                return (
                  <TouchableOpacity
                    key={key}
                    style={[styles.amenityChip, isActive && styles.amenityChipActive, isViewOnly && { opacity: 0.8 }]}
                    activeOpacity={0.7}
                    onPress={() => set(key, !form[key])}
                    disabled={isViewOnly}
                  >
                    <Ionicons name={AMENITY_ICONS[key]} size={16} color={isActive ? theme.colors.background : theme.colors.primary} />
                    <Text style={[styles.amenityChipText, isActive && styles.amenityChipTextActive]}>{AMENITY_LABELS[key]}</Text>
                  </TouchableOpacity>
                );
              })}
            </View>

            <SectionHeader title="BOOKING PREFERENCES" theme={theme} styles={styles} />
            <View style={[styles.section, { padding: 16, backgroundColor: theme.colors.surfaceMuted, borderRadius: 16, borderWidth: 1, borderColor: theme.colors.border }]}>
              <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 16 }}>
                <View style={{ flex: 1 }}>
                  <Text style={{ color: theme.colors.text, fontWeight: '800', fontSize: 15 }}>Require Manual Approval</Text>
                  <Text style={{ color: theme.colors.textMuted, fontSize: 13, marginTop: 6, lineHeight: 18 }}>
                    If enabled, you must manually approve or reject all new bookings. Rejected bookings are automatically refunded.
                  </Text>
                </View>
                <Switch
                  value={form.bookingApprovalType === 'MANUAL'}
                  onValueChange={(val) => set('bookingApprovalType', val ? 'MANUAL' : 'INSTANT')}
                  trackColor={{ false: theme.colors.border, true: theme.colors.primary }}
                  thumbColor={theme.colors.text}
                  disabled={isViewOnly}
                />
              </View>
            </View>

            <SectionHeader title="ACCEPTED PAYMENT METHODS" theme={theme} styles={styles} />
            <View style={styles.section}>
              {[
                { id: 'FULL_ONLINE', label: 'Full Online Payment', desc: 'Customer pays 100% online while booking.' },
                { id: 'ADVANCE_PAYMENT', label: 'Partial Advance', desc: 'Customer pays a deposit online and the rest at the venue.' },
                { id: 'FULL_CASH', label: 'Pay at Venue (Cash)', desc: 'Customer pays the full amount at the turf.' }
              ].map(pref => {
                const isActive = (form.paymentPreferences || []).includes(pref.id);
                return (
                  <TouchableOpacity
                    key={pref.id}
                    style={[styles.amenityChip, isActive && styles.amenityChipActive, { flexDirection: 'column', alignItems: 'flex-start', paddingVertical: 14 }, isViewOnly && { opacity: 0.8 }]}
                    activeOpacity={0.7}
                    onPress={() => togglePaymentPreference(pref.id)}
                    disabled={isViewOnly}
                  >
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                      <Ionicons name={isActive ? "checkbox" : "square-outline"} size={20} color={isActive ? theme.colors.background : theme.colors.primary} />
                      <Text style={[styles.amenityChipText, isActive && styles.amenityChipTextActive, { fontSize: 15 }]}>{pref.label}</Text>
                    </View>
                    <Text style={{ color: isActive ? 'rgba(0,0,0,0.6)' : theme.colors.textMuted, fontSize: 12, marginTop: 4, paddingLeft: 28 }}>
                      {pref.desc}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>

            <SectionHeader title="MEDIA UPLOADS" theme={theme} styles={styles} />
            <View style={styles.section}>
              {[
                { type: 'dayTurf', label: 'Ground Day Image', icon: 'sunny-outline', required: true },
                { type: 'nightTurf', label: 'Ground Night Image', icon: 'moon-outline', required: true },
                { type: 'entrance', label: 'Entrance / Parking Image', icon: 'business-outline', required: true }
              ].map(({ type, label, icon, required }) => (
                <View key={type} style={{ position: 'relative' }}>
                  <TouchableOpacity
                    style={[styles.imageUploadBox, { borderRadius: 12 }, isViewOnly && { opacity: 0.8 }]}
                    activeOpacity={0.7}
                    onPress={() => pickImage(type)}
                    disabled={isViewOnly}
                  >
                    {images[type] ? (
                      <Image source={{ uri: images[type].uri }} style={[styles.uploadedImage, { borderRadius: 12 }]} />
                    ) : (
                      <>
                        <Ionicons name={icon as any} size={28} color={theme.colors.primary} />
                        <Text style={styles.uploadText}>{label} {required && !isViewOnly && <Text style={{color: '#EF4444'}}>*</Text>}</Text>
                      </>
                    )}
                  </TouchableOpacity>
                  {images[type] && !isViewOnly && (
                    <TouchableOpacity 
                      style={{ position: 'absolute', top: -8, right: -8, backgroundColor: '#EF4444', width: 28, height: 28, borderRadius: 14, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: theme.colors.surface }}
                      onPress={() => setImages((prev: any) => ({ ...prev, [type]: null }))}
                    >
                      <Ionicons name="close" size={16} color="#FFF" />
                    </TouchableOpacity>
                  )}
                </View>
              ))}
            </View>

            <SectionHeader title="VIDEO (OPTIONAL)" theme={theme} styles={styles} />
            <View style={[styles.section, { position: 'relative' }]}>
              {video ? (
                <>
                  <View style={[styles.imageUploadBox, { padding: 0, borderWidth: 0, height: 200, borderRadius: 12 }, isViewOnly && { opacity: 0.8 }]}>
                    <VideoPreview uri={video.uri} />
                    {!isViewOnly && (
                      <TouchableOpacity 
                        style={styles.videoOverlayLabel} 
                        activeOpacity={0.9} 
                        onPress={pickVideo}
                      >
                        <Ionicons name="videocam" size={24} color="#FFF" />
                        <Text style={{ color: '#FFF', fontWeight: 'bold', marginLeft: 8 }}>Tap to Change Video</Text>
                      </TouchableOpacity>
                    )}
                  </View>
                  {!isViewOnly && (
                    <TouchableOpacity 
                      style={{ position: 'absolute', top: -8, right: -8, backgroundColor: '#EF4444', width: 28, height: 28, borderRadius: 14, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: theme.colors.surface, zIndex: 10 }}
                      onPress={() => setVideo(null)}
                    >
                      <Ionicons name="close" size={16} color="#FFF" />
                    </TouchableOpacity>
                  )}
                </>
              ) : (
                <TouchableOpacity
                  style={[styles.imageUploadBox, { borderRadius: 12 }, isViewOnly && { opacity: 0.8 }]}
                  activeOpacity={0.7}
                  onPress={pickVideo}
                  disabled={isViewOnly}
                >
                  <Ionicons name="videocam-outline" size={28} color={theme.colors.primary} />
                  <Text style={styles.uploadText}>Promotional Video (Optional)</Text>
                </TouchableOpacity>
              )}
            </View>

            {!isViewOnly && (
              <TouchableOpacity style={styles.submitBtn} onPress={handleSubmit} disabled={loading} activeOpacity={0.8}>
                {loading ? <ActivityIndicator color={theme.colors.background} /> : <Text style={styles.submitBtnText}>{initialData ? 'Update Turf Details' : 'Create Turf Profile'}</Text>}
              </TouchableOpacity>
            )}

            <View style={{ height: hp(40) }} />
          </ScrollView>
        </KeyboardAvoidingView>
      </View>
    </Modal>
  );
};


