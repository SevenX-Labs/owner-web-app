import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export const MapView = ({ region, onPress, children }: any) => {
  return (
    <View style={[styles.container, { backgroundColor: '#1A1A1A' }]}>
      <Text style={{ color: '#ADFF00', fontWeight: '900' }}>MAP PREVIEW (WEB)</Text>
      <Text style={{ color: '#8D8D8D', marginTop: 8 }}>
        Lat: {region.latitude.toFixed(4)} | Lng: {region.longitude.toFixed(4)}
      </Text>
      {children}
    </View>
  );
};

export const Marker = ({ coordinate, onDragEnd }: any) => null;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#333',
  },
});

export default MapView;