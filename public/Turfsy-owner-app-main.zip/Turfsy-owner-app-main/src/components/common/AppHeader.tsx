import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';

import { useResponsive } from '@/src/utils/responsive';
import { useAppTheme } from '@/src/hooks/useAppTheme';

interface HeaderAction {
  icon: keyof typeof Ionicons.glyphMap;
  onPress?: () => void;
}

interface AppHeaderProps {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  showBack?: boolean;
  action?: HeaderAction;
  showLogo?: boolean;
}

export function AppHeader({ eyebrow, title, subtitle, showBack = false, action, showLogo = false }: AppHeaderProps) {
  const router = useRouter();
  const responsive = useResponsive();
  const { theme } = useAppTheme();

  return (
    <View style={[styles.container, { marginBottom: 24 }]}>
      {showLogo && (
        <View style={styles.logoRow}>
          <Image source={require('@/assets/images/logo.png')} style={styles.logo} resizeMode="contain" />
          <Text style={[styles.logoText, { color: theme.colors.text, fontFamily: theme.fonts.bold, fontSize: responsive.fp(16) }]}>
            Owner App
          </Text>
        </View>
      )}
      {eyebrow ? (
        <Text style={[
          styles.eyebrow,
          {
            fontSize: responsive.fp(11),
            color: theme.colors.textMuted,
            fontFamily: theme.fonts.bold,
          },
        ]}>
          {eyebrow}
        </Text>
      ) : null}
      <View style={styles.titleRow}>
        {showBack ? (
          <TouchableOpacity
            style={[styles.iconButton, {
              backgroundColor: theme.colors.surfaceElevated,
              borderColor: theme.colors.border,
            }]}
            onPress={() => router.back()}
          >
            <Ionicons name="arrow-back" size={responsive.moderateScale(18)} color={theme.colors.text} />
          </TouchableOpacity>
        ) : null}
        <View style={styles.textWrap}>
          <Text
            style={[styles.title, {
              fontSize: responsive.fp(showBack ? 24 : 28),
              color: theme.colors.text,
              fontFamily: theme.fonts.black,
            }]}
            numberOfLines={1}
            adjustsFontSizeToFit
            minimumFontScale={0.8}
          >
            {title}
          </Text>
          {subtitle ? (
            <Text
              style={[styles.subtitle, {
                fontSize: responsive.fp(14),
                color: theme.colors.textSecondary,
                fontFamily: theme.fonts.regular,
              }]}
              numberOfLines={3}
            >
              {subtitle}
            </Text>
          ) : null}
        </View>
        {action ? (
          <TouchableOpacity
            style={[styles.iconButton, {
              backgroundColor: theme.colors.surfaceElevated,
              borderColor: theme.colors.border,
            }]}
            onPress={action.onPress}
          >
            <Ionicons name={action.icon} size={responsive.moderateScale(18)} color={theme.colors.textSecondary} />
          </TouchableOpacity>
        ) : null}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'column',
    gap: 4,
  },
  logoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 8,
  },
  logo: {
    width: 72,
    height: 72,
  },
  logoText: {
    letterSpacing: -0.3,
    fontSize: 24,
  },
  eyebrow: {
    letterSpacing: 1.5,
    marginBottom: 2,
    textTransform: 'uppercase',
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  textWrap: {
    flex: 1,
    minWidth: 0,
  },
  title: {
    letterSpacing: -0.5,
  },
  subtitle: {
    marginTop: 6,
    lineHeight: 20,
  },
  iconButton: {
    width: 44,
    height: 44,
    borderRadius: 14,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
  },
});
