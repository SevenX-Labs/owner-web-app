import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';

import { useAppTheme } from '@/src/hooks/useAppTheme';
import { useResponsive } from '@/src/utils/responsive';

interface HeroRevenueCardProps {
  monthlyRevenue: number;
  upcomingCount: number;
  onViewAll: () => void;
}

export const HeroRevenueCard: React.FC<HeroRevenueCardProps> = ({
  monthlyRevenue,
  upcomingCount,
  onViewAll,
}) => {
  const { theme } = useAppTheme();
  const responsive = useResponsive();

  return (
    <View style={[styles.heroCard, {
      backgroundColor: theme.colors.surface,
      borderColor: theme.colors.cardBorder,
    }]}>
      {/* Top Section */}
      <View style={styles.heroTop}>
        <View style={styles.heroLabelRow}>
          <View style={[styles.heroIconDot, { backgroundColor: theme.colors.primarySoft }]}>
            <Ionicons name="trending-up" size={14} color={theme.colors.primary} />
          </View>
          <Text style={[styles.heroLabel, {
            color: theme.colors.textMuted,
            fontFamily: theme.fonts.semiBold,
            fontSize: responsive.fp(12),
          }]}>
            This Month's Revenue
          </Text>
        </View>
        <TouchableOpacity
          style={[styles.heroMenuBtn, { backgroundColor: theme.colors.surfaceElevated }]}
          activeOpacity={0.7}
        >
          <Ionicons name="wallet-outline" size={18} color={theme.colors.textSecondary} />
        </TouchableOpacity>
      </View>

      {/* Revenue Amount */}
      <Text style={[styles.heroValue, {
        color: theme.colors.text,
        fontFamily: theme.fonts.black,
        fontSize: responsive.fp(40),
      }]} numberOfLines={1} adjustsFontSizeToFit>
        ₹{monthlyRevenue.toLocaleString('en-IN')}
      </Text>

      {/* Divider */}
      <View style={[styles.heroDivider, { backgroundColor: theme.colors.divider }]} />

      {/* Bottom Section */}
      <View style={styles.heroBottom}>
        <View style={styles.heroNoteRow}>
          <Ionicons name="calendar-outline" size={14} color={theme.colors.textMuted} />
          <Text style={[styles.heroNote, {
            color: theme.colors.textSecondary,
            fontFamily: theme.fonts.medium,
            fontSize: responsive.fp(13),
          }]} numberOfLines={1}>
            {upcomingCount} upcoming bookings
          </Text>
        </View>
        <TouchableOpacity
          style={[styles.viewAllBtn, { backgroundColor: theme.colors.primary }]}
          activeOpacity={0.8}
          onPress={onViewAll}
        >
          <Text style={[styles.viewAllText, {
            fontFamily: theme.fonts.bold,
            fontSize: responsive.fp(12),
          }]}>
            View All
          </Text>
          <Ionicons name="arrow-forward" size={14} color="#111111" />
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  heroCard: {
    borderRadius: 24,
    borderWidth: 1,
    padding: 24,
    marginBottom: 24,
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.22,
    shadowRadius: 30,
    elevation: 8,
  },
  heroTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  heroLabelRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  heroIconDot: {
    width: 28,
    height: 28,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  heroLabel: {
    letterSpacing: 0.3,
    textTransform: 'uppercase',
  },
  heroMenuBtn: {
    width: 36,
    height: 36,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  heroValue: {
    letterSpacing: -1.5,
    marginBottom: 20,
  },
  heroDivider: {
    height: 1,
    marginBottom: 16,
  },
  heroBottom: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  heroNoteRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    flex: 1,
    marginRight: 12,
  },
  heroNote: {
    letterSpacing: 0.1,
  },
  viewAllBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 18,
  },
  viewAllText: {
    color: '#111111',
    letterSpacing: 0.3,
  },
});
