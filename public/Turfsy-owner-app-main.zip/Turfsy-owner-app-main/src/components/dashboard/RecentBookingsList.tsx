import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';

import { useAppTheme } from '@/src/hooks/useAppTheme';
import { useResponsive } from '@/src/utils/responsive';
import { BookingCard } from './BookingCard';

interface RecentBookingsListProps {
  recentBookings: any[] | undefined;
  onSeeAll: () => void;
}

export const RecentBookingsList: React.FC<RecentBookingsListProps> = ({
  recentBookings,
  onSeeAll,
}) => {
  const { theme } = useAppTheme();
  const responsive = useResponsive();
  const router = useRouter();

  return (
    <>
      {/* ─── Recent Bookings Header ─────────────────────────────────────────── */}
      <View style={styles.sectionHeader}>
        <Text style={[styles.sectionTitle, {
          fontSize: responsive.fp(18),
          color: theme.colors.text,
          fontFamily: theme.fonts.bold,
        }]}>
          Recent Bookings
        </Text>
        <TouchableOpacity
          onPress={onSeeAll}
          style={[styles.seeAllBtn, { backgroundColor: theme.colors.surfaceElevated }]}
          activeOpacity={0.7}
        >
          <Text style={[styles.linkText, {
            fontSize: responsive.fp(13),
            color: theme.colors.primary,
            fontFamily: theme.fonts.semiBold,
          }]}>
            See all
          </Text>
          <Ionicons name="arrow-forward" size={14} color={theme.colors.primary} />
        </TouchableOpacity>
      </View>

      {/* ─── Booking Cards ──────────────────────────────────────────────────── */}
      <View style={styles.bookingsContainer}>
        {recentBookings && recentBookings.length > 0 ? (
          recentBookings.map((booking) => (
            <BookingCard
              key={booking.id || booking._id}
              booking={booking}
              onPress={() => router.push(`/booking/${booking.id || booking._id}` as any)}
            />
          ))
        ) : (
          /* ─── Empty State ─────────────────────────────────────────────── */
          <View style={[styles.emptyState, {
            backgroundColor: theme.colors.surface,
            borderColor: theme.colors.cardBorder,
          }]}>
            <View style={[styles.emptyIconWrap, {
              backgroundColor: theme.colors.surfaceMuted,
            }]}>
              <Ionicons name="calendar-outline" size={32} color={theme.colors.textMuted} />
            </View>
            <Text style={[styles.emptyStateText, {
              color: theme.colors.text,
              fontFamily: theme.fonts.semiBold,
            }]}>
              No recent bookings found.
            </Text>
            <Text style={[styles.emptyStateSubtext, {
              color: theme.colors.textMuted,
              fontFamily: theme.fonts.regular,
            }]}>
              New bookings will appear here.
            </Text>
          </View>
        )}
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  sectionTitle: {
    letterSpacing: -0.3,
  },
  seeAllBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 12,
  },
  linkText: {
    letterSpacing: 0.2,
  },
  bookingsContainer: {
    gap: 12,
  },
  emptyState: {
    paddingVertical: 48,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 24,
    borderWidth: 1,
    gap: 8,
  },
  emptyIconWrap: {
    width: 64,
    height: 64,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  emptyStateText: {
    fontSize: 16,
  },
  emptyStateSubtext: {
    fontSize: 14,
  },
});
