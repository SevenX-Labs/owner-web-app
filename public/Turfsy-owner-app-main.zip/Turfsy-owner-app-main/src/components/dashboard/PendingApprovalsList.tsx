import { Ionicons } from '@expo/vector-icons';
import React, { useEffect, useState, useCallback } from 'react';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';

import { PendingApprovalCard } from './PendingApprovalCard';
import { useAppTheme } from '@/src/hooks/useAppTheme';
import { useResponsive } from '@/src/utils/responsive';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { STORAGE_KEYS } from '@/src/utils/constants';

interface PendingApprovalsListProps {
  onSeeAll?: () => void;
}

export const PendingApprovalsList: React.FC<PendingApprovalsListProps> = ({ onSeeAll }) => {
  const { theme } = useAppTheme();
  const responsive = useResponsive();
  const [approvals, setApprovals] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchPendingApprovals = useCallback(async () => {
    try {
      setLoading(true);
      const token = await AsyncStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
      if (!token) return;

      const res = await fetch('https://turfsy.onrender.com/api/v3/bookings/owner?status=PENDING_APPROVAL', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Accept': 'application/json',
        }
      });
      const data = await res.json();
      if (data.success) {
        // Assume API returns bookings under data.data or directly in data
        setApprovals(Array.isArray(data.data) ? data.data : (Array.isArray(data) ? data : []));
      }
    } catch (error) {
      console.warn('Failed to load pending approvals:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchPendingApprovals();
    // Setting up a polling interval for pending approvals
    const intervalId = setInterval(fetchPendingApprovals, 30000);
    return () => clearInterval(intervalId);
  }, [fetchPendingApprovals]);

  if (loading && approvals.length === 0) {
    return (
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={[styles.title, { color: theme.colors.text, fontSize: responsive.fp(16) }]}>
            Pending Approvals
          </Text>
        </View>
        <ActivityIndicator size="small" color={theme.colors.primary} style={{ marginTop: 20 }} />
      </View>
    );
  }

  if (approvals.length === 0) {
    return null; // Don't show the section if there are no pending approvals
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <Text style={[styles.title, { color: theme.colors.text, fontSize: responsive.fp(16) }]}>
            Requires Approval
          </Text>
          <View style={[styles.badge, { backgroundColor: '#FF5D5D' }]}>
            <Text style={styles.badgeText}>{approvals.length}</Text>
          </View>
        </View>
      </View>

      <View style={styles.list}>
        {approvals.map((booking) => (
          <PendingApprovalCard 
            key={booking.id} 
            booking={booking} 
            onRefresh={fetchPendingApprovals} 
          />
        ))}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginBottom: 32,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  title: {
    fontWeight: '900',
    letterSpacing: 0.5,
  },
  badge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  badgeText: {
    color: '#FFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  list: {
    gap: 12,
  },
});
