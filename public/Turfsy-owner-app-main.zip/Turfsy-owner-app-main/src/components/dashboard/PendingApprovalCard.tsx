import { Ionicons } from '@expo/vector-icons';
import React, { useState } from 'react';
import { ActivityIndicator, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useAppTheme } from '@/src/hooks/useAppTheme';
import { useResponsive } from '@/src/utils/responsive';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { STORAGE_KEYS } from '@/src/utils/constants';

interface PendingApprovalCardProps {
  booking: any;
  onRefresh: () => void;
}

export const PendingApprovalCard: React.FC<PendingApprovalCardProps> = ({ booking, onRefresh }) => {
  const { theme } = useAppTheme();
  const responsive = useResponsive();
  const [loadingAction, setLoadingAction] = useState<'APPROVE' | 'REJECT' | null>(null);

  const bookingDate = new Date(booking.createdAt);

  const handleAction = async (action: 'APPROVE' | 'REJECT') => {
    try {
      setLoadingAction(action);
      const token = await AsyncStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
      
      const endpoint = action === 'APPROVE' 
        ? `https://turfsy.onrender.com/api/v3/bookings/owner/${booking.id}/approve`
        : `https://turfsy.onrender.com/api/v3/bookings/owner/${booking.id}/reject`;

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(action === 'REJECT' ? { reason: 'Owner rejected the booking.' } : {})
      });

      if (res.ok) {
        onRefresh();
      } else {
        const error = await res.json();
        console.warn(`Failed to ${action} booking:`, error.message);
      }
    } catch (err) {
      console.warn(`Error on ${action}:`, err);
    } finally {
      setLoadingAction(null);
    }
  };

  return (
    <View style={[styles.card, { backgroundColor: theme.colors.surface, borderColor: theme.colors.cardBorder }]}>
      <View style={styles.topRow}>
        <View style={[styles.dateBox, { backgroundColor: theme.colors.surfaceMuted, borderColor: theme.colors.border }]}>
          <Text style={[styles.dateDay, { color: theme.colors.text }]}>
            {bookingDate.toLocaleDateString('en-US', { day: 'numeric' })}
          </Text>
          <Text style={[styles.dateMonth, { color: theme.colors.primary }]}>
            {bookingDate.toLocaleDateString('en-US', { month: 'short' }).toUpperCase()}
          </Text>
        </View>

        <View style={styles.infoCol}>
          <Text style={[styles.title, { color: theme.colors.text, fontSize: responsive.fp(15) }]} numberOfLines={1}>
            {booking.customerName || booking.displayId}
          </Text>
          <View style={[styles.metaRow, { flexWrap: 'wrap' }]}>
            <Ionicons name="time-outline" size={13} color={theme.colors.textMuted} />
            <Text style={[styles.metaText, { color: theme.colors.textMuted }]}>
              {bookingDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </Text>
            <View style={[styles.dot, { backgroundColor: theme.colors.border }]} />
            <Text style={[styles.metaText, { color: theme.colors.textSecondary, fontWeight: '700' }]}>
              ₹{booking.amount}
            </Text>

            {/* Cash Collection Badge */}
            {(['HALF_ONLINE_HALF_CASH', 'ADVANCE_PAYMENT', 'FULL_CASH'].includes(booking.paymentType)) && 
              booking.paymentStatus !== 'SUCCESS' && (
              <>
                <View style={[styles.dot, { backgroundColor: theme.colors.border }]} />
                <View style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: '#FFEDD5', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6, gap: 4 }}>
                  <Ionicons name="cash" size={10} color="#EA580C" />
                  <Text style={{ fontSize: 10, color: '#EA580C', fontWeight: 'bold' }}>
                    Bal: ₹{booking.balanceAmount ?? (booking.amount - (booking.depositAmount || 0))}
                  </Text>
                </View>
              </>
            )}
            
            {/* Paid Online Badge */}
            {(booking.paymentType === 'FULL_ONLINE' || booking.paymentStatus === 'SUCCESS') && (
              <>
                <View style={[styles.dot, { backgroundColor: theme.colors.border }]} />
                <View style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: '#DCFCE7', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6, gap: 4 }}>
                  <Ionicons name="checkmark-circle" size={10} color="#16A34A" />
                  <Text style={{ fontSize: 10, color: '#16A34A', fontWeight: 'bold' }}>
                    Paid
                  </Text>
                </View>
              </>
            )}
          </View>
        </View>
      </View>

      <View style={[styles.divider, { backgroundColor: theme.colors.border }]} />

      <View style={styles.actionsRow}>
        <TouchableOpacity
          style={[styles.actionBtn, { borderColor: theme.colors.border, backgroundColor: theme.colors.surfaceMuted }]}
          activeOpacity={0.7}
          onPress={() => handleAction('REJECT')}
          disabled={loadingAction !== null}
        >
          {loadingAction === 'REJECT' ? <ActivityIndicator size="small" color="#FF5D5D" /> : (
            <>
              <Ionicons name="close" size={18} color="#FF5D5D" />
              <Text style={[styles.actionText, { color: '#FF5D5D' }]}>Reject</Text>
            </>
          )}
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.actionBtn, { backgroundColor: theme.colors.primary, borderWidth: 0 }]}
          activeOpacity={0.8}
          onPress={() => handleAction('APPROVE')}
          disabled={loadingAction !== null}
        >
          {loadingAction === 'APPROVE' ? <ActivityIndicator size="small" color="#000" /> : (
            <>
              <Ionicons name="checkmark" size={18} color="#000" />
              <Text style={[styles.actionText, { color: '#000', fontWeight: '800' }]}>Approve</Text>
            </>
          )}
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    padding: 16,
    borderRadius: 20,
    borderWidth: 1,
    marginBottom: 12,
  },
  topRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  dateBox: {
    width: 52,
    height: 52,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
  },
  dateDay: {
    fontSize: 18,
    fontWeight: '900',
    lineHeight: 22,
  },
  dateMonth: {
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 0.8,
  },
  infoCol: {
    flex: 1,
    gap: 4,
  },
  title: {
    fontWeight: '700',
    letterSpacing: 0.1,
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
  },
  metaText: {
    fontSize: 12,
    letterSpacing: 0.1,
  },
  dot: {
    width: 3,
    height: 3,
    borderRadius: 1.5,
    marginHorizontal: 2,
  },
  divider: {
    height: 1,
    marginVertical: 16,
  },
  actionsRow: {
    flexDirection: 'row',
    gap: 12,
  },
  actionBtn: {
    flex: 1,
    height: 44,
    borderRadius: 12,
    borderWidth: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
  },
  actionText: {
    fontWeight: '600',
    fontSize: 14,
    letterSpacing: 0.5,
  },
});
