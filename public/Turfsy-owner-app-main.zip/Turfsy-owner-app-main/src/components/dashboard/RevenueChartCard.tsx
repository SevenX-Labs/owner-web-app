import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { useAppTheme } from '@/src/hooks/useAppTheme';
import { useResponsive } from '@/src/utils/responsive';

interface ChartDataPoint {
  label: string;
  value: number;
}

interface RevenueChartCardProps {
  data?: ChartDataPoint[];
}

export const RevenueChartCard: React.FC<RevenueChartCardProps> = ({ data }) => {
  const { theme } = useAppTheme();
  const responsive = useResponsive();

  const emptyData = [
    { label: 'Mon', value: 0 },
    { label: 'Tue', value: 0 },
    { label: 'Wed', value: 0 },
    { label: 'Thu', value: 0 },
    { label: 'Fri', value: 0 },
    { label: 'Sat', value: 0 },
    { label: 'Sun', value: 0 },
  ];

  const chartData = data && data.length > 0 ? data : emptyData;
  const maxValue = Math.max(...chartData.map(d => d.value));
  
  // Calculate a reasonable max for the Y axis
  const yAxisMax = maxValue > 0 ? Math.ceil(maxValue / 10000) * 10000 : 100;
  
  return (
    <View style={[styles.card, { backgroundColor: theme.colors.surface, borderColor: theme.colors.cardBorder }]}>
      <View style={styles.header}>
        <Text style={[styles.title, { color: theme.colors.text, fontSize: responsive.fp(16) }]}>
          Revenue Trends
        </Text>
        <Ionicons name="bar-chart" size={20} color={theme.colors.primary} />
      </View>

      <View style={styles.chartContainer}>
        {/* Y Axis Grid Lines */}
        <View style={styles.gridLinesContainer}>
          {[1, 0.5, 0].map((tick, i) => (
            <View key={i} style={styles.gridLineRow}>
              <Text style={[styles.yAxisLabel, { color: theme.colors.textMuted }]}>
                {tick === 0 ? '0' : `${(yAxisMax * tick / 1000).toFixed(0)}k`}
              </Text>
              <View style={[styles.gridLine, { backgroundColor: theme.colors.border }]} />
            </View>
          ))}
        </View>

        {/* Bars */}
        <View style={styles.barsContainer}>
          {chartData.map((item, index) => {
            const heightPercent = maxValue > 0 ? (item.value / yAxisMax) * 100 : 0;
            const isHighest = item.value === maxValue;
            
            return (
              <View key={index} style={styles.barWrapper}>
                <View style={styles.barTrack}>
                  <View 
                    style={[
                      styles.barFill, 
                      { 
                        height: `${heightPercent}%`, 
                        backgroundColor: isHighest ? theme.colors.primary : theme.colors.surfaceElevated 
                      }
                    ]} 
                  />
                </View>
                <Text style={[styles.xAxisLabel, { color: isHighest ? theme.colors.primary : theme.colors.textMuted }]}>
                  {item.label}
                </Text>
              </View>
            );
          })}
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    borderRadius: 24,
    borderWidth: 1,
    padding: 24,
    marginBottom: 32,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  title: {
    fontWeight: '900',
    letterSpacing: 0.5,
  },
  chartContainer: {
    height: 180,
    flexDirection: 'row',
    position: 'relative',
  },
  gridLinesContainer: {
    position: 'absolute',
    top: 0,
    bottom: 24, // leave room for xAxis
    left: 0,
    right: 0,
    justifyContent: 'space-between',
  },
  gridLineRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  yAxisLabel: {
    width: 32,
    fontSize: 10,
    fontWeight: '600',
  },
  gridLine: {
    flex: 1,
    height: 1,
    opacity: 0.5,
  },
  barsContainer: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    marginLeft: 32, // clear the yAxis labels
  },
  barWrapper: {
    alignItems: 'center',
    flex: 1,
  },
  barTrack: {
    width: 24,
    height: 156, // total height - xAxis room
    justifyContent: 'flex-end',
    borderRadius: 6,
  },
  barFill: {
    width: '100%',
    borderRadius: 6,
    minHeight: 4,
  },
  xAxisLabel: {
    marginTop: 8,
    fontSize: 10,
    fontWeight: '700',
  },
});
