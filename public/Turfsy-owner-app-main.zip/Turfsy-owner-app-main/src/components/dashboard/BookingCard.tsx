import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';

import { useAppTheme } from '@/src/hooks/useAppTheme';
import { useResponsive } from '@/src/utils/responsive';

// ─── Status Colors ─────────────────────────────────────────────────────────
const STATUS_COLORS: Record<string, string> = {
  CONFIRMED: '#2ED573',
  PENDING: '#FFC857',
  CANCELLED: '#FF5D5D',
  COMPLETED: '#4DA3FF',
};

export const getStatusColor = (status: string): string => {
  return STATUS_COLORS[status?.toUpperCase()] || '#7D8592';
};

interface BookingCardProps {
  booking: any;
  onPress: () => void;
}

export const BookingCard: React.FC<BookingCardProps> = ({ booking, onPress }) => {
  const { theme } = useAppTheme();
  const responsive = useResponsive();

  const statusColor = getStatusColor(booking.status);
  const bookingDate = new Date(booking.createdAt);

  return (
    <TouchableOpacity
      activeOpacity={0.7}
      onPress={onPress}
    >
      <View style={[styles.bookingCard, {
        backgroundColor: theme.colors.surface,
        borderColor: theme.colors.cardBorder,
      }]}>
        {/* Date Column */}
        <View style={[styles.bookingDateWrap, {
          backgroundColor: theme.colors.surfaceMuted,
          borderColor: theme.colors.border,
        }]}>
          <Text style={[styles.bookingDateDay, {
            color: theme.colors.text,
            fontFamily: theme.fonts.black,
          }]}>
            {bookingDate.toLocaleDateString('en-US', { day: 'numeric' })}
          </Text>
          <Text style={[styles.bookingDateMonth, {
            color: theme.colors.primary,
            fontFamily: theme.fonts.bold,
          }]}>
            {bookingDate.toLocaleDateString('en-US', { month: 'short' }).toUpperCase()}
          </Text>
        </View>

        {/* Booking Info */}
        <View style={styles.bookingInfo}>
          <Text style={[styles.bookingTitle, {
            fontSize: responsive.fp(15),
            color: theme.colors.text,
            fontFamily: theme.fonts.semiBold,
          }]} numberOfLines={1}>
            {booking.displayId}
          </Text>

          <View style={styles.bookingMetaRow}>
            <Ionicons name="time-outline" size={13} color={theme.colors.textMuted} />
            <Text style={[styles.bookingMeta, {
              fontSize: responsive.fp(12),
              color: theme.colors.textMuted,
              fontFamily: theme.fonts.medium,
            }]}>
              {bookingDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </Text>
            <View style={[styles.metaDot, { backgroundColor: theme.colors.border }]} />
            <Text style={[styles.bookingAmount, {
              fontSize: responsive.fp(12),
              color: theme.colors.textSecondary,
              fontFamily: theme.fonts.semiBold,
            }]}>
              ₹{booking.amount}
            </Text>
          </View>

          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 4, flexWrap: 'wrap' }}>
            <View style={[styles.statusBadge, {
              backgroundColor: `${statusColor}14`,
            }]}>
              <View style={[styles.statusDot, { backgroundColor: statusColor }]} />
              <Text style={[styles.statusText, {
                fontSize: responsive.fp(10),
                color: statusColor,
                fontFamily: theme.fonts.bold,
              }]}>
                {booking.status}
              </Text>
            </View>

            {/* Cash Collection Badge */}
            {(['HALF_ONLINE_HALF_CASH', 'ADVANCE_PAYMENT', 'FULL_CASH'].includes(booking.paymentType)) && 
              booking.paymentStatus !== 'SUCCESS' && 
              !['CANCELLED', 'REJECTED'].includes(booking.status) && (
              <View style={[styles.statusBadge, { backgroundColor: '#FFEDD5' }]}>
                <Ionicons name="cash" size={12} color="#EA580C" />
                <Text style={[styles.statusText, { fontSize: responsive.fp(10), color: '#EA580C', fontFamily: theme.fonts.bold }]}>
                  Collect ₹{booking.balanceAmount ?? (booking.amount - (booking.depositAmount || 0))}
                </Text>
              </View>
            )}

            {/* Paid Online Badge */}
            {(booking.paymentType === 'FULL_ONLINE' || booking.paymentStatus === 'SUCCESS') && 
              !['CANCELLED', 'REJECTED'].includes(booking.status) && (
              <View style={[styles.statusBadge, { backgroundColor: '#DCFCE7' }]}>
                <Ionicons name="checkmark-circle" size={12} color="#16A34A" />
                <Text style={[styles.statusText, { fontSize: responsive.fp(10), color: '#16A34A', fontFamily: theme.fonts.bold }]}>
                  Paid
                </Text>
              </View>
            )}
          </View>
        </View>

        {/* Arrow */}
        <View style={[styles.bookingArrow, {
          backgroundColor: theme.colors.surfaceElevated,
        }]}>
          <Ionicons name="chevron-forward" size={16} color={theme.colors.textMuted} />
        </View>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  bookingCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    padding: 16,
    borderRadius: 20,
    borderWidth: 1,
  },
  bookingDateWrap: {
    width: 52,
    height: 52,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
  },
  bookingDateDay: {
    fontSize: 18,
    lineHeight: 22,
  },
  bookingDateMonth: {
    fontSize: 10,
    letterSpacing: 0.8,
  },
  bookingInfo: {
    flex: 1,
    gap: 4,
  },
  bookingTitle: {
    letterSpacing: 0.1,
  },
  bookingMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
  },
  bookingMeta: {
    letterSpacing: 0.1,
  },
  metaDot: {
    width: 3,
    height: 3,
    borderRadius: 1.5,
    marginHorizontal: 2,
  },
  bookingAmount: {
    letterSpacing: 0.1,
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
    gap: 5,
  },
  statusDot: {
    width: 5,
    height: 5,
    borderRadius: 2.5,
  },
  statusText: {
    letterSpacing: 0.5,
  },
  bookingArrow: {
    width: 36,
    height: 36,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
