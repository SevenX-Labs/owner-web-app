import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useRouter } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, TouchableOpacity, View, ActivityIndicator } from 'react-native';

import { useAppTheme } from '@/src/hooks/useAppTheme';
import { STORAGE_KEYS } from '@/src/utils/constants';
import { fp } from '@/src/utils/responsive';

export const SettlementOverviewCard = () => {
  const { theme } = useAppTheme();
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [pendingAmount, setPendingAmount] = useState(0);
  const [totalSettled, setTotalSettled] = useState(0);

  useEffect(() => {
    const fetchSettlements = async () => {
      try {
        const token = await AsyncStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
        if (!token) return;

        const res = await fetch('https://turfsy.onrender.com/api/v3/owner-settlements/summary', {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Accept': 'application/json',
          }
        });
        const data = await res.json();
        
        if (data.success && data.data) {
          setPendingAmount(data.data.pendingSettlements || 0);
          setTotalSettled(data.data.totalSettled || 0);
        }
      } catch (e) {
        console.warn('Failed to fetch settlement summary:', e);
      } finally {
        setLoading(false);
      }
    };
    
    fetchSettlements();
  }, []);

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.surfaceMuted, borderColor: theme.colors.border }]}>
      <View style={styles.header}>
        <Text style={[styles.title, { color: theme.colors.textMuted }]}>SETTLEMENTS & PAYOUTS</Text>
        <TouchableOpacity onPress={() => router.push('/earnings' as any)}>
          <Text style={[styles.viewAll, { color: theme.colors.primary }]}>View Details</Text>
        </TouchableOpacity>
      </View>

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator color={theme.colors.primary} size="small" />
        </View>
      ) : (
        <View style={styles.content}>
          <View style={styles.statBox}>
            <View style={styles.statLabelRow}>
              <Ionicons name="time-outline" size={14} color="#F59E0B" />
              <Text style={[styles.statLabel, { color: theme.colors.textMuted }]}>Pending</Text>
            </View>
            <Text style={[styles.statValue, { color: theme.colors.text }]}>
              ₹{pendingAmount.toLocaleString()}
            </Text>
          </View>
          
          <View style={[styles.divider, { backgroundColor: theme.colors.border }]} />
          
          <View style={styles.statBox}>
            <View style={styles.statLabelRow}>
              <Ionicons name="checkmark-circle-outline" size={14} color="#10B981" />
              <Text style={[styles.statLabel, { color: theme.colors.textMuted }]}>Settled</Text>
            </View>
            <Text style={[styles.statValue, { color: theme.colors.text }]}>
              ₹{totalSettled.toLocaleString()}
            </Text>
          </View>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    borderRadius: 24,
    borderWidth: 1,
    padding: 20,
    marginBottom: 32,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  title: {
    fontSize: fp(11),
    fontWeight: '800',
    letterSpacing: 1.5,
  },
  viewAll: {
    fontSize: fp(12),
    fontWeight: '800',
  },
  loadingContainer: {
    paddingVertical: 20,
    alignItems: 'center',
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  statBox: {
    flex: 1,
    gap: 4,
  },
  statLabelRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  statLabel: {
    fontSize: fp(12),
    fontWeight: '700',
  },
  statValue: {
    fontSize: fp(20),
    fontWeight: '900',
  },
  divider: {
    width: 1,
    height: '80%',
    marginHorizontal: 16,
  },
});
