import React from 'react';

import { useImmersiveMode } from '@/src/hooks/useImmersiveMode';

export function ImmersiveModeProvider({ children }: { children: React.ReactNode }) {
  useImmersiveMode();

  return <>{children}</>;
}
