import React from 'react';
import { ScrollView, StyleSheet, View, ViewStyle } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { useResponsive } from '@/src/utils/responsive';
import { useAppTheme } from '@/src/hooks/useAppTheme';

interface ScreenProps {
  children: React.ReactNode;
  scrollable?: boolean;
  contentStyle?: ViewStyle;
  edges?: ('top' | 'right' | 'bottom' | 'left')[];
  refreshControl?: React.ReactElement;
  style?: ViewStyle;
}

export function Screen({
  children,
  scrollable = false,
  contentStyle,
  edges = ['top', 'left', 'right'],
  refreshControl,
  style,
}: ScreenProps) {
  const responsive = useResponsive();
  const { theme } = useAppTheme();
  const horizontalPadding = responsive.isTablet ? 32 : responsive.isCompact ? 16 : 20;

  return (
    <SafeAreaView edges={edges} style={[styles.safeArea, { backgroundColor: theme.colors.background }, style]}>
      {scrollable ? (
        <ScrollView
          showsVerticalScrollIndicator={false}
          refreshControl={refreshControl}
          contentContainerStyle={[
            styles.scrollContent,
            { paddingHorizontal: horizontalPadding, paddingBottom: 120 },
            contentStyle,
          ]}
        >
          {children}
        </ScrollView>
      ) : (
        <View style={[styles.content, { paddingHorizontal: horizontalPadding }, contentStyle]}>
          {children}
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    paddingTop: 16,
    flexGrow: 1,
  },
});
