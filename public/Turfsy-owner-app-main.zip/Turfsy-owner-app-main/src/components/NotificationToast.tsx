// NotificationToast — In-app foreground notification overlay

import React, { useEffect, useRef, useCallback } from 'react';
import {
  Animated,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  ViewStyle,
  TextStyle,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { InAppNotification } from '../hooks/useNotifications';
import { NotificationType } from '../services/notificationService';

interface NotificationToastProps {
  notification: InAppNotification | null;
  onDismiss: () => void;
  onTap: () => void;
}

// Map notification types to icons and accent colors
const NOTIFICATION_META: Record<
  NotificationType,
  { icon: keyof typeof Ionicons.glyphMap; color: string; label: string }
> = {
  NEW_BOOKING_OWNER: { icon: 'calendar', color: '#ADFF00', label: 'New Booking' },
  NEW_PENDING_OWNER: { icon: 'time', color: '#FFB800', label: 'Pending Booking' },
  PAYMENT_RECEIVED_OWNER: { icon: 'card', color: '#00E676', label: 'Payment Received' },
  BOOKING_CANCELLED_OWNER: { icon: 'close-circle', color: '#FF4B4B', label: 'Cancelled' },
  VISIT_COMPLETED_OWNER: { icon: 'checkmark-circle', color: '#00E676', label: 'Completed' },
  MANUAL_COMPLETED_OWNER: { icon: 'checkmark-done-circle', color: '#00E676', label: 'Completed' },
  PIN_WINDOW_OPEN: { icon: 'key', color: '#7C4DFF', label: 'Verify PIN' },
};

const AUTO_DISMISS_MS = 5000;

export const NotificationToast: React.FC<NotificationToastProps> = ({
  notification,
  onDismiss,
  onTap,
}) => {
  const translateY = useRef(new Animated.Value(-150)).current;
  const opacity = useRef(new Animated.Value(0)).current;
  const dismissTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const isAnimatingOut = useRef(false);

  const clearTimer = useCallback(() => {
    if (dismissTimer.current) {
      clearTimeout(dismissTimer.current);
      dismissTimer.current = null;
    }
  }, []);

  const animateOut = useCallback(() => {
    if (isAnimatingOut.current) return;
    isAnimatingOut.current = true;
    clearTimer();

    Animated.parallel([
      Animated.timing(translateY, {
        toValue: -150,
        duration: 300,
        useNativeDriver: true,
      }),
      Animated.timing(opacity, {
        toValue: 0,
        duration: 300,
        useNativeDriver: true,
      }),
    ]).start(() => {
      isAnimatingOut.current = false;
      onDismiss();
    });
  }, [translateY, opacity, onDismiss, clearTimer]);

  useEffect(() => {
    if (notification) {
      // Reset animated values before animating in
      isAnimatingOut.current = false;
      translateY.setValue(-150);
      opacity.setValue(0);

      // Animate in
      Animated.parallel([
        Animated.spring(translateY, {
          toValue: 0,
          useNativeDriver: true,
          tension: 80,
          friction: 12,
        }),
        Animated.timing(opacity, {
          toValue: 1,
          duration: 200,
          useNativeDriver: true,
        }),
      ]).start();

      // Auto-dismiss after timeout
      clearTimer();
      dismissTimer.current = setTimeout(() => {
        animateOut();
      }, AUTO_DISMISS_MS);
    }

    return clearTimer;
  }, [notification?.id]); // Use notification id to detect new notifications

  const handleTap = useCallback(() => {
    clearTimer();
    console.log('[NotificationToast] Toast tapped');
    onTap();
  }, [onTap, clearTimer]);

  const handleDismiss = useCallback(() => {
    console.log('[NotificationToast] Dismiss tapped');
    animateOut();
  }, [animateOut]);

  if (!notification) return null;

  const notifType = notification.data?.type;
  const meta = notifType ? NOTIFICATION_META[notifType] : null;
  const accentColor = meta?.color || '#ADFF00';
  const iconName = meta?.icon || 'notifications';

  return (
    <Animated.View
      style={[
        styles.container,
        {
          transform: [{ translateY }],
          opacity,
        },
      ]}
      pointerEvents="box-none"
    >
      <TouchableOpacity
        style={styles.toast}
        activeOpacity={0.85}
        onPress={handleTap}
      >
        {/* Accent stripe */}
        <View style={[styles.accentStripe, { backgroundColor: accentColor }]} />

        {/* Icon */}
        <View style={[styles.iconContainer, { backgroundColor: `${accentColor}20` }]}>
          <Ionicons name={iconName} size={22} color={accentColor} />
        </View>

        {/* Content */}
        <View style={styles.content}>
          <Text style={styles.title} numberOfLines={1}>
            {notification.title}
          </Text>
          <Text style={styles.body} numberOfLines={2}>
            {notification.body}
          </Text>
        </View>

        {/* Dismiss button */}
        <TouchableOpacity
          style={styles.dismissBtn}
          onPress={handleDismiss}
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
        >
          <Ionicons name="close" size={18} color="#888" />
        </TouchableOpacity>
      </TouchableOpacity>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: Platform.OS === 'ios' ? 50 : 40,
    left: 16,
    right: 16,
    zIndex: 9999,
    elevation: 9999,
  } as ViewStyle,
  toast: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1A1A1A',
    borderRadius: 16,
    paddingVertical: 14,
    paddingHorizontal: 16,
    paddingLeft: 20,
    borderWidth: 1,
    borderColor: '#2A2A2A',
    // Shadow
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
    elevation: 20,
  } as ViewStyle,
  accentStripe: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 4,
    borderTopLeftRadius: 16,
    borderBottomLeftRadius: 16,
  } as ViewStyle,
  iconContainer: {
    width: 42,
    height: 42,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  } as ViewStyle,
  content: {
    flex: 1,
    marginRight: 8,
  } as ViewStyle,
  title: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '800',
    marginBottom: 2,
  } as TextStyle,
  body: {
    color: '#AAAAAA',
    fontSize: 12,
    fontWeight: '500',
    lineHeight: 16,
  } as TextStyle,
  dismissBtn: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: '#262626',
    justifyContent: 'center',
    alignItems: 'center',
  } as ViewStyle,
});

export default NotificationToast;
