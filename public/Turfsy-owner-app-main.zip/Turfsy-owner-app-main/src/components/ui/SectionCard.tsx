import React from 'react';
import { StyleSheet, View, ViewProps } from 'react-native';

import { useAppTheme } from '@/src/hooks/useAppTheme';

export function SectionCard({ style, ...props }: ViewProps) {
  const { theme } = useAppTheme();

  return (
    <View
      {...props}
      style={[
        {
          backgroundColor: theme.colors.surface,
          borderRadius: theme.radius.card,
          borderWidth: 1,
          borderColor: theme.colors.cardBorder,
          padding: 16,
          shadowColor: '#000000',
          shadowOffset: { width: 0, height: 10 },
          shadowOpacity: 0.22,
          shadowRadius: 30,
          elevation: 8,
          overflow: 'hidden',
        },
        style,
      ]}
    />
  );
}
