import React, { useEffect, useRef, useState } from 'react';
import {
  Animated,
  Dimensions,
  Modal,
  StyleSheet,
  Text,
  TouchableOpacity,
  TouchableWithoutFeedback,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAppTheme } from '../../hooks/useAppTheme';

type AlertType = 'success' | 'error' | 'warning' | 'info';

interface AlertButton {
  text: string;
  onPress?: () => void;
  style?: 'default' | 'cancel' | 'destructive';
}

interface AlertConfig {
  type?: AlertType;
  title: string;
  message: string;
  buttons?: AlertButton[];
}

interface CustomAlertState {
  visible: boolean;
  config: AlertConfig;
}

// Global alert state
let alertListener: ((state: CustomAlertState) => void) | null = null;

export const showAlert = (
  title: string,
  message: string,
  buttons?: AlertButton[],
  type?: AlertType
) => {
  if (alertListener) {
    alertListener({
      visible: true,
      config: { title, message, buttons, type: type || 'info' },
    });
  }
};

// Convenience functions
export const showSuccess = (title: string, message: string, buttons?: AlertButton[]) =>
  showAlert(title, message, buttons, 'success');

export const showError = (title: string, message: string, buttons?: AlertButton[]) =>
  showAlert(title, message, buttons, 'error');

export const showWarning = (title: string, message: string, buttons?: AlertButton[]) =>
  showAlert(title, message, buttons, 'warning');

export const showInfo = (title: string, message: string, buttons?: AlertButton[]) =>
  showAlert(title, message, buttons, 'info');

const ALERT_CONFIG: Record<AlertType, { icon: keyof typeof Ionicons.glyphMap; gradient: string }> = {
  success: { icon: 'checkmark-circle', gradient: '#ADFF00' },
  error: { icon: 'alert-circle', gradient: '#FF453A' },
  warning: { icon: 'warning', gradient: '#FFD60A' },
  info: { icon: 'information-circle', gradient: '#64D2FF' },
};

export function CustomAlertProvider({ children }: { children: React.ReactNode }) {
  const { theme, isDark } = useAppTheme();
  const [state, setState] = useState<CustomAlertState>({
    visible: false,
    config: { title: '', message: '' },
  });

  const scaleAnim = useRef(new Animated.Value(0)).current;
  const opacityAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    alertListener = setState;
    return () => {
      alertListener = null;
    };
  }, []);

  useEffect(() => {
    if (state.visible) {
      Animated.parallel([
        Animated.spring(scaleAnim, {
          toValue: 1,
          tension: 65,
          friction: 8,
          useNativeDriver: true,
        }),
        Animated.timing(opacityAnim, {
          toValue: 1,
          duration: 200,
          useNativeDriver: true,
        }),
      ]).start();
    }
  }, [state.visible]);

  const dismiss = (callback?: () => void) => {
    Animated.parallel([
      Animated.timing(scaleAnim, {
        toValue: 0,
        duration: 150,
        useNativeDriver: true,
      }),
      Animated.timing(opacityAnim, {
        toValue: 0,
        duration: 150,
        useNativeDriver: true,
      }),
    ]).start(() => {
      setState((s) => ({ ...s, visible: false }));
      scaleAnim.setValue(0);
      opacityAnim.setValue(0);
      callback?.();
    });
  };

  const alertType = state.config.type || 'info';
  const alertConf = ALERT_CONFIG[alertType];
  const buttons = state.config.buttons || [{ text: 'OK' }];

  const accentColor = alertType === 'success' ? theme.colors.primary : alertConf.gradient;

  return (
    <>
      {children}
      <Modal
        transparent
        visible={state.visible}
        animationType="none"
        statusBarTranslucent
        onRequestClose={() => dismiss()}
      >
        <TouchableWithoutFeedback onPress={() => dismiss()}>
          <Animated.View
            style={[
              styles.overlay,
              { opacity: opacityAnim },
            ]}
          >
            <TouchableWithoutFeedback>
              <Animated.View
                style={[
                  styles.alertContainer,
                  {
                    backgroundColor: isDark ? '#1A1A1A' : '#FFFFFF',
                    borderColor: isDark ? '#333' : '#E0E0E0',
                    transform: [{ scale: scaleAnim }],
                  },
                ]}
              >
                {/* Icon Circle */}
                <View
                  style={[
                    styles.iconCircle,
                    {
                      backgroundColor: accentColor + '18',
                      borderColor: accentColor + '30',
                    },
                  ]}
                >
                  <Ionicons name={alertConf.icon} size={36} color={accentColor} />
                </View>

                {/* Title */}
                <Text
                  style={[
                    styles.title,
                    { color: isDark ? '#FFFFFF' : '#000000' },
                  ]}
                >
                  {state.config.title}
                </Text>

                {/* Message */}
                <Text
                  style={[
                    styles.message,
                    { color: isDark ? '#999999' : '#666666' },
                  ]}
                >
                  {state.config.message}
                </Text>

                {/* Divider */}
                <View
                  style={[
                    styles.divider,
                    { backgroundColor: isDark ? '#333' : '#E5E5E5' },
                  ]}
                />

                {/* Buttons */}
                <View style={[styles.buttonRow, buttons.length === 1 && { justifyContent: 'center' }]}>
                  {buttons.map((btn, idx) => {
                    const isDestructive = btn.style === 'destructive';
                    const isCancel = btn.style === 'cancel';
                    const isPrimary = !isCancel && !isDestructive;

                    return (
                      <TouchableOpacity
                        key={idx}
                        style={[
                          styles.button,
                          buttons.length === 1 && styles.singleButton,
                          isPrimary && {
                            backgroundColor: accentColor,
                          },
                          isCancel && {
                            backgroundColor: isDark ? '#262626' : '#F0F0F0',
                          },
                          isDestructive && {
                            backgroundColor: '#FF453A',
                          },
                        ]}
                        activeOpacity={0.8}
                        onPress={() => dismiss(btn.onPress)}
                      >
                        <Text
                          style={[
                            styles.buttonText,
                            isPrimary && {
                              color: alertType === 'success' || alertType === 'warning' ? '#000000' : '#FFFFFF',
                            },
                            isCancel && {
                              color: isDark ? '#AAAAAA' : '#666666',
                            },
                            isDestructive && {
                              color: '#FFFFFF',
                            },
                          ]}
                        >
                          {btn.text}
                        </Text>
                      </TouchableOpacity>
                    );
                  })}
                </View>
              </Animated.View>
            </TouchableWithoutFeedback>
          </Animated.View>
        </TouchableWithoutFeedback>
      </Modal>
    </>
  );
}

const { width: SCREEN_WIDTH } = Dimensions.get('window');

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 32,
  },
  alertContainer: {
    width: Math.min(SCREEN_WIDTH - 64, 360),
    borderRadius: 24,
    borderWidth: 1,
    paddingTop: 32,
    paddingHorizontal: 24,
    paddingBottom: 24,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.25,
    shadowRadius: 24,
    elevation: 20,
  },
  iconCircle: {
    width: 72,
    height: 72,
    borderRadius: 36,
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: 0.3,
    textAlign: 'center',
    marginBottom: 8,
  },
  message: {
    fontSize: 14,
    fontWeight: '500',
    lineHeight: 21,
    textAlign: 'center',
    marginBottom: 24,
  },
  divider: {
    width: '100%',
    height: 1,
    marginBottom: 20,
  },
  buttonRow: {
    flexDirection: 'row',
    gap: 12,
    width: '100%',
  },
  button: {
    flex: 1,
    height: 50,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  singleButton: {
    flex: 0,
    minWidth: 160,
    paddingHorizontal: 32,
  },
  buttonText: {
    fontSize: 15,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
});
