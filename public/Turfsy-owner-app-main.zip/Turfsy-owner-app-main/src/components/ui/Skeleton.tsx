import React, { useEffect, useRef } from 'react';
import { Animated, View, StyleSheet, ViewStyle } from 'react-native';
import { useAppTheme } from '@/src/hooks/useAppTheme';
import { useResponsive } from '@/src/utils/responsive';

interface SkeletonProps {
  width?: number | string;
  height?: number | string;
  borderRadius?: number;
  style?: ViewStyle;
}

export const Skeleton: React.FC<SkeletonProps> & {
  Circle: React.FC<SkeletonProps>;
  Card: React.FC<SkeletonProps & { children?: React.ReactNode }>;
  TextLine: React.FC<SkeletonProps>;
  HomeScreen: React.FC;
  BookingScreen: React.FC;
  BookingDetailScreen: React.FC;
  AnalyticsScreen: React.FC;
} = ({
  width = '100%',
  height = 20,
  borderRadius = 8,
  style,
}) => {
  const { theme } = useAppTheme();
  const opacity = useRef(new Animated.Value(0.35)).current;

  useEffect(() => {
    const animation = Animated.loop(
      Animated.sequence([
        Animated.timing(opacity, {
          toValue: 0.65,
          duration: 900,
          useNativeDriver: true,
        }),
        Animated.timing(opacity, {
          toValue: 0.35,
          duration: 900,
          useNativeDriver: true,
        }),
      ])
    );
    animation.start();
    return () => animation.stop();
  }, [opacity]);

  return (
    <Animated.View
      style={[
        {
          width: width as any,
          height: height as any,
          borderRadius,
          backgroundColor: theme.colors.surfaceElevated,
          opacity,
        },
        style,
      ]}
    />
  );
};

// ─── Circle Preset ──────────────────────────────────────────────────────────
Skeleton.Circle = ({ width = 48, height = 48, style }) => {
  const size = typeof width === 'number' ? width : 48;
  return <Skeleton width={size} height={size} borderRadius={size / 2} style={style} />;
};

// ─── Card Wrapper (Container styled card with skeletons inside) ──────────────
Skeleton.Card = ({ children, style }) => {
  const { theme } = useAppTheme();
  return (
    <View
      style={[
        {
          backgroundColor: theme.colors.surface,
          borderRadius: theme.radius.card,
          borderWidth: 1,
          borderColor: theme.colors.border,
          padding: 16,
          marginBottom: 12,
        },
        style,
      ]}
    >
      {children}
    </View>
  );
};

// ─── Text Line Preset ────────────────────────────────────────────────────────
Skeleton.TextLine = ({ width = '70%', height = 14, borderRadius = 6, style }) => {
  return <Skeleton width={width} height={height} borderRadius={borderRadius} style={style} />;
};

// ─── Home Dashboard Skeleton Layout ──────────────────────────────────────────
Skeleton.HomeScreen = () => {
  const responsive = useResponsive();
  const { theme } = useAppTheme();

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.background, paddingHorizontal: responsive.isTablet ? 32 : 24, paddingTop: 16 }}>
      {/* Header Greeting Skeleton */}
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <View style={{ gap: 6 }}>
          <Skeleton.TextLine width={120} height={24} />
          <Skeleton.TextLine width={80} height={16} />
        </View>
        <Skeleton.Circle width={44} height={44} />
      </View>

      {/* Hero Card Skeleton */}
      <Skeleton.Card style={{ height: 180, marginBottom: 24, justifyContent: 'space-between' }}>
        <View style={{ gap: 8 }}>
          <Skeleton.TextLine width={100} height={12} />
          <Skeleton.TextLine width={160} height={32} />
        </View>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <Skeleton.TextLine width={120} height={14} />
          <Skeleton width={80} height={32} borderRadius={16} />
        </View>
      </Skeleton.Card>

      {/* Stats Grid Skeletons */}
      <View style={{ flexDirection: 'row', gap: 12, marginBottom: 32 }}>
        <Skeleton.Card style={{ flex: 1, height: 100, gap: 12, alignItems: 'center', justifyContent: 'center' }}>
          <Skeleton.Circle width={24} height={24} />
          <Skeleton.TextLine width="60%" height={10} />
          <Skeleton.TextLine width="40%" height={14} />
        </Skeleton.Card>
        <Skeleton.Card style={{ flex: 1, height: 100, gap: 12, alignItems: 'center', justifyContent: 'center' }}>
          <Skeleton.Circle width={24} height={24} />
          <Skeleton.TextLine width="60%" height={10} />
          <Skeleton.TextLine width="40%" height={14} />
        </Skeleton.Card>
        <Skeleton.Card style={{ flex: 1, height: 100, gap: 12, alignItems: 'center', justifyContent: 'center' }}>
          <Skeleton.Circle width={24} height={24} />
          <Skeleton.TextLine width="60%" height={10} />
          <Skeleton.TextLine width="40%" height={14} />
        </Skeleton.Card>
      </View>

      {/* Chart Skeleton */}
      <Skeleton.Card style={{ height: 220, marginBottom: 24, justifyContent: 'space-between' }}>
        <Skeleton.TextLine width={150} height={16} />
        <Skeleton width="100%" height={120} borderRadius={12} />
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
          <Skeleton.TextLine width={40} height={10} />
          <Skeleton.TextLine width={40} height={10} />
          <Skeleton.TextLine width={40} height={10} />
          <Skeleton.TextLine width={40} height={10} />
        </View>
      </Skeleton.Card>

      {/* List Skeletons */}
      <Skeleton.TextLine width={140} height={18} style={{ marginBottom: 12 }} />
      <Skeleton.Card style={{ height: 70, marginBottom: 12 }} />
      <Skeleton.Card style={{ height: 70, marginBottom: 12 }} />
    </View>
  );
};

// ─── Booking Screen Skeleton Layout ─────────────────────────────────────────
Skeleton.BookingScreen = () => {
  const responsive = useResponsive();
  const { theme } = useAppTheme();

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.background, paddingHorizontal: responsive.isTablet ? 32 : 24, paddingTop: 16 }}>
      {/* Screen Title */}
      <Skeleton.TextLine width={120} height={28} style={{ marginBottom: 20 }} />

      {/* Quick Metrics */}
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-between',
          backgroundColor: theme.colors.surfaceMuted,
          borderRadius: 24,
          paddingVertical: 20,
          paddingHorizontal: 16,
          marginBottom: 20,
          borderWidth: 1,
          borderColor: theme.colors.border,
        }}
      >
        <View style={{ flex: 1, alignItems: 'center', gap: 6 }}>
          <Skeleton.TextLine width={40} height={22} />
          <Skeleton.TextLine width={30} height={10} />
        </View>
        <View style={{ width: 1, height: 30, backgroundColor: theme.colors.border }} />
        <View style={{ flex: 1, alignItems: 'center', gap: 6 }}>
          <Skeleton.TextLine width={40} height={22} />
          <Skeleton.TextLine width={30} height={10} />
        </View>
        <View style={{ width: 1, height: 30, backgroundColor: theme.colors.border }} />
        <View style={{ flex: 1, alignItems: 'center', gap: 6 }}>
          <Skeleton.TextLine width={40} height={22} />
          <Skeleton.TextLine width={30} height={10} />
        </View>
      </View>

      {/* Search Input Box */}
      <View
        style={{
          height: 52,
          backgroundColor: theme.colors.surface,
          borderRadius: 20,
          borderWidth: 1.5,
          borderColor: theme.colors.border,
          marginBottom: 16,
          paddingHorizontal: 16,
          justifyContent: 'center',
        }}
      >
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          <Skeleton.Circle width={20} height={20} />
          <Skeleton.TextLine width="50%" height={14} />
        </View>
      </View>

      {/* Filter Row */}
      <View style={{ flexDirection: 'row', gap: 10, marginBottom: 20 }}>
        <Skeleton width={60} height={36} borderRadius={18} />
        <Skeleton width={80} height={36} borderRadius={18} />
        <Skeleton width={90} height={36} borderRadius={18} />
        <Skeleton width={90} height={36} borderRadius={18} />
      </View>

      {/* Booking list skeletons */}
      <View style={{ gap: 10 }}>
        {[1, 2, 3, 4].map((i) => (
          <Skeleton.Card key={i} style={{ flexDirection: 'row', alignItems: 'center', gap: 16, padding: 16 }}>
            {/* Left Date Box */}
            <Skeleton width={60} height={60} borderRadius={16} />
            {/* Center Info */}
            <View style={{ flex: 1, gap: 8 }}>
              <Skeleton.TextLine width="60%" height={16} />
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                <Skeleton.TextLine width="40%" height={12} />
                <Skeleton.TextLine width="20%" height={12} />
              </View>
              <Skeleton width={70} height={20} borderRadius={8} />
            </View>
            {/* Right arrow */}
            <Skeleton.Circle width={24} height={24} />
          </Skeleton.Card>
        ))}
      </View>
    </View>
  );
};

// ─── Booking Detail Screen Skeleton Layout ───────────────────────────────────
Skeleton.BookingDetailScreen = () => {
  const responsive = useResponsive();
  const { theme } = useAppTheme();

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.background, paddingHorizontal: responsive.isTablet ? 32 : 24, paddingTop: 16 }}>
      {/* Header back button + title */}
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 16, marginBottom: 24 }}>
        <Skeleton.Circle width={40} height={40} />
        <Skeleton.TextLine width={180} height={24} />
      </View>

      {/* Card Section 1: Customer Info */}
      <Skeleton.Card style={{ padding: 20, gap: 16 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 16 }}>
          <Skeleton.Circle width={54} height={54} />
          <View style={{ gap: 8, flex: 1 }}>
            <Skeleton.TextLine width="70%" height={18} />
            <Skeleton.TextLine width="40%" height={12} />
          </View>
        </View>
      </Skeleton.Card>

      {/* Card Section 2: Booking Info */}
      <Skeleton.Card style={{ padding: 20, gap: 20 }}>
        <Skeleton.TextLine width="50%" height={14} style={{ marginBottom: 4 }} />
        <View style={{ gap: 12 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <Skeleton.TextLine width="30%" height={14} />
            <Skeleton.TextLine width="40%" height={14} />
          </View>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <Skeleton.TextLine width="25%" height={14} />
            <Skeleton.TextLine width="45%" height={14} />
          </View>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <Skeleton.TextLine width="35%" height={14} />
            <Skeleton.TextLine width="30%" height={14} />
          </View>
        </View>
      </Skeleton.Card>

      {/* Card Section 3: Pricing Info */}
      <Skeleton.Card style={{ padding: 20, gap: 16 }}>
        <Skeleton.TextLine width="40%" height={14} />
        <View style={{ gap: 12 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <Skeleton.TextLine width="30%" height={14} />
            <Skeleton.TextLine width="20%" height={14} />
          </View>
          <View style={{ width: '100%', height: 1, backgroundColor: theme.colors.border }} />
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <Skeleton.TextLine width="35%" height={18} />
            <Skeleton.TextLine width="25%" height={18} />
          </View>
        </View>
      </Skeleton.Card>

      {/* Action Buttons */}
      <View style={{ marginTop: 24, gap: 12 }}>
        <Skeleton width="100%" height={56} borderRadius={18} />
        <Skeleton width="100%" height={56} borderRadius={18} />
      </View>
    </View>
  );
};

// ─── Analytics Screen Skeleton Layout ─────────────────────────────────────────
Skeleton.AnalyticsScreen = () => {
  const responsive = useResponsive();
  const { theme } = useAppTheme();

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.background, paddingHorizontal: responsive.isTablet ? 32 : 24, paddingTop: 16 }}>
      {/* Header Skeleton */}
      <View style={{ gap: 6, marginBottom: 24 }}>
        <Skeleton.TextLine width={100} height={12} />
        <Skeleton.TextLine width={150} height={28} />
        <Skeleton.TextLine width="90%" height={16} />
      </View>

      {/* Stats Container Skeleton */}
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-between',
          backgroundColor: theme.colors.surfaceMuted,
          borderRadius: 24,
          paddingVertical: 20,
          paddingHorizontal: 16,
          marginBottom: 20,
          borderWidth: 1,
          borderColor: theme.colors.border,
        }}
      >
        <View style={{ flex: 1, alignItems: 'center', gap: 6 }}>
          <Skeleton.Circle width={20} height={20} />
          <Skeleton.TextLine width={40} height={22} />
          <Skeleton.TextLine width={50} height={10} />
        </View>
        <View style={{ width: 1, height: 35, backgroundColor: theme.colors.border }} />
        <View style={{ flex: 1, alignItems: 'center', gap: 6 }}>
          <Skeleton.Circle width={20} height={20} />
          <Skeleton.TextLine width={50} height={22} />
          <Skeleton.TextLine width={50} height={10} />
        </View>
      </View>

      {/* Monthly Overview Card Skeleton */}
      <Skeleton.Card style={{ height: 180, marginBottom: 24, justifyContent: 'space-between', padding: 24 }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <View style={{ gap: 8 }}>
            <Skeleton.TextLine width={100} height={12} />
            <Skeleton.TextLine width={180} height={36} />
          </View>
          <Skeleton width={48} height={48} borderRadius={16} />
        </View>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, paddingTop: 16, borderTopWidth: 1, borderTopColor: theme.colors.border }}>
          <Skeleton.Circle width={16} height={16} />
          <Skeleton.TextLine width="80%" height={14} />
        </View>
      </Skeleton.Card>

      {/* Weekly Bar Chart Card Skeleton */}
      <Skeleton.Card style={{ height: 220, marginBottom: 24, justifyContent: 'space-between', padding: 20 }}>
        <Skeleton.TextLine width={150} height={12} />
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end', height: 120 }}>
          {[1, 2, 3, 4, 5, 6, 7].map((i) => (
            <View key={i} style={{ flex: 1, alignItems: 'center', gap: 8 }}>
              <Skeleton width={20} height={i * 15 + 20} borderRadius={6} />
              <Skeleton.TextLine width={24} height={10} />
            </View>
          ))}
        </View>
      </Skeleton.Card>

      {/* Key Operations Card Skeleton */}
      <Skeleton.Card style={{ padding: 20, gap: 16 }}>
        <Skeleton.TextLine width={120} height={14} style={{ marginBottom: 4 }} />
        <View style={{ gap: 12 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <Skeleton.Circle width={14} height={14} />
              <Skeleton.TextLine width={120} height={14} />
            </View>
            <Skeleton.TextLine width={40} height={14} />
          </View>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <Skeleton.Circle width={14} height={14} />
              <Skeleton.TextLine width={120} height={14} />
            </View>
            <Skeleton.TextLine width={30} height={14} />
          </View>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <Skeleton.Circle width={14} height={14} />
              <Skeleton.TextLine width={100} height={14} />
            </View>
            <Skeleton.TextLine width={30} height={14} />
          </View>
        </View>
      </Skeleton.Card>
    </View>
  );
};
