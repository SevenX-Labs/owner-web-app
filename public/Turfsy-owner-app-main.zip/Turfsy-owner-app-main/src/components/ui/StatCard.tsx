import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { useResponsive } from '@/src/utils/responsive';
import { useAppTheme } from '@/src/hooks/useAppTheme';

interface StatCardProps {
  label: string;
  value: string;
  icon?: keyof typeof Ionicons.glyphMap;
  highlight?: boolean;
  style?: any;
}

export function StatCard({ label, value, icon, highlight = false, style }: StatCardProps) {
  const responsive = useResponsive();
  const { theme } = useAppTheme();

  return (
    <View style={[
      styles.card,
      {
        backgroundColor: highlight ? theme.colors.primary : theme.colors.surface,
        borderColor: highlight ? theme.colors.primary : theme.colors.cardBorder,
      },
      style,
    ]}>
      {/* Top Row: Label and Icon */}
      <View style={styles.topRow}>
        <Text
          style={[
            styles.label,
            {
              fontSize: responsive.fp(10),
              color: highlight ? 'rgba(0,0,0,0.6)' : theme.colors.textMuted,
              fontFamily: theme.fonts.bold,
            },
          ]}
          numberOfLines={1}
          adjustsFontSizeToFit
        >
          {label}
        </Text>
        
        {icon ? (
          <View style={[
            styles.iconWrapper,
            { backgroundColor: highlight ? 'rgba(0,0,0,0.1)' : theme.colors.surfaceMuted }
          ]}>
            <Ionicons
              name={icon}
              size={responsive.moderateScale(12)}
              color={highlight ? '#111111' : theme.colors.primary}
            />
          </View>
        ) : null}
      </View>

      {/* Bottom: Large Value */}
      <Text
        style={[
          styles.value,
          {
            fontSize: responsive.fp(24),
            color: highlight ? '#111111' : theme.colors.text,
            fontFamily: theme.fonts.black,
            marginTop: 12,
          },
        ]}
        numberOfLines={1}
        adjustsFontSizeToFit
        minimumFontScale={0.5}
      >
        {value}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    flex: 1,
    minWidth: 0,
    paddingHorizontal: 14,
    paddingVertical: 14,
    borderRadius: 20,
    borderWidth: 1,
    justifyContent: 'space-between',
  },
  topRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  iconWrapper: {
    width: 24,
    height: 24,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  label: {
    letterSpacing: 0.5,
    flex: 1,
  },
  value: {
    letterSpacing: -0.5,
  },
});
